import React, { useState } from 'react';
import {
  Scale,
  ArrowRight,
  Sparkles,
  LayoutDashboard,
  Settings,
  ShieldCheck,
  LogOut,
  User as UserIcon,
  Menu,
  X,
  FolderOpen,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type AppView = 'landing' | 'editor' | 'lease-wizard' | 'dashboard' | 'templates' | 'settings' | 'admin' | 'preview';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  onOpenAuth: (mode: 'login' | 'signup') => void;
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenAuth,
  onToggleSidebar,
}) => {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const handleLogout = async () => {
    setProfileDropdownOpen(false);
    setMobileMenuOpen(false);
    await logout();
    onNavigate('landing');
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100">
      {/* Top Demo View Switcher Banner */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 flex flex-wrap items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-400 font-medium hidden sm:inline">LegalEase Interactive Experience:</span>
          <span className="text-white font-semibold">Live Mode Preview</span>
        </div>
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => onNavigate('landing')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
              currentView === 'landing'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Landing
          </button>
          <button
            onClick={() => onNavigate('editor')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-all flex items-center gap-1 ${
              currentView === 'editor'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3 h-3 text-blue-300" />
            AI Studio
          </button>
          <button
            onClick={() => onNavigate('lease-wizard')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
              currentView === 'lease-wizard'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Lease Builder
          </button>
          <button
            onClick={() => onNavigate('dashboard')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-all flex items-center gap-1 ${
              currentView === 'dashboard'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <LayoutDashboard className="w-3 h-3" />
            Dashboard
          </button>
          {user?.role === 'admin' && (
            <button
              onClick={() => onNavigate('admin')}
              className={`px-2.5 py-1 rounded text-xs font-bold transition-all flex items-center gap-1 ${
                currentView === 'admin'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-purple-300 hover:text-white hover:bg-purple-950/60'
              }`}
            >
              <ShieldCheck className="w-3 h-3" />
              Admin
            </button>
          )}
        </div>
      </div>

      {/* Main LegalEase Nav Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => onNavigate('landing')}
          className="flex items-center gap-3 cursor-pointer select-none group"
        >
          <div className="w-11 h-11 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shadow-sm group-hover:bg-blue-100 transition-colors">
            <Scale className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div className="flex flex-col">
            <span className="text-2xl font-bold text-slate-900 tracking-tight flex items-center">
              Legal<span className="text-blue-600">Ease</span>
            </span>
            <span className="text-[11px] font-medium text-slate-400 tracking-wide">
              Smart Legal Documents. Made Simple.
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8">
          <button
            onClick={() => onNavigate('landing')}
            className={`text-sm font-medium transition-colors relative py-2 ${
              currentView === 'landing'
                ? 'text-blue-600 font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Home
            {currentView === 'landing' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
            )}
          </button>

          <button
            onClick={() => onNavigate('templates')}
            className={`text-sm font-medium transition-colors relative py-2 ${
              currentView === 'templates'
                ? 'text-blue-600 font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Templates
            {currentView === 'templates' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
            )}
          </button>

          <a
            href="#how-it-works"
            onClick={(e) => {
              if (currentView !== 'landing') {
                e.preventDefault();
                onNavigate('landing');
                setTimeout(() => {
                  document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }
            }}
            className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors"
          >
            How It Works
          </a>

          <a
            href="#pricing"
            onClick={(e) => {
              if (currentView !== 'landing') {
                e.preventDefault();
                onNavigate('landing');
                setTimeout(() => {
                  document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }
            }}
            className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors"
          >
            Pricing
          </a>

          <button
            onClick={() => onNavigate('dashboard')}
            className={`text-sm font-medium transition-colors relative py-2 ${
              currentView === 'dashboard'
                ? 'text-blue-600 font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Dashboard
            {currentView === 'dashboard' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
            )}
          </button>
        </nav>

        {/* Right CTA / User Status */}
        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-2.5 p-1.5 pr-3 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-2xs">
                  {user.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase() || 'U'}
                </div>
                <div className="text-left text-xs">
                  <p className="font-bold text-slate-900 leading-tight truncate max-w-[120px]">{user.name}</p>
                  <span className="text-[10px] text-blue-600 font-semibold uppercase">{user.subscriptionPlan}</span>
                </div>
              </button>

              {/* Profile Dropdown Menu */}
              {profileDropdownOpen && (
                <div
                  onMouseLeave={() => setProfileDropdownOpen(false)}
                  className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200/90 p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                >
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="font-bold text-slate-900 text-xs">{user.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                  </div>

                  <div className="py-1 text-xs text-slate-700">
                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onNavigate('dashboard');
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-50 text-left font-medium"
                    >
                      <LayoutDashboard className="w-4 h-4 text-slate-400" />
                      <span>Workspace Dashboard</span>
                    </button>

                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onNavigate('editor');
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-50 text-left font-medium"
                    >
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <span>AI Document Studio</span>
                    </button>

                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onNavigate('settings');
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-50 text-left font-medium"
                    >
                      <Settings className="w-4 h-4 text-slate-400" />
                      <span>Settings & Security</span>
                    </button>

                    {user.role === 'admin' && (
                      <button
                        onClick={() => {
                          setProfileDropdownOpen(false);
                          onNavigate('admin');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg bg-purple-50 text-purple-800 text-left font-semibold"
                      >
                        <ShieldCheck className="w-4 h-4 text-purple-600" />
                        <span>Admin Console</span>
                      </button>
                    )}
                  </div>

                  <div className="border-t border-slate-100 pt-1">
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-rose-50 text-rose-600 text-left text-xs font-semibold"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <>
              <button
                onClick={() => onOpenAuth('login')}
                className="px-5 py-2.5 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-all shadow-xs cursor-pointer"
              >
                Login
              </button>
              <button
                onClick={() => onOpenAuth('signup')}
                className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-sm hover:shadow transition-all flex items-center gap-2 group cursor-pointer"
              >
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </>
          )}
        </div>

        {/* Mobile Hamburger Button */}
        <div className="md:hidden flex items-center gap-2">
          {onToggleSidebar && currentView !== 'landing' && (
            <button
              onClick={onToggleSidebar}
              className="p-2 rounded-lg text-blue-600 bg-blue-50 hover:bg-blue-100 flex items-center gap-1.5 text-xs font-semibold"
              title="Open Workspace Navigation"
            >
              <Menu className="w-4 h-4" />
              <span>Menu</span>
            </button>
          )}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-slate-600 hover:bg-slate-100"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 p-4 space-y-3 text-sm animate-in slide-in-from-top-3 duration-150">
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onNavigate('landing');
            }}
            className="w-full text-left py-2 font-medium text-slate-800"
          >
            Home
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onNavigate('templates');
            }}
            className="w-full text-left py-2 font-medium text-slate-800"
          >
            Templates
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onNavigate('editor');
            }}
            className="w-full text-left py-2 font-medium text-blue-600 flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" /> AI Document Studio
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onNavigate('lease-wizard');
            }}
            className="w-full text-left py-2 font-medium text-slate-800"
          >
            Lease Agreement Wizard
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onNavigate('dashboard');
            }}
            className="w-full text-left py-2 font-medium text-slate-800"
          >
            Dashboard
          </button>

          {user ? (
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onNavigate('settings');
                }}
                className="w-full text-left py-2 font-medium text-slate-700 flex items-center gap-2"
              >
                <Settings className="w-4 h-4" /> Settings & Profile
              </button>
              {user.role === 'admin' && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate('admin');
                  }}
                  className="w-full text-left py-2 font-bold text-purple-700 flex items-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" /> Admin Console
                </button>
              )}
              <button
                onClick={handleLogout}
                className="w-full text-left py-2 font-semibold text-rose-600 flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            </div>
          ) : (
            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAuth('login');
                }}
                className="w-full py-2.5 text-center font-semibold border border-slate-200 rounded-xl"
              >
                Login
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAuth('signup');
                }}
                className="w-full py-2.5 text-center font-semibold bg-blue-600 text-white rounded-xl shadow-xs"
              >
                Get Started
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
