import React from 'react';
import { X, CheckCircle2, ArrowRight, Play, Shield, Sparkles, FileText, Download } from 'lucide-react';

interface HowItWorksModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartDrafting: () => void;
}

export const HowItWorksModal: React.FC<HowItWorksModalProps> = ({
  isOpen,
  onClose,
  onStartDrafting,
}) => {
  if (!isOpen) return null;

  const steps = [
    {
      num: '01',
      title: 'Choose Your Document Template',
      desc: 'Select from our verified template library: Rental Agreements, NDAs, Master Service Agreements, or Wills.',
      icon: FileText,
    },
    {
      num: '02',
      title: 'Answer Guided Questions',
      desc: 'Provide your jurisdiction, parties\' names, contract duration, compensation amounts, and special rules.',
      icon: Sparkles,
    },
    {
      num: '03',
      title: 'AI Generates Custom First Draft',
      desc: 'Our engine applies verified statutory clauses, checks GDPR/CCPA protections, and highlights key variables.',
      icon: Shield,
    },
    {
      num: '04',
      title: 'Customize, Rewrite & Review',
      desc: 'Use Quick Rewrite to adjust clause tone (More Formal, More Protective) and review AI legal suggestions.',
      icon: Play,
    },
    {
      num: '05',
      title: 'Export PDF, DOCX or E-Sign',
      desc: 'Send for legally compliant e-signature with audit certificates, or download print-ready formatted PDFs.',
      icon: Download,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider block mb-0.5">
              THE WORKFLOW
            </span>
            <h3 className="text-xl font-bold text-slate-900">How LegalEase Works</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {steps.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div key={idx} className="flex items-start gap-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-2xs">
                  {s.num}
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-bold text-slate-900 mb-1">{s.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <p className="text-xs text-slate-500">Drafts are saved automatically to your workspace.</p>
          <button
            onClick={() => {
              onClose();
              onStartDrafting();
            }}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
          >
            <span>Try It Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
