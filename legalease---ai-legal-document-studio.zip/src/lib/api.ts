import { LegalDocument, SourceCitation, OutdatedLawWarning, JurisdictionInfo } from '../types';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  subscriptionPlan: 'free' | 'pro' | 'enterprise';
  emailVerified: boolean;
}

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  // Get token from localStorage if present
  const storedToken = localStorage.getItem('legalease_token');
  if (storedToken && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${storedToken}`);
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
    credentials: 'include', // sends cookies
  });

  if (!response.ok) {
    let errorMsg = `Request failed (${response.status})`;
    try {
      const errorJson = await response.json();
      if (errorJson.error) {
        errorMsg = errorJson.error;
      }
    } catch {
      // not json
    }
    throw new ApiError(errorMsg, response.status);
  }

  return response.json();
}

export const api = {
  // Authentication
  auth: {
    me: async (): Promise<{ user: User | null }> => {
      try {
        return await request<{ user: User | null }>('/api/auth/me');
      } catch {
        return { user: null };
      }
    },
    login: async (credentials: { email: string; password: string }): Promise<{ user: User; token: string }> => {
      const res = await request<{ user: User; token: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      });
      if (res.token) {
        localStorage.setItem('legalease_token', res.token);
      }
      return res;
    },
    register: async (data: { name: string; email: string; password: string }): Promise<{ user: User; token: string }> => {
      const res = await request<{ user: User; token: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      if (res.token) {
        localStorage.setItem('legalease_token', res.token);
      }
      return res;
    },
    logout: async (): Promise<void> => {
      try {
        await request('/api/auth/logout', { method: 'POST' });
      } finally {
        localStorage.removeItem('legalease_token');
      }
    },
    forgotPassword: async (email: string): Promise<{ success: boolean; message: string; resetToken?: string }> => {
      return request('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
    },
    resetPassword: async (data: { token: string; newPassword: string }): Promise<{ success: boolean; message: string }> => {
      return request('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    updateProfile: async (data: { name?: string; email?: string }): Promise<{ user: User; message: string }> => {
      return request('/api/auth/profile', {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    },
    changePassword: async (data: { currentPassword: string; newPassword: string }): Promise<{ success: boolean; message: string }> => {
      return request('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    deleteAccount: async (confirmPassword: string): Promise<{ success: boolean; message: string }> => {
      const res = await request<{ success: boolean; message: string }>('/api/auth/delete-account', {
        method: 'DELETE',
        body: JSON.stringify({ confirmPassword }),
      });
      localStorage.removeItem('legalease_token');
      return res;
    },
  },

  // Documents
  documents: {
    list: async (): Promise<{ documents: LegalDocument[] }> => {
      return request('/api/documents');
    },
    getById: async (id: string): Promise<{ document: LegalDocument }> => {
      return request(`/api/documents/${id}`);
    },
    create: async (docData: Partial<LegalDocument>): Promise<{ document: LegalDocument }> => {
      return request('/api/documents', {
        method: 'POST',
        body: JSON.stringify(docData),
      });
    },
    update: async (id: string, updates: Partial<LegalDocument>): Promise<{ document: LegalDocument }> => {
      return request(`/api/documents/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      });
    },
    delete: async (id: string): Promise<{ success: boolean; message: string }> => {
      return request(`/api/documents/${id}`, {
        method: 'DELETE',
      });
    },
    downloadDocx: async (id: string, filename: string): Promise<void> => {
      const storedToken = localStorage.getItem('legalease_token');
      const headers: Record<string, string> = {};
      if (storedToken) {
        headers['Authorization'] = `Bearer ${storedToken}`;
      }

      const response = await fetch(`/api/documents/${id}/export-docx`, {
        method: 'POST',
        headers,
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to export DOCX');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename.endsWith('.docx') ? filename : `${filename}.docx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
  },

  // AI
  ai: {
    generate: async (params: {
      documentType: string;
      parties?: string;
      jurisdiction?: string;
      keyTerms?: string;
    }) => {
      return request<{
        title: string;
        summary: string;
        sections: Array<{ number: number; title: string; content: string }>;
        citations?: SourceCitation[];
        legalDisclaimer?: string;
        outdatedWarnings?: OutdatedLawWarning[];
        requiresLegalReview?: boolean;
        jurisdiction?: JurisdictionInfo;
      }>('/api/ai/generate', {
        method: 'POST',
        body: JSON.stringify(params),
      });
    },
    rewrite: async (params: {
      text: string;
      tone: 'Formal' | 'Concise' | 'Protective' | 'Friendly';
      clauseTitle?: string;
      jurisdiction?: string;
    }) => {
      return request<{ rewritten: string }>('/api/ai/rewrite', {
        method: 'POST',
        body: JSON.stringify(params),
      });
    },
    chat: async (params: {
      question: string;
      documentTitle: string;
      documentSummary: string;
      jurisdiction?: string;
    }) => {
      return request<{ answer: string }>('/api/ai/chat', {
        method: 'POST',
        body: JSON.stringify(params),
      });
    },
  },

  // Legal Reference & Statutory Retrieval (India Code, Legislative Dept, e-Gazette)
  legal: {
    searchProvisions: async (params: {
      query?: string;
      country?: string;
      state?: string;
      category?: string;
      limit?: number;
    }) => {
      const searchParams = new URLSearchParams();
      if (params.query) searchParams.set('query', params.query);
      if (params.country) searchParams.set('country', params.country);
      if (params.state) searchParams.set('state', params.state);
      if (params.category) searchParams.set('category', params.category);
      if (params.limit) searchParams.set('limit', params.limit.toString());

      return request<{
        provisions: any[];
        citations: SourceCitation[];
        outdatedWarnings: OutdatedLawWarning[];
        jurisdictionApplied: { country: string; state?: string };
        legalReviewRequired: boolean;
        legalDisclaimer: string;
      }>(`/api/legal/provisions?${searchParams.toString()}`);
    },
    getProvisionById: async (id: string) => {
      return request<{ provision: any }>(`/api/legal/provisions/${id}`);
    },
    verifyText: async (params: { text: string; state?: string; country?: string }) => {
      return request<{
        outdatedWarnings: OutdatedLawWarning[];
        citations: SourceCitation[];
        requiresLegalReview: boolean;
        legalDisclaimer: string;
      }>('/api/legal/verify-text', {
        method: 'POST',
        body: JSON.stringify(params),
      });
    },
    ingestBatch: async (payload: {
      sourceAuthority: string;
      retrievalDate?: string;
      sourceDatasetDescription?: string;
      provisions: any[];
    }) => {
      return request<{
        success: boolean;
        accepted: number;
        rejected: number;
        rejectedItems: Array<{ id: string; reason: string }>;
        totalActiveProvisions: number;
      }>('/api/legal/ingest', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    },
  },

  // Billing
  billing: {
    subscribe: async (plan: 'basic' | 'pro' | 'enterprise', currency: 'USD' | 'INR' = 'USD') => {
      return request<{ success: boolean; plan: string; message: string }>('/api/billing/subscribe', {
        method: 'POST',
        body: JSON.stringify({ plan, currency }),
      });
    },
  },

  // Admin
  admin: {
    getUsers: async () => {
      return request<{ users: User[] }>('/api/admin/users');
    },
    getStats: async () => {
      return request<{
        totalUsers: number;
        totalDocuments: number;
        activeSubscriptions: number;
        recentAuditCount: number;
      }>('/api/admin/stats');
    },
    getAuditLogs: async () => {
      return request<{
        logs: Array<{
          id: string;
          userId: string;
          userEmail: string;
          action: string;
          details: string;
          timestamp: string;
        }>;
      }>('/api/admin/audit-logs');
    },
    updateUserRole: async (userId: string, role: 'user' | 'admin') => {
      return request<{ user: User; message: string }>(`/api/admin/users/${userId}/role`, {
        method: 'PATCH',
        body: JSON.stringify({ role }),
      });
    },
  },
};
