import React from 'react';
import {
  FileText,
  Download,
  Printer,
  Edit3,
  ArrowLeft,
  Shield,
  CheckCircle2,
  Calendar,
  MapPin,
  Building,
} from 'lucide-react';
import { LegalDocument } from '../../types';
import { resolveVariables, exportDocumentToPdf, exportDocumentToDocx } from '../../lib/documentExport';

interface DocumentPreviewProps {
  document: LegalDocument;
  onBack: () => void;
  onEdit: () => void;
}

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({
  document: doc,
  onBack,
  onEdit,
}) => {
  const [downloading, setDownloading] = React.useState(false);

  const handleDownloadPdf = () => {
    exportDocumentToPdf(doc);
  };

  const handleDownloadDocx = async () => {
    setDownloading(true);
    try {
      await exportDocumentToDocx(doc);
    } finally {
      setDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-100/90 py-8 px-4 sm:px-6 lg:px-8 font-sans">
      {/* Top Action Bar (hidden when printing) */}
      <div className="max-w-4xl mx-auto mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors shadow-2xs flex items-center gap-2 text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <span className="truncate max-w-[280px]">{doc.title}</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                {doc.status}
              </span>
            </h1>
            <p className="text-[11px] text-slate-500">Official Document Preview · Audited Format</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onEdit}
            className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-blue-600 text-xs font-semibold shadow-2xs flex items-center gap-1.5 transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5 text-blue-600" />
            <span>Edit Document</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>

          <button
            onClick={handleDownloadDocx}
            disabled={downloading}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>{downloading ? 'Exporting...' : 'Word (.docx)'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-slate-900 text-xs font-semibold shadow-2xs hover:bg-slate-50 transition-colors"
            title="Print Document"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sheet Container: A4 Simulation with standard margins */}
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-md border border-slate-200/90 p-8 sm:p-14 text-slate-800 leading-relaxed print:shadow-none print:border-none print:p-0 print:m-0">
        {/* Document Header & Branding */}
        <div className="border-b-2 border-slate-900 pb-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                LE
              </div>
              <span className="font-extrabold text-sm tracking-tight text-slate-900">
                Legal<span className="text-blue-600">Ease</span> Draft
              </span>
            </div>
            <div className="text-right text-[11px] text-slate-400">
              <span>REF: {doc.id}</span>
              <span className="mx-1.5">·</span>
              <span>{new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
            </div>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight text-center uppercase mb-2">
            {doc.title}
          </h2>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500 font-medium">
            <span className="flex items-center gap-1">
              <Building className="w-3.5 h-3.5 text-slate-400" />
              Category: {doc.category}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              Governing Law: Delaware Standard
            </span>
            <span>·</span>
            <span className="flex items-center gap-1 text-emerald-600 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Audited Legal Structure
            </span>
          </div>
        </div>

        {/* Variables / Key Parties Box */}
        {doc.variables && doc.variables.length > 0 && (
          <div className="mb-8 p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Key Parties & Transaction Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {doc.variables.map((v) => (
                <div key={v.id} className="flex flex-col">
                  <span className="text-[11px] text-slate-400 font-medium">{v.label}</span>
                  <span className="font-semibold text-slate-900">{v.value || v.defaultValue || '—'}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Clauses & Sections */}
        <div className="space-y-6 text-sm text-slate-700">
          {doc.sections.map((sec) => {
            const resolvedText = resolveVariables(sec.content, doc.variables);
            return (
              <div key={sec.id} className="space-y-2 break-inside-avoid">
                <h4 className="font-bold text-base text-slate-900 tracking-tight flex items-baseline gap-2">
                  <span className="text-blue-700 font-extrabold">{sec.number}.</span>
                  <span>{sec.title}</span>
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pl-5 whitespace-pre-line text-left">
                  {resolvedText}
                </p>
              </div>
            );
          })}
        </div>

        {/* Execution & Signature Section */}
        <div className="mt-12 pt-8 border-t border-slate-200 space-y-6 break-inside-avoid">
          <p className="text-xs font-semibold text-slate-700">
            IN WITNESS WHEREOF, the parties hereto have executed and delivered this Agreement through their authorized representatives as of the Effective Date.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-6">
            {/* First Party */}
            <div className="space-y-3">
              <div className="border-b border-slate-400 pb-1">
                <span className="text-xs text-slate-400 italic">Authorized Signature</span>
              </div>
              <div className="text-xs space-y-0.5">
                <p className="font-bold text-slate-900">{doc.variables[0]?.value || 'First Party Name'}</p>
                <p className="text-slate-500">Title: Authorized Representative</p>
                <p className="text-slate-400">Date: _________________________</p>
              </div>
            </div>

            {/* Second Party */}
            <div className="space-y-3">
              <div className="border-b border-slate-400 pb-1">
                <span className="text-xs text-slate-400 italic">Authorized Signature</span>
              </div>
              <div className="text-xs space-y-0.5">
                <p className="font-bold text-slate-900">{doc.variables[1]?.value || 'Second Party Name'}</p>
                <p className="text-slate-500">Title: Authorized Representative</p>
                <p className="text-slate-400">Date: _________________________</p>
              </div>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer Footer */}
        <div className="mt-12 pt-6 border-t border-slate-100 text-[10px] text-slate-400 flex items-center justify-between">
          <span>LegalEase Document Engine v2.4</span>
          <span>Informational draft for professional review. Not guaranteed legal advice.</span>
        </div>
      </div>
    </div>
  );
};
