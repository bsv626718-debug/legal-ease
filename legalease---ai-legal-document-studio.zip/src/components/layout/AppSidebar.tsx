import React from 'react';
import {
  LayoutDashboard,
  FilePlus2,
  FolderOpen,
  Files,
  Clock,
  FileEdit,
  User,
  Settings,
  CreditCard,
  LogOut,
  ChevronLeft,
  ChevronRight,
  X,
  Scale,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AppView } from './Navbar';

export type SidebarAction =
  | 'dashboard'
  | 'create-document'
  | 'templates'
  | 'my-documents'
  | 'recent-documents'
  | 'saved-drafts'
  | 'profile'
  | 'settings'
  | 'billing'
  | 'logout';

interface AppSidebarProps {
  currentView: AppView;
  activeFilter?: 'all' | 'recent' | 'drafts' | 'signed';
  activeSettingsTab?: 'profile' | 'security' | 'billing';
  onNavigate: (view: AppView, options?: { tab?: string; filter?: string }) => void;
  onCreateDocument: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  isCollapsedDesktop: boolean;
  onToggleCollapseDesktop: () => void;
}

export const AppSidebar: React.FC<AppSidebarProps> = ({
  currentView,
  activeFilter = 'all',
  activeSettingsTab = 'profile',
  onNavigate,
  onCreateDocument,
  isOpenMobile,
  onCloseMobile,
  isCollapsedDesktop,
  onToggleCollapseDesktop,
}) => {
  const { user, logout } = useAuth();

  const handleAction = async (action: SidebarAction) => {
    onCloseMobile();

    switch (action) {
      case 'dashboard':
        onNavigate('dashboard', { filter: 'all' });
        break;
      case 'create-document':
        onCreateDocument();
        break;
      case 'templates':
        onNavigate('templates');
        break;
      case 'my-documents':
        onNavigate('dashboard', { filter: 'all' });
        break;
      case 'recent-documents':
        onNavigate('dashboard', { filter: 'recent' });
        break;
      case 'saved-drafts':
        onNavigate('dashboard', { filter: 'drafts' });
        break;
      case 'profile':
        onNavigate('settings', { tab: 'profile' });
        break;
      case 'settings':
        onNavigate('settings', { tab: 'security' });
        break;
      case 'billing':
        onNavigate('settings', { tab: 'billing' });
        break;
      case 'logout':
        await logout();
        onNavigate('landing');
        break;
    }
  };

  const isItemActive = (action: SidebarAction): boolean => {
    if (action === 'dashboard') {
      return currentView === 'dashboard' && activeFilter === 'all';
    }
    if (action === 'templates') {
      return currentView === 'templates';
    }
    if (action === 'my-documents') {
      return currentView === 'dashboard' && activeFilter === 'all';
    }
    if (action === 'recent-documents') {
      return currentView === 'dashboard' && activeFilter === 'recent';
    }
    if (action === 'saved-drafts') {
      return currentView === 'dashboard' && activeFilter === 'drafts';
    }
    if (action === 'profile') {
      return currentView === 'settings' && activeSettingsTab === 'profile';
    }
    if (action === 'settings') {
      return currentView === 'settings' && activeSettingsTab === 'security';
    }
    if (action === 'billing') {
      return currentView === 'settings' && activeSettingsTab === 'billing';
    }
    return false;
  };

  const navItems: Array<{
    id: SidebarAction;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'create-document', label: 'Create Document', icon: FilePlus2, badge: 'New' },
    { id: 'templates', label: 'Templates', icon: FolderOpen },
    { id: 'my-documents', label: 'My Documents', icon: Files },
    { id: 'recent-documents', label: 'Recent Documents', icon: Clock },
    { id: 'saved-drafts', label: 'Saved Drafts', icon: FileEdit },
  ];

  const bottomItems: Array<{
    id: SidebarAction;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'billing', label: 'Billing / Subscription', icon: CreditCard },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs md:hidden animate-in fade-in duration-200"
        />
      )}

      {/* Sidebar Content */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 md:static flex flex-col justify-between bg-white border-r border-slate-200 shadow-sm transition-all duration-200 select-none ${
          isCollapsedDesktop ? 'md:w-18' : 'md:w-60'
        } ${
          isOpenMobile ? 'w-72 translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div>
          {/* Brand Logo & Close on mobile */}
          <div className="h-16 border-b border-slate-100 px-4 flex items-center justify-between">
            <div
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer overflow-hidden group"
            >
              <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shrink-0 shadow-2xs group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Scale className="w-4 h-4 stroke-[2.2]" />
              </div>
              {(!isCollapsedDesktop || isOpenMobile) && (
                <div className="flex flex-col truncate">
                  <span className="text-sm font-bold text-slate-900 tracking-tight leading-tight">
                    Legal<span className="text-blue-600">Ease</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium leading-none">
                    Smart Legal Studio
                  </span>
                </div>
              )}
            </div>

            {/* Mobile Close Button */}
            <button
              onClick={onCloseMobile}
              className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Primary Navigation */}
          <nav className="p-3 space-y-1 text-xs font-medium">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isItemActive(item.id);
              const isCreate = item.id === 'create-document';

              return (
                <button
                  key={item.id}
                  onClick={() => handleAction(item.id)}
                  title={item.label}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all text-left ${
                    isCreate
                      ? 'bg-blue-600 text-white font-semibold hover:bg-blue-700 shadow-2xs my-2'
                      : active
                      ? 'bg-blue-50/80 text-blue-700 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isCreate
                          ? 'text-white'
                          : active
                          ? 'text-blue-600'
                          : 'text-slate-400 group-hover:text-slate-600'
                      }`}
                    />
                    {(!isCollapsedDesktop || isOpenMobile) && (
                      <span className="truncate">{item.label}</span>
                    )}
                  </div>

                  {(!isCollapsedDesktop || isOpenMobile) && item.badge && !isCreate && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700 leading-none">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Section: Profile, Settings, Billing, Logout & Collapse Toggle */}
        <div className="p-3 border-t border-slate-100 space-y-1 text-xs font-medium">
          {/* User Preview */}
          {user && (!isCollapsedDesktop || isOpenMobile) && (
            <div className="px-3 py-2 mb-2 rounded-xl bg-slate-50/80 border border-slate-200/60 flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-blue-600 text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                {user.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
              </div>
              <div className="truncate">
                <p className="font-bold text-slate-900 text-xs truncate leading-tight">{user.name}</p>
                <span className="text-[10px] text-blue-600 font-semibold uppercase">{user.subscriptionPlan} Plan</span>
              </div>
            </div>
          )}

          {bottomItems.map((item) => {
            const Icon = item.icon;
            const active = isItemActive(item.id);
            return (
              <button
                key={item.id}
                onClick={() => handleAction(item.id)}
                title={item.label}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl transition-all text-left ${
                  active
                    ? 'bg-blue-50/80 text-blue-700 font-semibold shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-blue-600' : 'text-slate-400'}`} />
                {(!isCollapsedDesktop || isOpenMobile) && (
                  <span className="truncate">{item.label}</span>
                )}
              </button>
            );
          })}

          {/* Sign Out Button */}
          <button
            onClick={() => handleAction('logout')}
            title="Sign Out"
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-rose-600 hover:bg-rose-50 transition-all text-left font-semibold"
          >
            <LogOut className="w-4 h-4 shrink-0 text-rose-500" />
            {(!isCollapsedDesktop || isOpenMobile) && <span>Logout</span>}
          </button>

          {/* Desktop Collapse / Expand Button */}
          <div className="pt-2 border-t border-slate-100 hidden md:block">
            <button
              onClick={onToggleCollapseDesktop}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:text-slate-900 hover:bg-slate-50 transition-all text-left"
              title={isCollapsedDesktop ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              {isCollapsedDesktop ? (
                <ChevronRight className="w-4 h-4 shrink-0" />
              ) : (
                <>
                  <ChevronLeft className="w-4 h-4 shrink-0" />
                  <span>Collapse</span>
                </>
              )}
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
