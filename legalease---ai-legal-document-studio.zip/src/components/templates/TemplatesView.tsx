import React, { useState, useEffect } from 'react';
import {
  Search,
  Home,
  ShieldCheck,
  User,
  Briefcase,
  Users,
  FileText,
  Sparkles,
  AlertCircle,
  Clock,
  ArrowRight,
  Eye,
  Edit3,
  RefreshCw,
  FileCheck,
} from 'lucide-react';
import { templateService, TemplateSummary } from '../../services/templateService';

interface TemplatesViewProps {
  onSelectTemplate: (templateId: string, title: string) => void;
  onEditTemplate: (templateId: string, title: string) => void;
  onPreviewTemplate: (templateId: string) => void;
  onOpenLeaseWizard: () => void;
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({
  onSelectTemplate,
  onEditTemplate,
  onPreviewTemplate,
  onOpenLeaseWizard,
}) => {
  const [templates, setTemplates] = useState<TemplateSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Property',
    'Business',
    'Personal',
    'Employment',
    'Freelancers',
    'Legal Letters',
  ];

  const fetchTemplates = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await templateService.getTemplates();
      setTemplates(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load templates. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Home':
        return Home;
      case 'ShieldCheck':
        return ShieldCheck;
      case 'User':
        return User;
      case 'Briefcase':
        return Briefcase;
      case 'Users':
        return Users;
      case 'FileText':
        return FileText;
      case 'AlertCircle':
        return AlertCircle;
      default:
        return Sparkles;
    }
  };

  const filteredTemplates = templates.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 font-sans">
      {/* Title & Description */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 block mb-1">
            LEGAL TEMPLATE LIBRARY
          </span>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Verified Legal Document Templates
          </h1>
          <p className="text-sm text-slate-500 mt-2">
            Curated and legally audited contract templates customized for your jurisdiction and business requirements.
          </p>
        </div>

        <button
          onClick={fetchTemplates}
          className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors self-start md:self-auto flex items-center gap-1.5 text-xs font-medium"
          title="Refresh Template Catalog"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Filter Bar & Search */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100/80 p-1.5 rounded-xl border border-slate-200/80">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedCategory === cat
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search templates, clauses..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Error state with Retry button */}
      {error && (
        <div className="p-6 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <div>
              <p className="font-bold text-sm">Failed to Load Templates</p>
              <p className="text-xs text-rose-600 mt-0.5">{error}</p>
            </div>
          </div>
          <button
            onClick={fetchTemplates}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0"
          >
            Retry Loading
          </button>
        </div>
      )}

      {/* Loading Skeleton */}
      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-white rounded-2xl p-6 border border-slate-200 animate-pulse space-y-4">
              <div className="flex justify-between items-center">
                <div className="w-12 h-12 bg-slate-100 rounded-xl" />
                <div className="w-16 h-5 bg-slate-100 rounded-full" />
              </div>
              <div className="h-4 bg-slate-100 rounded w-20" />
              <div className="h-6 bg-slate-100 rounded w-48" />
              <div className="h-12 bg-slate-100 rounded w-full" />
              <div className="h-8 bg-slate-100 rounded w-full pt-2" />
            </div>
          ))}
        </div>
      )}

      {/* Templates Grid */}
      {!loading && !error && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.length === 0 ? (
            <div className="col-span-full py-16 text-center text-slate-400 space-y-2">
              <FileCheck className="w-10 h-10 mx-auto text-slate-300" />
              <p className="text-sm font-semibold text-slate-700">No matching templates found</p>
              <p className="text-xs text-slate-400">Try adjusting your search query or selected category.</p>
            </div>
          ) : (
            filteredTemplates.map((template) => {
              const Icon = getIcon(template.icon);
              const isRental = template.id === 'rental-agreement';

              return (
                <div
                  key={template.id}
                  className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between group"
                >
                  <div>
                    {/* Header with Icon & Time Estimate */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <Icon className="w-6 h-6 stroke-[2]" />
                      </div>
                      <span className="text-[11px] font-semibold text-slate-400 bg-slate-50 border border-slate-200/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {template.timeEst}
                      </span>
                    </div>

                    <div className="mb-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 block mb-1">
                        {template.category}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                        {template.title}
                      </h3>
                    </div>

                    <p className="text-xs text-slate-500 leading-relaxed mb-6">
                      {template.description}
                    </p>
                  </div>

                  {/* Actions Bar */}
                  <div className="pt-4 border-t border-slate-100 space-y-3">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="truncate max-w-[180px]">{template.jurisdiction}</span>
                      <span className="font-semibold text-emerald-600 flex items-center gap-1">
                        Audited
                      </span>
                    </div>

                    {/* Interactive Action Buttons */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => onPreviewTemplate(template.id)}
                        className="flex-1 py-2 px-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                        title="Preview Document Layout"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-400" />
                        <span>Preview</span>
                      </button>

                      <button
                        onClick={() => {
                          onEditTemplate(template.id, template.title);
                        }}
                        className="flex-1 py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                        title="Open and Edit Template"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>

                      {isRental && (
                        <button
                          onClick={onOpenLeaseWizard}
                          className="py-2 px-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-semibold flex items-center justify-center transition-colors cursor-pointer shadow-2xs"
                          title="Open Step-by-Step Lease Wizard"
                        >
                          Wizard
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
