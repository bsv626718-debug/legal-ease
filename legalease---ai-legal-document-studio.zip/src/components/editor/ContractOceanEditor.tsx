import React, { useState, useRef } from 'react';
import {
  LayoutDashboard,
  FileText,
  FolderOpen,
  Sparkles,
  Users,
  BarChart3,
  CreditCard,
  Settings,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
  Clock,
  Target,
  Bold,
  Italic,
  Underline,
  Check,
  CheckCircle2,
  Circle,
  Eye,
  Download,
  Send,
  Plus,
  ShieldAlert,
  AlertTriangle,
  Scale,
  RefreshCw,
  MessageSquare,
  Hash,
  X,
  ExternalLink,
  Save,
} from 'lucide-react';
import { LegalDocument, AISuggestion, DocumentVariable } from '../../types';
import { initialMasterServiceAgreement } from '../../data/mockData';
import { api } from '../../lib/api';
import { templateService } from '../../services/templateService';
import { exportDocumentToPdf, exportDocumentToDocx } from '../../lib/documentExport';

interface ContractOceanEditorProps {
  onBack: () => void;
  onOpenExport: (doc: LegalDocument) => void;
  onOpenSignature: (doc: LegalDocument) => void;
  docId?: string;
  templateId?: string;
  onNavigateToTab?: (tab: 'dashboard' | 'templates' | 'settings') => void;
  onOpenPreview?: (doc: LegalDocument) => void;
}

export const ContractOceanEditor: React.FC<ContractOceanEditorProps> = ({
  onBack,
  onOpenExport,
  onOpenSignature,
  docId,
  templateId,
  onNavigateToTab,
  onOpenPreview,
}) => {
  const [doc, setDoc] = useState<LegalDocument>(initialMasterServiceAgreement);
  const [activeSectionId, setActiveSectionId] = useState<string>('sec-1');
  const [activeRightTab, setActiveRightTab] = useState<'ai' | 'variables' | 'comments'>('ai');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string>('Saved 2 min ago');
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Load document or template
  const loadData = async () => {
    setIsLoading(true);
    setLoadError(null);
    try {
      if (docId) {
        const res = await api.documents.getById(docId);
        if (res.document) {
          setDoc(res.document);
          setDocTitle(res.document.title);
          setActiveSectionId(res.document.sections?.[0]?.id || 'sec-1');
        }
      } else if (templateId) {
        const t = await templateService.getTemplateById(templateId);
        const instantiated: LegalDocument = {
          id: `draft-${t.id}-${Date.now()}`,
          title: t.title,
          category: t.category,
          status: 'Draft',
          lastSaved: 'Just now',
          collaborators: [
            { name: 'You (Editor)', initials: 'ME', role: 'Author', avatarColor: 'bg-blue-600' },
          ],
          variables: t.variables,
          sections: t.sections,
          suggestions: t.suggestions,
          comments: [],
          readiness: t.readiness,
        };
        setDoc(instantiated);
        setDocTitle(t.title);
        setActiveSectionId(t.sections?.[0]?.id || 'sec-1');
      }
    } catch (err: any) {
      setLoadError(err.message || 'Failed to retrieve document or template.');
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    loadData();
  }, [docId, templateId]);

  const handleSaveDocument = async () => {
    setIsSaving(true);
    try {
      if (doc.id && !doc.id.startsWith('draft-')) {
        const res = await api.documents.update(doc.id, {
          ...doc,
          title: docTitle,
        });
        setDoc(res.document);
      } else {
        const res = await api.documents.create({
          ...doc,
          title: docTitle,
        });
        setDoc(res.document);
      }
      setSaveStatus('Saved just now');
      showToast('Document saved successfully to your vault!');
    } catch (err: any) {
      showToast(err.message || 'Failed to save document. Please sign in.');
    } finally {
      setIsSaving(false);
    }
  };

  // Interactive editing state
  const [editingTitle, setEditingTitle] = useState(false);
  const [docTitle, setDocTitle] = useState(doc.title);
  const [selectedVariable, setSelectedVariable] = useState<DocumentVariable | null>(null);

  // AI Chat state
  const [aiChatPrompt, setAiChatPrompt] = useState('');
  const [aiChatHistory, setAiChatHistory] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: 'Hello! I\'ve reviewed your Master Service Agreement. The agreement is in good shape (72% readiness coverage). You have 2 missing variables and can enhance GDPR compliance and liability protections.',
    },
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New comment input
  const [newCommentText, setNewCommentText] = useState('');

  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Scroll to section when clicked in outline
  const handleScrollToSection = (secId: string) => {
    setActiveSectionId(secId);
    const el = sectionRefs.current[secId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Update a variable value across document
  const handleUpdateVariable = (id: string, newValue: string) => {
    setDoc((prev) => {
      const updatedVars = prev.variables.map((v) => (v.id === id ? { ...v, value: newValue } : v));
      // update readiness
      const allFilled = updatedVars.every((v) => v.value.trim().length > 0);
      const updatedReadiness = {
        ...prev.readiness,
        completed: allFilled ? 6 : 5,
        items: prev.readiness.items.map((item) =>
          item.label === 'All variables filled' ? { ...item, done: allFilled } : item
        ),
      };
      return {
        ...prev,
        variables: updatedVars,
        readiness: updatedReadiness,
      };
    });
    setSaveStatus('Saved just now');
    showToast(`Updated variable: "${newValue}"`);
  };

  // Apply suggestion
  const handleApplySuggestion = (sug: AISuggestion) => {
    if (sug.type === 'gdpr' && sug.clauseToAdd) {
      setDoc((prev) => ({
        ...prev,
        sections: [
          ...prev.sections,
          {
            id: 'sec-gdpr',
            number: prev.sections.length + 1,
            title: 'Data Protection & GDPR',
            content: sug.clauseToAdd!,
          },
        ],
        suggestions: prev.suggestions.filter((s) => s.id !== sug.id),
      }));
      showToast('Added GDPR Data Protection clause to document');
    } else if (sug.type === 'liability' && sug.clauseToAdd) {
      setDoc((prev) => ({
        ...prev,
        sections: prev.sections.map((s) =>
          s.number === 8 ? { ...s, content: sug.clauseToAdd! } : s
        ),
        suggestions: prev.suggestions.filter((s) => s.id !== sug.id),
      }));
      showToast('Updated Section 8: Strengthened Liability Cap');
    } else if (sug.type === 'dispute' && sug.clauseToAdd) {
      setDoc((prev) => ({
        ...prev,
        sections: [
          ...prev.sections,
          {
            id: 'sec-arbitration',
            number: prev.sections.length + 1,
            title: 'Dispute Resolution & Arbitration',
            content: sug.clauseToAdd!,
          },
        ],
        suggestions: prev.suggestions.filter((s) => s.id !== sug.id),
      }));
      showToast('Added Binding Arbitration Dispute Resolution clause');
    } else if (sug.type === 'confidentiality' && sug.clauseToAdd) {
      setDoc((prev) => ({
        ...prev,
        sections: prev.sections.map((s) =>
          s.number === 5 ? { ...s, content: sug.clauseToAdd! } : s
        ),
        suggestions: prev.suggestions.filter((s) => s.id !== sug.id),
      }));
      showToast('Updated Section 5: Extended confidentiality to 7 years');
    }
  };

  // Quick Rewrite tone adjustment
  const handleQuickRewrite = (tone: 'Formal' | 'Concise' | 'Protective' | 'Friendly') => {
    setIsAiLoading(true);
    setTimeout(() => {
      setDoc((prev) => {
        const activeSec = prev.sections.find((s) => s.id === activeSectionId) || prev.sections[0];
        let transformedText = activeSec.content;
        if (tone === 'Concise') {
          transformedText = transformedText
            .replace('agrees to provide professional consulting, software development, and related technology services as described in each Statement of Work ("SOW")', 'agrees to perform services per executed SOWs')
            .replace('Each Party represents and warrants that it has full authority to enter into and perform its obligations under this Agreement.', 'Both Parties warrant authorized corporate authority.');
        } else if (tone === 'Protective') {
          transformedText = transformedText + ' Neither party warrants any fitness for a particular purpose, and indemnity shall remain strictly subject to explicit reciprocal notice within 10 calendar days.';
        } else if (tone === 'Formal') {
          transformedText = 'IN WITNESS WHEREOF, the undersigned entities covenant as follows: ' + transformedText;
        } else {
          transformedText = transformedText.replace(/shall/g, 'will').replace(/herein/g, 'in this agreement');
        }

        return {
          ...prev,
          sections: prev.sections.map((s) => (s.id === activeSec.id ? { ...s, content: transformedText } : s)),
        };
      });
      setIsAiLoading(false);
      showToast(`Rewrote section in "${tone}" legal tone.`);
    }, 600);
  };

  // AI Chat submission
  const handleSendAiChat = (customText?: string) => {
    const textToSend = customText || aiChatPrompt;
    if (!textToSend.trim()) return;

    setAiChatHistory((prev) => [...prev, { role: 'user', text: textToSend }]);
    setAiChatPrompt('');
    setIsAiLoading(true);

    setTimeout(() => {
      let reply = '';
      const lower = textToSend.toLowerCase();
      if (lower.includes('california') || lower.includes('enforceable')) {
        reply =
          'Under California law, non-compete clauses are generally void under Business and Professions Code §16600. However, this Master Service Agreement primarily relies on IP ownership, confidentiality, and milestone deliverables, which are fully enforceable in California when supported by adequate consideration.';
      } else if (lower.includes('payment') || lower.includes('terms') || lower.includes('fees')) {
        reply =
          'Payment terms in Section 4 are Net 30 days from invoice date. Late payments accrue interest at 1.5% per month or the highest statutory rate. All deliverables have a 15-day inspection window before acceptance.';
      } else if (lower.includes('liability')) {
        reply =
          'Section 8 currently limits aggregate liability to fees paid in the prior 12 months. Recommendation: Verify whether gross negligence or data breach indemnification should be explicitly carved out.';
      } else {
        reply = `Analysis for "${textToSend}": The clause aligns with standard commercial contracting practices under Delaware law. Both mutual warranties and IP assignment work product standards are met.`;
      }

      setAiChatHistory((prev) => [...prev, { role: 'assistant', text: reply }]);
      setIsAiLoading(false);
    }, 800);
  };

  // Add Comment
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;
    const newComment = {
      id: `c-${Date.now()}`,
      author: 'You (Editor)',
      initials: 'ME',
      avatarColor: 'bg-emerald-600',
      text: newCommentText.trim(),
      timestamp: 'Just now',
    };
    setDoc((prev) => ({
      ...prev,
      comments: [newComment, ...prev.comments],
    }));
    setNewCommentText('');
    showToast('Comment posted for review team.');
  };

  // Helper to render text with clickable variable chips
  const renderTextWithVariables = (text: string) => {
    // replace {{Key}} or highlighted keywords
    let formattedText = text;
    doc.variables.forEach((v) => {
      formattedText = formattedText.replace(
        new RegExp(`{{${v.key}}}`, 'g'),
        `__VAR_${v.id}__`
      );
    });

    const parts = formattedText.split(/(__VAR_[^_]+__)/g);

    return parts.map((part, index) => {
      if (part.startsWith('__VAR_') && part.endsWith('__')) {
        const varId = part.replace('__VAR_', '').replace('__', '');
        const variable = doc.variables.find((v) => v.id === varId);
        if (variable) {
          return (
            <span
              key={index}
              onClick={() => {
                setSelectedVariable(variable);
                setActiveRightTab('variables');
              }}
              title={`Click to edit variable: ${variable.label}`}
              className="inline-block px-2 py-0.5 mx-1 text-xs font-semibold rounded bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors cursor-pointer border border-blue-200 shadow-2xs"
            >
              {variable.value || `[${variable.label}]`}
            </span>
          );
        }
      }
      return <span key={index}>{part}</span>;
    });
  };

  return (
    <div className="flex h-screen w-full bg-slate-100 overflow-hidden font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700 text-xs font-medium flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Left Primary Navigation Sidebar (Contract Ocean Workspace - Image 1 exact) */}
      <aside
        className={`${
          isSidebarCollapsed ? 'w-16' : 'w-56'
        } bg-white border-r border-slate-200 flex flex-col justify-between transition-all duration-200 shrink-0 select-none z-20`}
      >
        <div>
          {/* Brand Header */}
          <div className="h-16 border-b border-slate-100 px-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <FileText className="w-4 h-4 stroke-[2.5]" />
              </div>
              {!isSidebarCollapsed && (
                <div className="flex flex-col truncate">
                  <span className="text-sm font-bold text-slate-900 tracking-tight leading-tight">
                    Contract Ocean
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium leading-none">
                    Workspace
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Menu Items */}
          <nav className="p-3 space-y-1 text-xs font-medium text-slate-600">
            <button
              onClick={() => (onNavigateToTab ? onNavigateToTab('dashboard') : onBack())}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors text-left"
            >
              <LayoutDashboard className="w-4 h-4 text-slate-400" />
              {!isSidebarCollapsed && <span>Dashboard</span>}
            </button>

            <button
              onClick={() => (onNavigateToTab ? onNavigateToTab('dashboard') : onBack())}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg bg-blue-50/70 text-blue-700 font-semibold transition-colors text-left"
            >
              <FileText className="w-4 h-4 text-blue-600" />
              {!isSidebarCollapsed && <span>Contracts</span>}
            </button>

            <button
              onClick={() => (onNavigateToTab ? onNavigateToTab('templates') : onBack())}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors text-left"
            >
              <FolderOpen className="w-4 h-4 text-slate-400" />
              {!isSidebarCollapsed && <span>Templates</span>}
            </button>

            <button
              onClick={() => setActiveRightTab('ai')}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-purple-600" />
                {!isSidebarCollapsed && <span>AI Generator</span>}
              </div>
              {!isSidebarCollapsed && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-600 text-white leading-none">
                  AI
                </span>
              )}
            </button>
          </nav>
        </div>

        {/* Bottom Menu Items */}
        <div className="p-3 border-t border-slate-100 space-y-1 text-xs font-medium text-slate-600">
          <button
            onClick={() => (onNavigateToTab ? onNavigateToTab('settings') : onBack())}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors text-left"
          >
            <CreditCard className="w-4 h-4 text-slate-400" />
            {!isSidebarCollapsed && <span>Billing</span>}
          </button>
          <button
            onClick={() => (onNavigateToTab ? onNavigateToTab('settings') : onBack())}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors text-left"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            {!isSidebarCollapsed && <span>Settings</span>}
          </button>
          <button
            onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-400 hover:text-slate-900 transition-colors text-left"
          >
            {isSidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <>
                <ChevronLeft className="w-4 h-4" />
                <span>Collapse</span>
              </>
            )}
          </button>
        </div>
      </aside>

      {/* 2. Document Outline Sub-Sidebar (Image 1 exact outline & readiness) */}
      <aside className="w-64 bg-slate-50/80 border-r border-slate-200 hidden lg:flex flex-col justify-between shrink-0 select-none z-10">
        <div className="p-4 overflow-y-auto">
          {/* Outline Header */}
          <div className="flex items-center justify-between mb-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>DOCUMENT OUTLINE</span>
            <span className="text-[10px] text-slate-400 font-normal">8 Sections</span>
          </div>

          {/* Section Items */}
          <div className="space-y-1">
            {doc.sections.map((sec) => {
              const isActive = activeSectionId === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => handleScrollToSection(sec.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-all text-left group ${
                    isActive
                      ? 'bg-blue-100/70 text-blue-900 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded flex items-center justify-center text-[11px] font-semibold shrink-0 transition-colors ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-200/80 text-slate-600 group-hover:bg-slate-300'
                    }`}
                  >
                    {sec.number}
                  </span>
                  <span className="truncate">{sec.title}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Readiness Checklist Card (Image 1 exact 5/7 with checklist) */}
        <div className="p-4 border-t border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              READINESS
            </span>
            <span className="text-xs font-bold text-slate-800">
              {doc.readiness.completed}/{doc.readiness.total}
            </span>
          </div>

          {/* Readiness Progress Bar */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mb-3.5">
            <div
              className="bg-blue-600 h-full rounded-full transition-all duration-500"
              style={{
                width: `${(doc.readiness.completed / doc.readiness.total) * 100}%`,
              }}
            />
          </div>

          {/* Checklist */}
          <div className="space-y-2 text-[11px]">
            {doc.readiness.items.map((item, idx) => (
              <div
                key={idx}
                className={`flex items-center gap-2 ${
                  item.done ? 'text-slate-600' : 'text-slate-400'
                }`}
              >
                {item.done ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                )}
                <span className={item.done ? '' : 'italic'}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* 3. Center Document Editor Canvas Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-100/70 overflow-hidden">
        {/* Top Header Toolbar (Image 1 exact match) */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between shrink-0 shadow-2xs z-10">
          {/* Left: Back button, Title, Status Badges */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={onBack}
              title="Return to Workspace"
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            {/* Editable Title */}
            {editingTitle ? (
              <input
                type="text"
                value={docTitle}
                onChange={(e) => setDocTitle(e.target.value)}
                onBlur={() => {
                  setEditingTitle(false);
                  setDoc((prev) => ({ ...prev, title: docTitle }));
                  setSaveStatus('Saved just now');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setEditingTitle(false);
                    setDoc((prev) => ({ ...prev, title: docTitle }));
                    setSaveStatus('Saved just now');
                  }
                }}
                autoFocus
                className="text-base sm:text-lg font-bold text-slate-900 border-b border-blue-500 focus:outline-none px-1"
              />
            ) : (
              <h2
                onClick={() => setEditingTitle(true)}
                title="Click to rename document"
                className="text-base sm:text-lg font-bold text-slate-900 truncate hover:text-blue-600 cursor-pointer"
              >
                {doc.title}
              </h2>
            )}

            {/* Status Pills */}
            <div className="hidden sm:flex items-center gap-2 shrink-0">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-700 text-xs font-semibold">
                Draft
              </span>

              <span className="px-2.5 py-0.5 rounded-full bg-amber-50/80 border border-amber-200/80 text-amber-800 text-[11px] font-medium flex items-center gap-1">
                <Clock className="w-3 h-3 text-amber-600" />
                2 items remaining
              </span>

              <span className="px-2.5 py-0.5 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-[11px] font-medium flex items-center gap-1">
                <Target className="w-3 h-3 text-rose-600" />
                2 missing fields
              </span>
            </div>

            {/* Basic Text Formatting Actions */}
            <div className="hidden md:flex items-center border-l border-slate-200 pl-3 ml-1 gap-1 text-slate-600">
              <button
                onClick={() => showToast('Text set to bold')}
                className="p-1.5 rounded hover:bg-slate-100 hover:text-slate-900"
                title="Bold"
              >
                <Bold className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => showToast('Text set to italic')}
                className="p-1.5 rounded hover:bg-slate-100 hover:text-slate-900"
                title="Italic"
              >
                <Italic className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => showToast('Text underlined')}
                className="p-1.5 rounded hover:bg-slate-100 hover:text-slate-900"
                title="Underline"
              >
                <Underline className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Saved Indicator */}
            <div className="hidden xl:flex items-center gap-1 text-xs text-slate-400 pl-2">
              <Check className="w-3.5 h-3.5 text-emerald-500" />
              <span>{saveStatus}</span>
            </div>
          </div>

          {/* Right: Collaborator Avatars & Actions */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Avatars */}
            <div className="hidden md:flex items-center -space-x-1.5">
              <div
                title="Sarah Chen (Admin)"
                className="w-7 h-7 rounded-full bg-blue-600 text-white text-[11px] font-bold flex items-center justify-center ring-2 ring-white shadow-2xs"
              >
                SC
              </div>
              <div
                title="John O'Connor (Counsel)"
                className="w-7 h-7 rounded-full bg-amber-600 text-white text-[11px] font-bold flex items-center justify-center ring-2 ring-white shadow-2xs"
              >
                JO
              </div>
              <button
                onClick={() => showToast('Invited new reviewer to document')}
                title="Add collaborator"
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-medium flex items-center justify-center ring-2 ring-white transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Save Button */}
            <button
              onClick={handleSaveDocument}
              disabled={isSaving}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Save document changes"
            >
              <Save className={`w-3.5 h-3.5 ${isSaving ? 'animate-spin' : ''}`} />
              <span>{isSaving ? 'Saving...' : 'Save'}</span>
            </button>

            {/* Preview Button */}
            <button
              onClick={() => {
                if (onOpenPreview) {
                  onOpenPreview(doc);
                } else {
                  onOpenExport(doc);
                }
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-slate-500" />
              <span>Preview</span>
            </button>

            {/* Export Button */}
            <button
              onClick={() => onOpenExport(doc)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export</span>
            </button>

            {/* Send for Signature Button (Image 1 primary action) */}
            <button
              onClick={() => onOpenSignature(doc)}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm hover:shadow flex items-center gap-2 transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send for Signature</span>
            </button>
          </div>
        </header>

        {/* Scrollable Document Body Canvas */}
        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-4">
            <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
            <p className="text-sm font-semibold text-slate-700">Loading document template & variables...</p>
          </div>
        ) : loadError ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-4 max-w-md mx-auto text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Document Could Not Be Loaded</h3>
            <p className="text-xs text-slate-500 leading-relaxed">{loadError}</p>
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={loadData}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
              >
                Retry
              </button>
              <button
                onClick={onBack}
                className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
              >
                Back to Catalog
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex justify-center">
            {/* Printable White Paper Document */}
            <div className="document-sheet printable-document bg-white w-full max-w-[850px] min-h-[1100px] p-8 sm:p-14 rounded-xl shadow-lg border border-slate-200/80 text-slate-800 space-y-7 transition-all">
              {/* Header Title */}
              <div className="text-center pb-4 border-b border-slate-100">
                <h1 className="text-xl sm:text-2xl font-extrabold uppercase tracking-wider text-slate-900 mb-3">
                  {doc.title}
                </h1>
                <p className="text-xs text-slate-400">
                  Document ID: {doc.id} · Category: {doc.category} · Status: {doc.status}
                </p>
              </div>

              {/* Dynamic Variables Chips Summary Banner */}
              {doc.variables && doc.variables.length > 0 && (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                    TRANSACTION VARIABLES (CLICK TO EDIT)
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {doc.variables.map((v) => (
                      <span
                        key={v.id}
                        onClick={() => {
                          setSelectedVariable(v);
                          setActiveRightTab('variables');
                        }}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold cursor-pointer border border-blue-200/80 transition-colors shadow-2xs"
                      >
                        <span className="text-slate-400 font-normal">{v.label}:</span>
                        <span>{v.value || `[${v.defaultValue}]`}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Document Sections */}
              <div className="space-y-6">
                {doc.sections.map((sec) => (
                  <div
                    key={sec.id}
                    ref={(el) => {
                      sectionRefs.current[sec.id] = el;
                    }}
                    onClick={() => setActiveSectionId(sec.id)}
                    className={`p-3 -mx-3 rounded-lg transition-colors cursor-text ${
                      activeSectionId === sec.id
                        ? 'bg-blue-50/40 ring-1 ring-blue-200/60'
                        : 'hover:bg-slate-50/60'
                    }`}
                  >
                    <h3 className="text-sm font-bold text-slate-900 mb-2">
                      {sec.number}. {sec.title}
                    </h3>
                    <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                      {renderTextWithVariables(sec.content)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Dynamic Signature Blocks */}
              <div className="pt-10 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs text-slate-700">
                <div>
                  <p className="font-bold text-slate-900 mb-1 uppercase">
                    {doc.variables[0]?.label || 'FIRST PARTY'}:
                  </p>
                  <p className="font-semibold text-slate-800">{doc.variables[0]?.value || doc.variables[1]?.value || 'First Party'}</p>
                  <div className="mt-8 border-b border-slate-300 w-48 pb-1 text-slate-400 italic">
                    Authorized Signature
                  </div>
                  <p className="mt-2 text-[11px] text-slate-500">Name: {doc.variables[0]?.value || 'Authorized Signatory'}</p>
                  <p className="text-[11px] text-slate-500">Title: Authorized Representative</p>
                  <p className="text-[11px] text-slate-500">Date: {new Date().toLocaleDateString()}</p>
                </div>

                <div>
                  <p className="font-bold text-slate-900 mb-1 uppercase">
                    {doc.variables[1]?.label || 'SECOND PARTY'}:
                  </p>
                  <p className="font-semibold text-slate-800">{doc.variables[1]?.value || doc.variables[2]?.value || 'Second Party'}</p>
                  <div className="mt-8 border-b border-slate-300 w-48 pb-1 text-slate-400 italic">
                    Authorized Signature
                  </div>
                  <p className="mt-2 text-[11px] text-slate-500">Name: {doc.variables[1]?.value || 'Authorized Signatory'}</p>
                  <p className="text-[11px] text-slate-500">Title: Authorized Representative</p>
                  <p className="text-[11px] text-slate-500">Date: {new Date().toLocaleDateString()}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* 4. Right AI Assistant & Inspector Sidebar (Image 1 exact tabs, suggestions, quick rewrite, chat) */}
      <aside className="w-80 sm:w-96 bg-white border-l border-slate-200 flex flex-col justify-between shrink-0 select-none z-10 shadow-sm">
        {/* Top Tab Bar: AI, Variables (2), Comments (2) */}
        <div>
          <div className="h-14 border-b border-slate-200 px-4 flex items-center justify-between text-xs font-semibold">
            <button
              onClick={() => setActiveRightTab('ai')}
              className={`flex items-center gap-1.5 py-3 relative transition-colors ${
                activeRightTab === 'ai' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>AI</span>
              {activeRightTab === 'ai' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
              )}
            </button>

            <button
              onClick={() => setActiveRightTab('variables')}
              className={`flex items-center gap-1.5 py-3 relative transition-colors ${
                activeRightTab === 'variables' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <span>(x) Variables</span>
              <span className="px-1.5 py-0.2 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold">
                {doc.variables.length}
              </span>
              {activeRightTab === 'variables' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
              )}
            </button>

            <button
              onClick={() => setActiveRightTab('comments')}
              className={`flex items-center gap-1.5 py-3 relative transition-colors ${
                activeRightTab === 'comments' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <span>Comments</span>
              <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700 text-[10px] font-bold">
                {doc.comments.length}
              </span>
              {activeRightTab === 'comments' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
              )}
            </button>
          </div>

          {/* TAB 1: AI Assistant (Image 1 exact layout) */}
          {activeRightTab === 'ai' && (
            <div className="p-4 overflow-y-auto max-h-[calc(100vh-220px)] space-y-5">
              {/* Contract AI Assistant Card with Gradient Header */}
              <div className="rounded-xl bg-linear-to-br from-indigo-900 via-blue-900 to-slate-900 text-white p-4 shadow-md">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-blue-500/30 flex items-center justify-center text-blue-300">
                      <Sparkles className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold">Contract AI Assistant</span>
                  </div>
                  <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800/40">
                    Live
                  </span>
                </div>
                <p className="text-[11px] text-blue-200 mb-3">
                  Analyzing your agreement in real-time
                </p>
                <div className="flex items-center justify-between text-[11px] text-blue-200 mb-1">
                  <span>Coverage</span>
                  <span className="font-bold text-white">72% coverage</span>
                </div>
                <div className="w-full bg-blue-950 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blue-400 h-full rounded-full" style={{ width: '72%' }} />
                </div>
              </div>

              {/* Suggestions (4) with border colors (Image 1 exact match) */}
              <div>
                <div className="flex items-center justify-between mb-2 text-xs font-bold text-slate-800">
                  <span>SUGGESTIONS ({doc.suggestions.length})</span>
                  <span className="text-[10px] text-blue-600 font-semibold cursor-pointer hover:underline">
                    Re-analyze
                  </span>
                </div>

                <div className="space-y-2.5">
                  {doc.suggestions.map((sug) => {
                    const borderColors = {
                      red: 'border-l-rose-500',
                      yellow: 'border-l-amber-500',
                      blue: 'border-l-blue-500',
                      purple: 'border-l-purple-500',
                      green: 'border-l-emerald-500',
                    };

                    return (
                      <div
                        key={sug.id}
                        className={`p-3 bg-white rounded-xl border border-slate-200/80 border-l-4 ${
                          borderColors[sug.color]
                        } shadow-2xs hover:shadow-xs transition-all`}
                      >
                        <p className="text-xs font-medium text-slate-800 leading-snug mb-2">
                          {sug.title}
                        </p>
                        <button
                          onClick={() => handleApplySuggestion(sug)}
                          className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 group cursor-pointer"
                        >
                          <span>{sug.actionText}</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* QUICK REWRITE Section (Image 1 exact) */}
              <div>
                <span className="text-xs font-bold text-slate-800 block mb-1">QUICK REWRITE</span>
                <p className="text-[11px] text-slate-500 mb-3">
                  Select text in the document, then choose a tone:
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    disabled={isAiLoading}
                    onClick={() => handleQuickRewrite('Formal')}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 hover:border-slate-300 font-medium text-slate-700 text-center transition-all disabled:opacity-50"
                  >
                    More Formal
                  </button>
                  <button
                    disabled={isAiLoading}
                    onClick={() => handleQuickRewrite('Concise')}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 hover:border-slate-300 font-medium text-slate-700 text-center transition-all disabled:opacity-50"
                  >
                    More Concise
                  </button>
                  <button
                    disabled={isAiLoading}
                    onClick={() => handleQuickRewrite('Protective')}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 hover:border-slate-300 font-medium text-slate-700 text-center transition-all disabled:opacity-50"
                  >
                    More Protective
                  </button>
                  <button
                    disabled={isAiLoading}
                    onClick={() => handleQuickRewrite('Friendly')}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 hover:border-slate-300 font-medium text-slate-700 text-center transition-all disabled:opacity-50"
                  >
                    More Friendly
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Variables List */}
          {activeRightTab === 'variables' && (
            <div className="p-4 overflow-y-auto max-h-[calc(100vh-220px)] space-y-4">
              <div className="text-xs font-bold text-slate-800 mb-1">
                DOCUMENT VARIABLES ({doc.variables.length})
              </div>
              <p className="text-[11px] text-slate-500 mb-3">
                Values updated here instantly synchronize across all paragraphs and signature blocks.
              </p>

              <div className="space-y-3">
                {doc.variables.map((variable) => (
                  <div
                    key={variable.id}
                    className={`p-3 rounded-xl border text-xs transition-all ${
                      selectedVariable?.id === variable.id
                        ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-500/20'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <label className="font-bold text-slate-800 block mb-1">
                      {variable.label}
                    </label>
                    <input
                      type="text"
                      value={variable.value}
                      onChange={(e) => handleUpdateVariable(variable.id, e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Comments */}
          {activeRightTab === 'comments' && (
            <div className="p-4 overflow-y-auto max-h-[calc(100vh-220px)] space-y-4">
              <div className="text-xs font-bold text-slate-800 mb-1">
                REVIEW COMMENTS ({doc.comments.length})
              </div>

              {/* Add Comment Form */}
              <form onSubmit={handleAddComment} className="space-y-2">
                <textarea
                  value={newCommentText}
                  onChange={(e) => setNewCommentText(e.target.value)}
                  placeholder="Leave a comment or legal note..."
                  rows={2}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
                />
                <button
                  type="submit"
                  className="w-full py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold"
                >
                  Post Comment
                </button>
              </form>

              {/* Comments Stream */}
              <div className="space-y-3 pt-2">
                {doc.comments.map((comment) => (
                  <div key={comment.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-full ${comment.avatarColor} text-white font-bold text-[10px] flex items-center justify-center`}
                        >
                          {comment.initials}
                        </div>
                        <span className="font-bold text-slate-800">{comment.author}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">{comment.timestamp}</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed text-[11px]">{comment.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Interactive AI Chat & Prompt Bar (Image 1 exact match) */}
        <div className="p-4 border-t border-slate-200 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendAiChat();
            }}
            className="relative mb-2"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={aiChatPrompt}
              onChange={(e) => setAiChatPrompt(e.target.value)}
              placeholder="Ask AI about this contract..."
              className="w-full pl-8 pr-9 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-slate-400"
            />
            <button
              type="submit"
              disabled={isAiLoading || !aiChatPrompt.trim()}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white flex items-center justify-center transition-all cursor-pointer"
            >
              <Send className="w-3 h-3" />
            </button>
          </form>

          {/* Quick Prompt Suggestions */}
          <div className="text-[10px] text-slate-400 flex flex-wrap gap-1 items-center">
            <span>Try:</span>
            <button
              onClick={() => handleSendAiChat('Is this enforceable in California?')}
              className="text-blue-600 hover:underline"
            >
              &ldquo;Is this enforceable in California?&rdquo;
            </button>
            <span>or</span>
            <button
              onClick={() => handleSendAiChat('Summarize payment terms')}
              className="text-blue-600 hover:underline"
            >
              &ldquo;Summarize payment terms&rdquo;
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
