import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Plus,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Download,
  Eye,
  Trash2,
  RefreshCw,
  FolderOpen,
  Edit3,
} from 'lucide-react';
import { api } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { LegalDocument } from '../../types';

interface UserDashboardProps {
  onOpenDocument: (docTitle: string, docId?: string) => void;
  onOpenLeaseWizard: () => void;
  onOpenExportDoc: (doc: LegalDocument) => void;
  onOpenPreviewDoc?: (doc: LegalDocument) => void;
  initialFilter?: 'all' | 'recent' | 'drafts' | 'signed';
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  onOpenDocument,
  onOpenLeaseWizard,
  onOpenExportDoc,
  onOpenPreviewDoc,
  initialFilter = 'all',
}) => {
  const { user } = useAuth();
  const [quickPrompt, setQuickPrompt] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'recent' | 'drafts' | 'signed'>(initialFilter);
  const [documents, setDocuments] = useState<LegalDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [genStep, setGenStep] = useState(1);
  const [genStepText, setGenStepText] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  useEffect(() => {
    if (initialFilter) {
      setActiveTab(initialFilter);
    }
  }, [initialFilter]);

  const fetchDocs = async () => {
    setLoading(true);
    try {
      const res = await api.documents.list();
      setDocuments(res.documents || []);
    } catch {
      showToast('Could not load documents from server');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocs();
  }, []);

  const handleDelete = async (docId: string, title: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm(`Are you sure you want to delete "${title}"?`)) return;

    try {
      await api.documents.delete(docId);
      setDocuments((prev) => prev.filter((d) => d.id !== docId));
      showToast(`Deleted "${title}"`);
    } catch (err: any) {
      showToast(err.message || 'Failed to delete document');
    }
  };

  const handleQuickSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const prompt = quickPrompt.trim();
    if (!prompt) {
      showToast('Please describe the legal agreement you want to generate.');
      return;
    }

    setIsGenerating(true);
    setGenStep(1);
    setGenStepText('Analyzing document intent and identifying applicable jurisdiction...');

    try {
      setTimeout(() => {
        setGenStep(2);
        setGenStepText('Auditing required statutory clauses and standard terms...');
      }, 700);

      setTimeout(() => {
        setGenStep(3);
        setGenStepText('Formatting clauses, numbering hierarchy, and signature lines...');
      }, 1400);

      const generated = await api.ai.generate({
        documentType: prompt,
        keyTerms: prompt,
      });

      setGenStep(4);
      setGenStepText('Saving structured legal document to your account...');

      const createdDoc = await api.documents.create({
        title: generated.title || prompt,
        category: (generated as any).category || 'Business',
        status: 'Draft',
        variables: (generated as any).variables || [],
        sections: (generated as any).sections || [],
        suggestions: (generated as any).suggestions || [],
        readiness: (generated as any).readiness || {
          completed: 5,
          total: 7,
          items: [
            { label: 'All parties defined', done: true },
            { label: 'Payment terms set', done: true },
            { label: 'Confidentiality clause included', done: true },
            { label: 'IP assignment clarified', done: true },
            { label: 'Termination terms specified', done: true },
            { label: 'All variables filled', done: false },
            { label: 'Signature blocks ready', done: false },
          ],
        },
      });

      setQuickPrompt('');
      showToast(`Successfully drafted and saved "${createdDoc.document.title}"`);
      await fetchDocs();
      onOpenDocument(createdDoc.document.title, createdDoc.document.id);
    } catch (err: any) {
      showToast(err.message || 'Generation failed. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const filteredDocs = [...documents]
    .filter((d) => {
      if (activeTab === 'drafts') return d.status === 'Draft';
      if (activeTab === 'signed') return d.status === 'Signed';
      return true;
    })
    .sort((a, b) => {
      if (activeTab === 'recent') {
        const dateA = (a as any).updatedAt || (a as any).createdAt || 0;
        const dateB = (b as any).updatedAt || (b as any).createdAt || 0;
        return new Date(dateB).getTime() - new Date(dateA).getTime();
      }
      return 0;
    });

  const totalCount = documents.length;
  const draftCount = documents.filter((d) => d.status === 'Draft').length;
  const signedCount = documents.filter((d) => d.status === 'Signed').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 font-sans">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700 text-xs font-medium flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-blue-600 uppercase tracking-wider mb-1">
            <span>LegalEase Workspace</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Good morning, {user?.name?.split(' ')[0] || 'User'}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            What legal document would you like to create or manage today?
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onOpenDocument('Master Service Agreement')}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Document</span>
          </button>
        </div>
      </div>

      {/* AI Document Generator Prompt Box */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-sm relative overflow-hidden">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-600 mb-2">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>AI Document Generator</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Describe your document or choose a template to get started
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            Our AI will draft accurate jurisdiction-specific clauses with verified standard legal terminology.
          </p>

          <form onSubmit={handleQuickSubmit} className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={quickPrompt}
              onChange={(e) => setQuickPrompt(e.target.value)}
              disabled={isGenerating}
              placeholder="e.g. Create a residential rental agreement for 1182 S Reed St with $1,850 rent..."
              className="flex-1 px-4 py-3 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-slate-900"
            />
            <button
              type="submit"
              disabled={isGenerating}
              className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-xs transition-all"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-blue-400" />
                  <span>Drafting...</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>Generate Document</span>
                </>
              )}
            </button>
          </form>

          {/* Progress state during generation */}
          {isGenerating && (
            <div className="mt-4 p-4 rounded-2xl bg-blue-50 border border-blue-200 text-xs space-y-2 animate-in fade-in duration-150">
              <div className="flex items-center justify-between text-blue-900 font-bold">
                <span>Generating Legal Contract</span>
                <span>Step {genStep} of 4</span>
              </div>
              <div className="w-full bg-blue-200 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-blue-600 h-full transition-all duration-300"
                  style={{ width: `${(genStep / 4) * 100}%` }}
                />
              </div>
              <p className="text-blue-700 font-medium">{genStepText}</p>
            </div>
          )}
        </div>
      </div>

      {/* 3 Metric Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block mb-1">
              Documents created
            </span>
            <span className="text-3xl font-extrabold text-slate-900">
              {totalCount}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <FileText className="w-6 h-6 stroke-[2]" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block mb-1">
              Drafts in progress
            </span>
            <span className="text-3xl font-extrabold text-slate-900">
              {draftCount}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6 stroke-[2]" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-2xs flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500 block mb-1">
              Signed & Executed
            </span>
            <span className="text-3xl font-extrabold text-slate-900">
              {signedCount}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6 stroke-[2]" />
          </div>
        </div>
      </div>

      {/* Recent Documents Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">Saved Documents</h3>
            <p className="text-xs text-slate-400 mt-0.5">Manage, edit, or download your legal agreements</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === 'all' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setActiveTab('recent')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === 'recent' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Recent
            </button>
            <button
              onClick={() => setActiveTab('drafts')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === 'drafts' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Drafts
            </button>
            <button
              onClick={() => setActiveTab('signed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === 'signed' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Signed
            </button>
            <button
              onClick={fetchDocs}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors ml-1 cursor-pointer"
              title="Refresh document list"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          {filteredDocs.length === 0 ? (
            <div className="p-12 text-center text-slate-400 space-y-2">
              <FileText className="w-10 h-10 mx-auto text-slate-300" />
              <p className="text-sm font-semibold text-slate-700">No documents found</p>
              <p className="text-xs text-slate-400">
                Click &ldquo;New Document&rdquo; or select a template from the library to get started.
              </p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse text-xs text-slate-700">
              <thead>
                <tr className="bg-slate-50/75 border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-6">Document Name</th>
                  <th className="py-3 px-6">Category</th>
                  <th className="py-3 px-6">Status</th>
                  <th className="py-3 px-6">Sections</th>
                  <th className="py-3 px-6">Last Modified</th>
                  <th className="py-3 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredDocs.map((item) => (
                  <tr
                    key={item.id}
                    onClick={() => onOpenDocument(item.title, item.id)}
                    className="hover:bg-blue-50/40 transition-colors cursor-pointer"
                  >
                    <td className="py-4 px-6 font-bold text-slate-900 flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <span className="truncate max-w-[220px]">{item.title}</span>
                    </td>
                    <td className="py-4 px-6 text-slate-500">{item.category}</td>
                    <td className="py-4 px-6">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${
                          item.status === 'Signed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.status === 'In Review'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-semibold text-slate-800">{item.sections?.length || 0} clauses</span>
                    </td>
                    <td className="py-4 px-6 text-slate-400">{item.lastSaved || 'Recently'}</td>
                    <td className="py-4 px-6 text-right space-x-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onOpenDocument(item.title, item.id)}
                        className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-blue-600"
                        title="Open in Editor"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      {onOpenPreviewDoc && (
                        <button
                          onClick={() => onOpenPreviewDoc(item)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-blue-600"
                          title="Preview Formatted Document"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => onOpenExportDoc(item)}
                        className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-900"
                        title="Export PDF / DOCX"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => handleDelete(item.id, item.title, e)}
                        className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600"
                        title="Delete Document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
