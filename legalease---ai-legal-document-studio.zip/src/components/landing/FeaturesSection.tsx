import React from 'react';
import { Zap, ShieldCheck, Edit3, Clock } from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: Zap,
      title: 'AI-Powered',
      description: 'Get accurate, professional documents in seconds using advanced AI technology.',
    },
    {
      icon: ShieldCheck,
      title: 'Secure & Private',
      description: 'Your data is encrypted and never shared with third parties.',
    },
    {
      icon: Edit3,
      title: 'Fully Customizable',
      description: 'Easily edit and personalize your documents to fit your needs.',
    },
    {
      icon: Clock,
      title: 'Save Time & Money',
      description: 'Skip the expensive legal fees and create documents at your convenience.',
    },
  ];

  return (
    <section className="py-14 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-2xs">
                  <Icon className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 mb-1.5 group-hover:text-blue-600 transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
