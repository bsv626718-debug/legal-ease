import React from 'react';
import {
  Home,
  ShieldCheck,
  User,
  Briefcase,
  Users,
  FileText,
  ArrowRight,
} from 'lucide-react';

interface PopularDocumentsProps {
  onSelectDocument: (docTitle: string, templateId?: string) => void;
  onOpenLeaseWizard: () => void;
}

export const PopularDocuments: React.FC<PopularDocumentsProps> = ({
  onSelectDocument,
  onOpenLeaseWizard,
}) => {
  const documents = [
    {
      id: 'rental-agreement',
      title: 'Rental Agreement',
      description: 'Create rental agreements for residential or commercial properties.',
      icon: Home,
      isLeaseWizard: true,
    },
    {
      id: 'nda',
      title: 'Non-Disclosure Agreement',
      description: 'Protect your ideas and sensitive information.',
      icon: ShieldCheck,
      isLeaseWizard: false,
    },
    {
      id: 'last-will',
      title: 'Last Will & Testament',
      description: 'Secure your legacy for your loved ones.',
      icon: User,
      isLeaseWizard: false,
    },
    {
      id: 'employment-contract',
      title: 'Employment Contract',
      description: 'Create professional contracts for your workforce.',
      icon: Briefcase,
      isLeaseWizard: false,
    },
    {
      id: 'business-partnership',
      title: 'Business Partnership',
      description: 'Formalize your business partnerships with confidence.',
      icon: Users,
      isLeaseWizard: false,
    },
    {
      id: 'power-of-attorney',
      title: 'Power of Attorney',
      description: 'Grant authority with legal protection.',
      icon: FileText,
      isLeaseWizard: false,
    },
  ];

  return (
    <section className="py-20 bg-slate-50/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 block mb-2">
            POPULAR DOCUMENTS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
            Choose From a Wide Range of Legal Documents
          </h2>
          <p className="text-sm sm:text-base text-slate-500 font-normal">
            Whether it's for personal, business, or professional use — we've got you covered.
          </p>
        </div>

        {/* 6 Cards Grid (Exact matching layout from Image 2) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((doc) => {
            const Icon = doc.icon;
            return (
              <div
                key={doc.id}
                onClick={() => {
                  if (doc.isLeaseWizard) {
                    onOpenLeaseWizard();
                  } else {
                    onSelectDocument(doc.title, doc.id);
                  }
                }}
                className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md hover:border-blue-200 transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  {/* Blue Icon inside rounded square */}
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-5 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Icon className="w-6 h-6 stroke-[2]" />
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                    {doc.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed mb-6">
                    {doc.description}
                  </p>
                </div>

                {/* Bottom Arrow link */}
                <div className="flex items-center justify-end pt-2 border-t border-slate-50">
                  <div className="w-8 h-8 rounded-full bg-slate-50 group-hover:bg-blue-50 text-slate-400 group-hover:text-blue-600 flex items-center justify-center transition-colors">
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
