import jsPDF from 'jspdf';
import { Document as DocxDocument, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { LegalDocument, LeaseWizardData } from '../types';

export function resolveVariables(text: string, variables: Array<{ key: string; value: string }>): string {
  let resolved = text;
  variables.forEach((v) => {
    resolved = resolved.replace(new RegExp(`{{${v.key}}}`, 'g'), v.value || `[${v.key}]`);
  });
  return resolved;
}

/**
 * Generate and download a print-quality A4 PDF with proper margins, page numbers, and headers.
 */
export function exportDocumentToPdf(doc: LegalDocument): void {
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 20;
  const maxContentWidth = pageWidth - margin * 2;
  let cursorY = margin;

  // Header helper
  const renderHeaderFooter = (pageNumber: number, totalPagesPlaceholder = 1) => {
    pdf.setFont('helvetica', 'italic');
    pdf.setFontSize(8);
    pdf.setTextColor(150, 150, 150);
    // Header
    pdf.text('LegalEase Certified Draft · Private & Confidential', margin, 12);
    // Footer
    pdf.text(
      `Generated via LegalEase AI · Page ${pageNumber}`,
      margin,
      pageHeight - 10
    );
    pdf.text(
      'Verify with qualified legal counsel before signing.',
      pageWidth - margin,
      pageHeight - 10,
      { align: 'right' }
    );
    pdf.setTextColor(30, 41, 59); // reset to dark slate
  };

  const checkPageBreak = (neededHeight: number) => {
    if (cursorY + neededHeight > pageHeight - margin) {
      pdf.addPage();
      cursorY = margin;
      renderHeaderFooter(pdf.getNumberOfPages());
    }
  };

  // First page header
  renderHeaderFooter(1);

  // Document Title
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(18);
  pdf.setTextColor(15, 23, 42); // slate-900
  const titleLines = pdf.splitTextToSize(doc.title.toUpperCase(), maxContentWidth);
  pdf.text(titleLines, pageWidth / 2, cursorY + 4, { align: 'center' });
  cursorY += titleLines.length * 8 + 4;

  // Subtitle / Metadata
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  pdf.setTextColor(100, 116, 139); // slate-500
  pdf.text(`Category: ${doc.category}  |  Status: ${doc.status}  |  Audited Legal Format`, pageWidth / 2, cursorY, { align: 'center' });
  cursorY += 6;

  // Horizontal divider rule
  pdf.setDrawColor(226, 232, 240); // slate-200
  pdf.setLineWidth(0.4);
  pdf.line(margin, cursorY, pageWidth - margin, cursorY);
  cursorY += 8;

  // Variables Summary Box
  if (doc.variables && doc.variables.length > 0) {
    checkPageBreak(30);
    pdf.setFillColor(248, 250, 252); // slate-50
    pdf.roundedRect(margin, cursorY, maxContentWidth, 24, 2, 2, 'F');
    pdf.setDrawColor(203, 213, 225); // slate-300
    pdf.roundedRect(margin, cursorY, maxContentWidth, 24, 2, 2, 'S');

    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(8);
    pdf.setTextColor(71, 85, 105);
    pdf.text('KEY TRANSACTION VARIABLES & PARTIES', margin + 4, cursorY + 5);

    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(7.5);
    pdf.setTextColor(30, 41, 59);

    let varY = cursorY + 10;
    const colWidth = maxContentWidth / 2;
    doc.variables.slice(0, 4).forEach((v, idx) => {
      const colX = idx % 2 === 0 ? margin + 4 : margin + colWidth + 4;
      if (idx === 2) varY += 6;
      pdf.text(`${v.label}: ${v.value || v.defaultValue}`, colX, varY);
    });

    cursorY += 30;
  }

  // Sections / Clauses
  doc.sections.forEach((sec) => {
    checkPageBreak(25);

    // Section Heading
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(11);
    pdf.setTextColor(30, 58, 138); // blue-900
    const headingText = `${sec.number}. ${sec.title}`;
    pdf.text(headingText, margin, cursorY);
    cursorY += 6;

    // Section Content
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9.5);
    pdf.setTextColor(51, 65, 85); // slate-700
    const resolvedContent = resolveVariables(sec.content, doc.variables);
    const splitContent = pdf.splitTextToSize(resolvedContent, maxContentWidth);

    // Render content line-by-line with page-break awareness
    splitContent.forEach((line: string) => {
      checkPageBreak(5);
      pdf.text(line, margin, cursorY);
      cursorY += 4.8;
    });

    cursorY += 4; // clause spacing
  });

  // Signature Block
  checkPageBreak(45);
  cursorY += 6;
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(10);
  pdf.setTextColor(15, 23, 42);
  pdf.text('IN WITNESS WHEREOF, the parties have executed this Agreement as of the Effective Date.', margin, cursorY);
  cursorY += 12;

  const sigColWidth = maxContentWidth / 2 - 8;
  // Party A
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  pdf.line(margin, cursorY, margin + sigColWidth, cursorY);
  pdf.text('By: Authorized Signature', margin, cursorY + 5);
  pdf.text(`Name: ${doc.variables[0]?.value || 'First Party'}`, margin, cursorY + 10);
  pdf.text('Date: ________________________', margin, cursorY + 15);

  // Party B
  const partyBX = margin + sigColWidth + 16;
  pdf.line(partyBX, cursorY, partyBX + sigColWidth, cursorY);
  pdf.text('By: Authorized Signature', partyBX, cursorY + 5);
  pdf.text(`Name: ${doc.variables[1]?.value || 'Second Party'}`, partyBX, cursorY + 10);
  pdf.text('Date: ________________________', partyBX, cursorY + 15);

  // Save PDF
  const filename = `${doc.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.pdf`;
  pdf.save(filename);
}

/**
 * Generate and download a client-side Word (.docx) document
 */
export async function exportDocumentToDocx(doc: LegalDocument): Promise<void> {
  const docParagraphs: Paragraph[] = [
    new Paragraph({
      text: doc.title.toUpperCase(),
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER,
      spacing: { after: 120 },
    }),
    new Paragraph({
      children: [
        new TextRun({
          text: `Category: ${doc.category}  |  Status: ${doc.status}  |  Generated via LegalEase AI`,
          italics: true,
          color: '64748B',
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 300 },
    }),
  ];

  doc.sections.forEach((sec) => {
    docParagraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `${sec.number}. ${sec.title}`,
            bold: true,
            size: 24, // 12pt
            color: '1E3A8A',
          }),
        ],
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 240, after: 100 },
      })
    );

    const resolvedContent = resolveVariables(sec.content, doc.variables);
    docParagraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text: resolvedContent,
            size: 20, // 10pt
            color: '334155',
          }),
        ],
        spacing: { after: 180 },
      })
    );
  });

  // Signature Block
  docParagraphs.push(
    new Paragraph({
      text: 'IN WITNESS WHEREOF, the parties hereto have executed this Agreement.',
      spacing: { before: 300, after: 200 },
    }),
    new Paragraph({
      text: '__________________________________          __________________________________',
      spacing: { after: 80 },
    }),
    new Paragraph({
      text: `By: ${doc.variables[0]?.value || 'First Party'}                       By: ${doc.variables[1]?.value || 'Second Party'}`,
      spacing: { after: 80 },
    }),
    new Paragraph({
      text: 'Date: _________________________                  Date: _________________________',
      spacing: { after: 200 },
    })
  );

  const docxFile = new DocxDocument({
    sections: [{ properties: {}, children: docParagraphs }],
  });

  const blob = await Packer.toBlob(docxFile);
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${doc.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.docx`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

/**
 * Generate PDF for Lease Agreement Builder
 */
export function exportLeaseToPdf(lease: LeaseWizardData): void {
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 20;
  const maxContentWidth = pageWidth - margin * 2;
  let cursorY = margin;

  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(18);
  pdf.setTextColor(15, 23, 42);
  pdf.text('RESIDENTIAL LEASE AGREEMENT', pageWidth / 2, cursorY + 4, { align: 'center' });
  cursorY += 12;

  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  pdf.setTextColor(100, 116, 139);
  pdf.text(`Premises: ${lease.address}, ${lease.unit ? lease.unit + ', ' : ''}${lease.city}, ${lease.state} ${lease.zip}`, pageWidth / 2, cursorY, { align: 'center' });
  cursorY += 8;

  pdf.setDrawColor(226, 232, 240);
  pdf.line(margin, cursorY, pageWidth - margin, cursorY);
  cursorY += 8;

  const clauses = [
    { title: '1. Parties', content: `This Agreement is between ${lease.landlordName} ("Landlord") and ${lease.tenantNames} ("Tenant"). Landlord Phone: ${lease.landlordPhone}, Email: ${lease.landlordEmail}. Tenant Email: ${lease.tenantEmail}.` },
    { title: '2. Term of Lease', content: `The lease commences on ${lease.leaseStartDate} and terminates on ${lease.leaseEndDate}. Month-to-month continuation requires thirty (30) days written notice.` },
    { title: '3. Rent & Deposits', content: `Monthly rent is ${lease.monthlyRent}, due on the first day of each calendar month. Security Deposit is ${lease.securityDeposit}. Pet Deposit is ${lease.petDeposit}. Late fee: ${lease.lateFee}.` },
    { title: '4. Pets & Smoking', content: `Pets allowed: ${lease.petsAllowed ? 'Yes (' + lease.petPolicyDetails + ')' : 'No'}. Smoking allowed: ${lease.smokingAllowed ? 'Yes' : 'No'}. Renters Insurance Required: ${lease.rentersInsuranceRequired ? 'Yes' : 'No'}.` },
    { title: '5. Utilities Included', content: `The following utilities are included in monthly rent: ${lease.utilitiesIncluded.join(', ') || 'None (Tenant responsible for all utilities)'}.` },
    { title: '6. Additional Provisions', content: lease.customClauses || 'Standard quiet hours between 10:00 PM and 7:00 AM. Premises shall be kept clean and sanitary.' },
  ];

  clauses.forEach((c) => {
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(11);
    pdf.setTextColor(30, 58, 138);
    pdf.text(c.title, margin, cursorY);
    cursorY += 6;

    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9.5);
    pdf.setTextColor(51, 65, 85);
    const split = pdf.splitTextToSize(c.content, maxContentWidth);
    split.forEach((line: string) => {
      pdf.text(line, margin, cursorY);
      cursorY += 4.8;
    });
    cursorY += 4;
  });

  // Signatures
  cursorY += 8;
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(10);
  pdf.setTextColor(15, 23, 42);
  pdf.text('IN WITNESS WHEREOF, Landlord and Tenant execute this Residential Lease.', margin, cursorY);
  cursorY += 12;

  const colWidth = maxContentWidth / 2 - 8;
  pdf.line(margin, cursorY, margin + colWidth, cursorY);
  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(8.5);
  pdf.text(`Landlord: ${lease.landlordName}`, margin, cursorY + 5);
  pdf.text('Date: ________________________', margin, cursorY + 10);

  const tX = margin + colWidth + 16;
  pdf.line(tX, cursorY, tX + colWidth, cursorY);
  pdf.text(`Tenant: ${lease.tenantNames}`, tX, cursorY + 5);
  pdf.text('Date: ________________________', tX, cursorY + 10);

  pdf.save('residential-lease-agreement.pdf');
}
