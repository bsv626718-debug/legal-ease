export type DocumentStatus = 'Draft' | 'In Review' | 'Active' | 'Signed' | 'Archived';

export interface DocumentVariable {
  id: string;
  key: string;
  label: string;
  value: string;
  defaultValue: string;
  type: 'text' | 'date' | 'currency' | 'number';
}

export interface DocumentSection {
  id: string;
  number: number;
  title: string;
  content: string;
}

export interface AISuggestion {
  id: string;
  type: 'gdpr' | 'liability' | 'dispute' | 'confidentiality' | 'custom' | 'statutory';
  color: 'red' | 'yellow' | 'blue' | 'purple' | 'green';
  title: string;
  actionText: string;
  applied?: boolean;
  clauseToAdd?: string;
  sectionTarget?: number;
}

export interface DocumentComment {
  id: string;
  author: string;
  initials: string;
  avatarColor: string;
  text: string;
  timestamp: string;
}

export type OfficialSourceAuthority =
  | 'India Code'
  | 'Legislative Department'
  | 'e-Gazette of India';

export interface SourceCitation {
  id: string;
  provisionId: string;
  actName: string;
  sectionNumber: string;
  sectionTitle: string;
  officialUrl: string;
  sourceTitle: OfficialSourceAuthority;
  verificationStatus: 'verified' | 'pending_review' | 'unverified' | 'outdated';
  amendmentStatus: string;
  sourceSnippet: string;
  relevanceScore: number;
  jurisdiction: {
    country: string;
    state?: string;
    territoryType?: string;
  };
  requiresLegalReview: boolean;
  reviewWarning?: string;
}

export interface OutdatedLawWarning {
  citedText: string;
  repealedAct: string;
  repealedSection?: string;
  currentInForceAct: string;
  currentInForceSection?: string;
  officialUrl: string;
  warningMessage: string;
  gazetteRef?: string;
}

export interface JurisdictionInfo {
  country: 'India' | 'United States' | 'United Kingdom';
  state?: string; // e.g. 'Tamil Nadu', 'Maharashtra', 'Karnataka', 'Delhi (NCT)', 'Central'
}

export interface LegalDocument {
  id: string;
  title: string;
  category: 'Business' | 'Property' | 'Personal' | 'Employment' | 'Legal Letters' | 'Freelancers';
  status: DocumentStatus;
  lastSaved: string;
  collaborators: { name: string; initials: string; role: string; avatarColor: string }[];
  variables: DocumentVariable[];
  sections: DocumentSection[];
  suggestions: AISuggestion[];
  comments: DocumentComment[];
  readiness: {
    completed: number;
    total: number;
    items: { label: string; done: boolean }[];
  };
  jurisdiction?: JurisdictionInfo;
  citations?: SourceCitation[];
  outdatedWarnings?: OutdatedLawWarning[];
  legalDisclaimer?: string;
  requiresLegalReview?: boolean;
}

export interface LeaseWizardData {
  address: string;
  unit: string;
  city: string;
  state: string; // e.g. 'Tamil Nadu', 'Maharashtra', 'CO'
  country?: string; // e.g. 'India', 'United States'
  zip: string;
  leaseStartDate: string;
  leaseEndDate: string;
  monthlyRent: string;
  securityDeposit: string;
  petDeposit: string;
  moveInFee: string;
  lateFee: string;
  landlordName: string;
  landlordEmail: string;
  landlordPhone: string;
  tenantNames: string;
  tenantEmail: string;
  petsAllowed: boolean;
  petPolicyDetails: string;
  smokingAllowed: boolean;
  rentersInsuranceRequired: boolean;
  utilitiesIncluded: string[];
  customClauses: string;
  // Tamil Nadu & India Tenancy Compliance
  tenancyPortalRegistrationAgreed?: boolean;
  securityDepositCompliant?: boolean; // Max 3 months in TN
  statutoryActApplied?: string; // e.g. 'TNRRRL Act, 2017'
}
