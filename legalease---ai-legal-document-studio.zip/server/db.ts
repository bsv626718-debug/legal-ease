import fs from 'fs';
import path from 'path';

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'user' | 'admin';
  emailVerified: boolean;
  subscriptionPlan: 'free' | 'pro' | 'enterprise';
  resetToken?: string;
  resetTokenExpiry?: number;
  verificationToken?: string;
  createdAt: string;
}

export interface DocumentRecord {
  id: string;
  userId: string;
  title: string;
  category: 'Business' | 'Property' | 'Personal' | 'Employment' | 'Legal Letters' | 'Freelancers';
  status: 'Draft' | 'In Review' | 'Active' | 'Signed' | 'Archived';
  lastSaved: string;
  variables: Array<{
    id: string;
    key: string;
    label: string;
    value: string;
    defaultValue: string;
    type: 'text' | 'date' | 'currency' | 'number';
  }>;
  sections: Array<{
    id: string;
    number: number;
    title: string;
    content: string;
  }>;
  suggestions: Array<{
    id: string;
    type: 'gdpr' | 'liability' | 'dispute' | 'confidentiality' | 'custom';
    color: 'red' | 'yellow' | 'blue' | 'purple' | 'green';
    title: string;
    actionText: string;
    clauseToAdd?: string;
    sectionTarget?: number;
  }>;
  comments: Array<{
    id: string;
    author: string;
    initials: string;
    avatarColor: string;
    text: string;
    timestamp: string;
  }>;
  readiness: {
    completed: number;
    total: number;
    items: Array<{ label: string; done: boolean }>;
  };
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogRecord {
  id: string;
  userId: string;
  userEmail: string;
  action: string;
  details: string;
  ipAddress?: string;
  timestamp: string;
}

export interface SubscriptionRecord {
  id: string;
  userId: string;
  plan: 'free' | 'pro' | 'enterprise';
  status: 'active' | 'cancelled' | 'past_due';
  amount: number;
  currency: 'USD' | 'INR';
  currentPeriodEnd: string;
  createdAt: string;
}

interface DatabaseSchema {
  users: UserRecord[];
  documents: DocumentRecord[];
  audit_logs: AuditLogRecord[];
  subscriptions: SubscriptionRecord[];
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'legalease.db.json');

// Ensure data directory exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

function loadDatabase(): DatabaseSchema {
  if (!fs.existsSync(DB_FILE)) {
    const initialDb: DatabaseSchema = {
      users: [],
      documents: [],
      audit_logs: [],
      subscriptions: [],
    };
    saveDatabase(initialDb);
    return initialDb;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read database, creating fallback:', err);
    return {
      users: [],
      documents: [],
      audit_logs: [],
      subscriptions: [],
    };
  }
}

function saveDatabase(db: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save database:', err);
  }
}

export const db = {
  getUsers: (): UserRecord[] => loadDatabase().users,
  findUserById: (id: string): UserRecord | undefined =>
    loadDatabase().users.find((u) => u.id === id),
  findUserByEmail: (email: string): UserRecord | undefined =>
    loadDatabase().users.find((u) => u.email.toLowerCase() === email.toLowerCase().trim()),
  findUserByResetToken: (token: string): UserRecord | undefined =>
    loadDatabase().users.find((u) => u.resetToken === token && (u.resetTokenExpiry || 0) > Date.now()),
  createUser: (user: UserRecord): UserRecord => {
    const database = loadDatabase();
    database.users.push(user);
    saveDatabase(database);
    return user;
  },
  updateUser: (id: string, updates: Partial<UserRecord>): UserRecord | null => {
    const database = loadDatabase();
    const index = database.users.findIndex((u) => u.id === id);
    if (index === -1) return null;
    database.users[index] = { ...database.users[index], ...updates };
    saveDatabase(database);
    return database.users[index];
  },
  deleteUser: (id: string): boolean => {
    const database = loadDatabase();
    const initialCount = database.users.length;
    database.users = database.users.filter((u) => u.id !== id);
    // Also remove documents belonging to user
    database.documents = database.documents.filter((d) => d.userId !== id);
    saveDatabase(database);
    return database.users.length < initialCount;
  },

  // Documents
  getDocumentsByUser: (userId: string): DocumentRecord[] =>
    loadDatabase().documents.filter((d) => d.userId === userId),
  getAllDocuments: (): DocumentRecord[] => loadDatabase().documents,
  findDocumentById: (id: string): DocumentRecord | undefined =>
    loadDatabase().documents.find((d) => d.id === id),
  createDocument: (doc: DocumentRecord): DocumentRecord => {
    const database = loadDatabase();
    database.documents.unshift(doc);
    saveDatabase(database);
    return doc;
  },
  updateDocument: (id: string, updates: Partial<DocumentRecord>): DocumentRecord | null => {
    const database = loadDatabase();
    const index = database.documents.findIndex((d) => d.id === id);
    if (index === -1) return null;
    database.documents[index] = {
      ...database.documents[index],
      ...updates,
      updatedAt: new Date().toISOString(),
      lastSaved: 'Just now',
    };
    saveDatabase(database);
    return database.documents[index];
  },
  deleteDocument: (id: string, userId: string, isAdmin = false): boolean => {
    const database = loadDatabase();
    const index = database.documents.findIndex((d) => d.id === id && (isAdmin || d.userId === userId));
    if (index === -1) return false;
    database.documents.splice(index, 1);
    saveDatabase(database);
    return true;
  },

  // Audit Logs
  createAuditLog: (log: Omit<AuditLogRecord, 'id' | 'timestamp'>): AuditLogRecord => {
    const database = loadDatabase();
    const record: AuditLogRecord = {
      ...log,
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
    };
    database.audit_logs.unshift(record);
    // Keep max 500 logs
    if (database.audit_logs.length > 500) {
      database.audit_logs = database.audit_logs.slice(0, 500);
    }
    saveDatabase(database);
    return record;
  },
  getAuditLogs: (limit = 100): AuditLogRecord[] => loadDatabase().audit_logs.slice(0, limit),

  // Subscriptions
  createOrUpdateSubscription: (sub: SubscriptionRecord): SubscriptionRecord => {
    const database = loadDatabase();
    const existingIndex = database.subscriptions.findIndex((s) => s.userId === sub.userId);
    if (existingIndex >= 0) {
      database.subscriptions[existingIndex] = sub;
    } else {
      database.subscriptions.push(sub);
    }
    saveDatabase(database);
    return sub;
  },
  getSubscriptionByUser: (userId: string): SubscriptionRecord | undefined =>
    loadDatabase().subscriptions.find((s) => s.userId === userId),
};
