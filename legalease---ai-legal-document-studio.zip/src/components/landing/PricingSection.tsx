import React, { useState } from 'react';
import { Cloud, Users, User, Mail, Shield, BarChart3, Settings2, Sparkles, Check } from 'lucide-react';

interface PricingSectionProps {
  onSelectPlan: (plan: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  const [currency, setCurrency] = useState<'USD' | 'INR'>('USD');
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');

  const prices = {
    USD: {
      basic: billingPeriod === 'monthly' ? '$10' : '$8',
      pro: billingPeriod === 'monthly' ? '$25' : '$20',
      enterprise: billingPeriod === 'monthly' ? '$75' : '$60',
      period: '/month',
    },
    INR: {
      basic: billingPeriod === 'monthly' ? '₹199' : '₹159',
      pro: billingPeriod === 'monthly' ? '₹499' : '₹399',
      enterprise: billingPeriod === 'monthly' ? '₹1,499' : '₹1,199',
      period: '/month',
    },
  };

  const currentPrices = prices[currency];

  return (
    <section id="pricing" className="py-24 bg-slate-100/70 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 block mb-2">
            TRANSPARENT PRICING
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
            Simple, Predictable Plans For Everyone
          </h2>
          <p className="text-sm sm:text-base text-slate-500">
            Create high-quality legal agreements without surprise fees. Cancel anytime.
          </p>

          {/* Currency and Billing Period Toggles */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-6">
            <div className="bg-white p-1 rounded-xl border border-slate-200 shadow-2xs flex items-center">
              <button
                onClick={() => setBillingPeriod('monthly')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  billingPeriod === 'monthly'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingPeriod('yearly')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  billingPeriod === 'yearly'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Annual</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded font-bold">
                  Save 20%
                </span>
              </button>
            </div>

            <div className="bg-white p-1 rounded-xl border border-slate-200 shadow-2xs flex items-center">
              <button
                onClick={() => setCurrency('USD')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  currency === 'USD' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                USD ($)
              </button>
              <button
                onClick={() => setCurrency('INR')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  currency === 'INR' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                INR (₹)
              </button>
            </div>
          </div>
        </div>

        {/* 3 Pricing Cards (Exact match to Image 4) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto items-stretch">
          {/* Card 1: Basic */}
          <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-lg border border-slate-200 flex flex-col justify-between hover:shadow-xl transition-all">
            <div>
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-slate-900 mb-3">Basic</h3>
                <div className="flex items-baseline justify-center">
                  <span className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
                    {currentPrices.basic}
                  </span>
                  <span className="text-slate-500 text-sm ml-1">{currentPrices.period}</span>
                </div>
              </div>

              {/* Features with dividers (Image 4 exact styling) */}
              <div className="space-y-4 my-8 text-sm text-slate-700">
                <div className="flex items-center gap-3 py-2 border-b border-slate-100">
                  <Cloud className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>5GB Storage</span>
                </div>
                <div className="flex items-center gap-3 py-2 border-b border-slate-100">
                  <Users className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>1 User</span>
                </div>
                <div className="flex items-center gap-3 py-2 border-b border-slate-100">
                  <User className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>Standard Document Drafts</span>
                </div>
                <div className="flex items-center gap-3 py-2">
                  <Mail className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>Email Support</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectPlan('Basic')}
              className="w-full py-3.5 px-6 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all text-center cursor-pointer"
            >
              Get Started
            </button>
          </div>

          {/* Card 2: Pro (Highlight Centerpiece Card from Image 4) */}
          <div className="bg-linear-to-b from-blue-600 via-blue-600 to-indigo-700 text-white rounded-3xl p-8 sm:p-10 shadow-2xl relative flex flex-col justify-between transform md:-translate-y-2 hover:-translate-y-3 transition-all">
            {/* Top Popular Ribbon */}
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-amber-400 text-slate-900 font-extrabold text-[11px] uppercase tracking-wider py-1 px-4 rounded-full shadow-md">
              Most Popular
            </div>

            <div>
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-white mb-3">Pro</h3>
                <div className="flex items-baseline justify-center text-white">
                  <span className="text-4xl sm:text-5xl font-extrabold tracking-tight">
                    {currentPrices.pro}
                  </span>
                  <span className="text-blue-100 text-sm ml-1">{currentPrices.period}</span>
                </div>
              </div>

              {/* Features with dividers */}
              <div className="space-y-4 my-8 text-sm text-blue-50">
                <div className="flex items-center gap-3 py-2 border-b border-white/20">
                  <Cloud className="w-5 h-5 text-blue-200 shrink-0" />
                  <span>25GB Storage</span>
                </div>
                <div className="flex items-center gap-3 py-2 border-b border-white/20">
                  <BarChart3 className="w-5 h-5 text-blue-200 shrink-0" />
                  <span>5 Users</span>
                </div>
                <div className="flex items-center gap-3 py-2 border-b border-white/20">
                  <Shield className="w-5 h-5 text-blue-200 shrink-0" />
                  <span>Priority Support</span>
                </div>
                <div className="flex items-center gap-3 py-2">
                  <Sparkles className="w-5 h-5 text-blue-200 shrink-0" />
                  <span>Advanced Analytics & AI Rewrite</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectPlan('Pro')}
              className="w-full py-3.5 px-6 rounded-2xl bg-white hover:bg-slate-50 text-slate-900 font-bold text-sm shadow-lg hover:shadow-xl transition-all text-center cursor-pointer"
            >
              Get Started
            </button>
          </div>

          {/* Card 3: Enterprise */}
          <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-lg border border-slate-200 flex flex-col justify-between hover:shadow-xl transition-all">
            <div>
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-slate-900 mb-3">Enterprise</h3>
                <div className="flex items-baseline justify-center">
                  <span className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
                    {currentPrices.enterprise}
                  </span>
                  <span className="text-slate-500 text-sm ml-1">{currentPrices.period}</span>
                </div>
              </div>

              {/* Features with dividers */}
              <div className="space-y-4 my-8 text-sm text-slate-700">
                <div className="flex items-center gap-3 py-2 border-b border-slate-100">
                  <Cloud className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>Unlimited Storage</span>
                </div>
                <div className="flex items-center gap-3 py-2 border-b border-slate-100">
                  <Users className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>20+ Users</span>
                </div>
                <div className="flex items-center gap-3 py-2 border-b border-slate-100">
                  <Shield className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>Dedicated Account Manager</span>
                </div>
                <div className="flex items-center gap-3 py-2">
                  <Settings2 className="w-5 h-5 text-slate-500 shrink-0" />
                  <span>Custom Integrations & API</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectPlan('Enterprise')}
              className="w-full py-3.5 px-6 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all text-center cursor-pointer"
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
