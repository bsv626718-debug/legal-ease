import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar, AppView } from './components/layout/Navbar';
import { AppSidebar } from './components/layout/AppSidebar';
import { Footer } from './components/layout/Footer';
import { HeroSection } from './components/landing/HeroSection';
import { FeaturesSection } from './components/landing/FeaturesSection';
import { PopularDocuments } from './components/landing/PopularDocuments';
import { PricingSection } from './components/landing/PricingSection';
import { ContractOceanEditor } from './components/editor/ContractOceanEditor';
import { TurboTenantLeaseBuilder } from './components/lease/TurboTenantLeaseBuilder';
import { UserDashboard } from './components/dashboard/UserDashboard';
import { TemplatesView } from './components/templates/TemplatesView';
import { SettingsView } from './components/settings/SettingsView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { DocumentPreview } from './components/common/DocumentPreview';
import { SignatureModal } from './components/modals/SignatureModal';
import { ExportModal } from './components/modals/ExportModal';
import { AuthModal } from './components/modals/AuthModal';
import { HowItWorksModal } from './components/modals/HowItWorksModal';
import { LegalDocument, LeaseWizardData } from './types';
import { initialMasterServiceAgreement, initialLeaseData } from './data/mockData';
import { api } from './lib/api';
import { templateService } from './services/templateService';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [activeDocId, setActiveDocId] = useState<string | undefined>(undefined);
  const [activeTemplateId, setActiveTemplateId] = useState<string | undefined>(undefined);

  // Sidebar and Filter/Tab navigation state
  const [dashboardFilter, setDashboardFilter] = useState<'all' | 'recent' | 'drafts' | 'signed'>('all');
  const [settingsTab, setSettingsTab] = useState<'profile' | 'security' | 'billing'>('profile');
  const [sidebarOpenMobile, setSidebarOpenMobile] = useState(false);
  const [sidebarCollapsedDesktop, setSidebarCollapsedDesktop] = useState(false);

  // Modals
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot' | 'reset'>('login');
  const [signatureModalOpen, setSignatureModalOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [howItWorksOpen, setHowItWorksOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active documents for modals & preview
  const [activeDocForExport, setActiveDocForExport] = useState<LegalDocument | undefined>(initialMasterServiceAgreement);
  const [activeLeaseForExport, setActiveLeaseForExport] = useState<LeaseWizardData | undefined>(undefined);
  const [activeTitleForSignature, setActiveTitleForSignature] = useState('Master Service Agreement');
  const [activeDocForPreview, setActiveDocForPreview] = useState<LegalDocument | undefined>(undefined);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleOpenAuth = (mode: 'login' | 'signup' | 'forgot' | 'reset') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  // Safe navigation with route protection
  const handleNavigate = (view: AppView, options?: { tab?: string; filter?: string }) => {
    if (options?.filter) {
      setDashboardFilter(options.filter as any);
    }
    if (options?.tab) {
      setSettingsTab(options.tab as any);
    }

    if (view === 'dashboard' || view === 'settings') {
      if (!user && !loading) {
        showToast('Please sign in to access your workspace.');
        handleOpenAuth('login');
        return;
      }
    } else if (view === 'admin') {
      if (!user && !loading) {
        showToast('Admin authentication required.');
        handleOpenAuth('login');
        return;
      }
      if (user && user.role !== 'admin') {
        showToast('Access restricted. Admin privileges required.');
        setCurrentView('dashboard');
        return;
      }
    }
    setCurrentView(view);
  };

  const handleGenerateDocument = (promptText?: string, docId?: string) => {
    setActiveDocId(docId);
    setActiveTemplateId(undefined);
    if (promptText && (promptText.toLowerCase().includes('lease') || promptText.toLowerCase().includes('rental'))) {
      setCurrentView('lease-wizard');
    } else {
      setCurrentView('editor');
    }
  };

  const handleOpenExportDoc = (doc: LegalDocument) => {
    setActiveDocForExport(doc);
    setActiveLeaseForExport(undefined);
    setExportModalOpen(true);
  };

  const handleOpenExportLease = (leaseData: LeaseWizardData) => {
    setActiveDocForExport(undefined);
    setActiveLeaseForExport(leaseData);
    setExportModalOpen(true);
  };

  const handleOpenSignatureDoc = (doc?: LegalDocument) => {
    setActiveTitleForSignature(doc?.title || 'Master Service Agreement');
    setSignatureModalOpen(true);
  };

  const handleOpenSignatureLease = () => {
    setActiveTitleForSignature('Residential Lease Agreement');
    setSignatureModalOpen(true);
  };

  const handleEditTemplate = (templateId: string, title: string) => {
    setActiveTemplateId(templateId);
    setActiveDocId(undefined);
    setCurrentView('editor');
  };

  const handlePreviewTemplate = async (templateId: string) => {
    try {
      showToast('Loading document preview...');
      const t = await templateService.getTemplateById(templateId);
      setActiveDocForPreview({
        id: `template-${t.id}`,
        title: t.title,
        category: t.category,
        status: 'Draft',
        lastSaved: 'Template Schema',
        collaborators: [],
        variables: t.variables,
        sections: t.sections,
        suggestions: t.suggestions,
        comments: [],
        readiness: t.readiness,
      });
      setCurrentView('preview');
    } catch (err: any) {
      showToast(err.message || 'Failed to load preview');
    }
  };

  const handleSelectPlan = async (plan: string) => {
    if (!user) {
      handleOpenAuth('signup');
    } else {
      try {
        const planLower = plan.toLowerCase() as 'basic' | 'pro' | 'enterprise';
        await api.billing.subscribe(planLower);
        showToast(`Upgraded subscription plan to ${plan}!`);
        setSettingsTab('billing');
        setCurrentView('settings');
      } catch (err: any) {
        showToast(err.message || 'Failed to update subscription');
      }
    }
  };

  const isWorkspaceView =
    currentView === 'dashboard' ||
    currentView === 'templates' ||
    currentView === 'settings' ||
    currentView === 'admin';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700 text-xs font-medium flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenAuth={handleOpenAuth}
        onToggleSidebar={() => setSidebarOpenMobile(!sidebarOpenMobile)}
      />

      {/* Main View Router */}
      <div className="flex-1 flex flex-col">
        {/* Landing Page */}
        {currentView === 'landing' && (
          <main className="flex-1">
            <HeroSection
              onGenerateDocument={handleGenerateDocument}
              onWatchDemo={() => setHowItWorksOpen(true)}
              onOpenLeaseWizard={() => setCurrentView('lease-wizard')}
            />

            <FeaturesSection />

            <PopularDocuments
              onSelectDocument={(title, templateId) => {
                if (templateId) {
                  handleEditTemplate(templateId, title);
                } else {
                  handleGenerateDocument(title);
                }
              }}
              onOpenLeaseWizard={() => setCurrentView('lease-wizard')}
            />

            {/* Pipeline Section */}
            <section id="how-it-works" className="py-20 bg-white border-t border-slate-100">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-2xl mx-auto mb-14">
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-600 block mb-2">
                    FAST 5-STEP PIPELINE
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
                    From Questionnaire to Signed Agreement in Minutes
                  </h2>
                  <p className="text-sm sm:text-base text-slate-500 font-normal">
                    Automated jurisdiction-specific clauses drafted by AI, vetted against standard legal contracts.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                  {[
                    { step: '01', title: 'Choose Document', desc: 'Select from 15+ audited commercial, property, and personal templates.' },
                    { step: '02', title: 'Answer Questions', desc: 'Provide parties, jurisdiction, milestone compensation, and rules.' },
                    { step: '03', title: 'AI Generates Draft', desc: 'Structured legal draft created with statutory references and safeguards.' },
                    { step: '04', title: 'Customize & Tone', desc: 'Rewrite clauses, resolve missing fields, and adjust liability caps.' },
                    { step: '05', title: 'Export & E-Sign', desc: 'Download print-ready PDF or execute legally binding digital signatures.' },
                  ].map((item, idx) => (
                    <div key={idx} className="bg-slate-50 p-6 rounded-2xl border border-slate-200/80 space-y-2 relative group hover:bg-blue-50/50 hover:border-blue-200 transition-all">
                      <span className="text-2xl font-black text-blue-600 block">{item.step}</span>
                      <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                      <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            <PricingSection onSelectPlan={handleSelectPlan} />
          </main>
        )}

        {/* View 2: Contract Ocean Studio */}
        {currentView === 'editor' && (
          <div className="flex-1 flex flex-col h-[calc(100vh-104px)]">
            <ContractOceanEditor
              onBack={() => handleNavigate('dashboard')}
              onOpenExport={handleOpenExportDoc}
              onOpenSignature={handleOpenSignatureDoc}
              docId={activeDocId}
              templateId={activeTemplateId}
              onNavigateToTab={(tab) => handleNavigate(tab)}
              onOpenPreview={(doc) => {
                setActiveDocForPreview(doc);
                setCurrentView('preview');
              }}
            />
          </div>
        )}

        {/* View 3: TurboTenant Lease Agreement Builder */}
        {currentView === 'lease-wizard' && (
          <div className="flex-1 flex flex-col h-[calc(100vh-104px)]">
            <TurboTenantLeaseBuilder
              onBack={() => handleNavigate('dashboard')}
              onOpenExportPDF={handleOpenExportLease}
              onOpenSignature={handleOpenSignatureLease}
            />
          </div>
        )}

        {/* View 4: Dedicated Document Preview View */}
        {currentView === 'preview' && (
          <div className="flex-1">
            <DocumentPreview
              document={activeDocForPreview || initialMasterServiceAgreement}
              onBack={() => handleNavigate('dashboard')}
              onEdit={() => {
                if (activeDocForPreview) {
                  if (activeDocForPreview.id.startsWith('template-')) {
                    const tid = activeDocForPreview.id.replace('template-', '');
                    handleEditTemplate(tid, activeDocForPreview.title);
                  } else {
                    setActiveDocId(activeDocForPreview.id);
                    setActiveTemplateId(undefined);
                    setCurrentView('editor');
                  }
                } else {
                  setCurrentView('editor');
                }
              }}
            />
          </div>
        )}

        {/* Workspace Views with Left Primary Navigation Sidebar (Requirement 2 exact implementation) */}
        {isWorkspaceView && (
          <div className="flex-1 flex overflow-hidden">
            <AppSidebar
              currentView={currentView}
              activeFilter={dashboardFilter}
              activeSettingsTab={settingsTab}
              onNavigate={handleNavigate}
              onCreateDocument={() => {
                setCurrentView('templates');
              }}
              isOpenMobile={sidebarOpenMobile}
              onCloseMobile={() => setSidebarOpenMobile(false)}
              isCollapsedDesktop={sidebarCollapsedDesktop}
              onToggleCollapseDesktop={() => setSidebarCollapsedDesktop(!sidebarCollapsedDesktop)}
            />

            <div className="flex-1 overflow-y-auto">
              {currentView === 'dashboard' && (
                <UserDashboard
                  onOpenDocument={handleGenerateDocument}
                  onOpenLeaseWizard={() => setCurrentView('lease-wizard')}
                  onOpenExportDoc={handleOpenExportDoc}
                  onOpenPreviewDoc={(doc) => {
                    setActiveDocForPreview(doc);
                    setCurrentView('preview');
                  }}
                  initialFilter={dashboardFilter}
                />
              )}

              {currentView === 'templates' && (
                <TemplatesView
                  onSelectTemplate={handleEditTemplate}
                  onEditTemplate={handleEditTemplate}
                  onPreviewTemplate={handlePreviewTemplate}
                  onOpenLeaseWizard={() => setCurrentView('lease-wizard')}
                />
              )}

              {currentView === 'settings' && (
                <SettingsView
                  onBack={() => handleNavigate('dashboard')}
                  onUpgradePlan={() => {
                    setSettingsTab('billing');
                  }}
                  initialTab={settingsTab}
                />
              )}

              {currentView === 'admin' && (
                <AdminDashboard onBack={() => handleNavigate('dashboard')} />
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer on landing and preview */}
      {(currentView === 'landing' || currentView === 'preview') && (
        <Footer onNavigate={(v) => handleNavigate(v as AppView)} />
      )}

      {/* Global Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
        onSuccess={() => {
          showToast('Signed in successfully!');
          handleNavigate('dashboard');
        }}
      />

      <SignatureModal
        isOpen={signatureModalOpen}
        onClose={() => setSignatureModalOpen(false)}
        documentTitle={activeTitleForSignature}
      />

      <ExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        document={activeDocForExport}
        leaseData={activeLeaseForExport}
      />

      <HowItWorksModal
        isOpen={howItWorksOpen}
        onClose={() => setHowItWorksOpen(false)}
        onStartDrafting={() => setCurrentView('editor')}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
