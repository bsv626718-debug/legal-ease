import { LegalDocument, DocumentVariable, DocumentSection, AISuggestion } from '../types';
import { api } from '../lib/api';

export interface TemplateSummary {
  id: string;
  title: string;
  category: 'Property' | 'Business' | 'Personal' | 'Employment' | 'Freelancers' | 'Legal Letters';
  description: string;
  popular: boolean;
  jurisdiction: string;
  timeEst: string;
  icon: string;
}

export interface FullTemplate extends TemplateSummary {
  variables: DocumentVariable[];
  sections: DocumentSection[];
  suggestions: AISuggestion[];
  readiness: {
    completed: number;
    total: number;
    items: { label: string; done: boolean }[];
  };
}

export class TemplateLoadError extends Error {
  templateId?: string;
  isNotFound?: boolean;
  constructor(message: string, templateId?: string, isNotFound = false) {
    super(message);
    this.name = 'TemplateLoadError';
    this.templateId = templateId;
    this.isNotFound = isNotFound;
  }
}

export const templateService = {
  /**
   * Retrieve list of all available legal templates
   */
  async getTemplates(): Promise<TemplateSummary[]> {
    try {
      const res = await fetch('/api/templates', {
        headers: { 'Content-Type': 'application/json' },
      });
      if (!res.ok) {
        throw new Error(`Failed to load templates (HTTP ${res.status})`);
      }
      const data = await res.json();
      return data.templates || [];
    } catch (err: any) {
      console.error('Error in templateService.getTemplates:', err);
      throw new TemplateLoadError(err.message || 'Could not load legal templates.');
    }
  },

  /**
   * Retrieve full template data by its actual template ID
   */
  async getTemplateById(templateId: string): Promise<FullTemplate> {
    if (!templateId || typeof templateId !== 'string') {
      throw new TemplateLoadError('A valid template ID is required.', templateId, true);
    }

    try {
      const res = await fetch(`/api/templates/${encodeURIComponent(templateId)}`, {
        headers: { 'Content-Type': 'application/json' },
      });

      if (res.status === 404) {
        throw new TemplateLoadError(
          `Template "${templateId}" was not found. Please select an available template from our catalog.`,
          templateId,
          true
        );
      }

      if (!res.ok) {
        const errorJson = await res.json().catch(() => null);
        throw new TemplateLoadError(
          errorJson?.error || `Failed to retrieve template (HTTP ${res.status})`,
          templateId
        );
      }

      const data = await res.json();
      if (!data.template || !data.template.sections || data.template.sections.length === 0) {
        throw new TemplateLoadError(
          'Template retrieved has invalid or empty content. Please contact support.',
          templateId
        );
      }

      return data.template;
    } catch (err: any) {
      if (err instanceof TemplateLoadError) throw err;
      throw new TemplateLoadError(
        err.message || 'Network connection issue while retrieving template.',
        templateId
      );
    }
  },

  /**
   * Instantiate an editable LegalDocument copy from a template
   */
  async instantiateDocument(
    templateId: string,
    options?: { title?: string; initialVariables?: Record<string, string> }
  ): Promise<LegalDocument> {
    const template = await this.getTemplateById(templateId);

    // Merge custom variable values if provided
    const variables = template.variables.map((v) => {
      if (options?.initialVariables && options.initialVariables[v.key]) {
        return { ...v, value: options.initialVariables[v.key] };
      }
      return { ...v };
    });

    const newDocPayload: Partial<LegalDocument> = {
      title: options?.title || template.title,
      category: template.category,
      status: 'Draft',
      variables,
      sections: template.sections.map((s) => ({ ...s })),
      suggestions: template.suggestions.map((sug) => ({ ...sug })),
      readiness: { ...template.readiness },
    };

    // If user is authenticated, save directly to server
    try {
      const res = await api.documents.create(newDocPayload);
      return res.document;
    } catch {
      // Local fallback representation if offline or not signed in yet
      return {
        id: `draft-${template.id}-${Date.now()}`,
        title: newDocPayload.title || template.title,
        category: template.category,
        status: 'Draft',
        lastSaved: 'Just now',
        collaborators: [
          { name: 'You (Editor)', initials: 'ME', role: 'Author', avatarColor: 'bg-blue-600' },
        ],
        variables,
        sections: newDocPayload.sections || [],
        suggestions: newDocPayload.suggestions || [],
        comments: [],
        readiness: template.readiness,
      };
    }
  },
};
