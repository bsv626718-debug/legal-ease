import React, { useState } from 'react';
import {
  FileText,
  Home,
  DollarSign,
  Users,
  ShieldCheck,
  Key,
  Paperclip,
  CheckCircle2,
  ArrowLeft,
  Edit,
  Save,
  Eye,
  Send,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Code,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  RotateCcw,
  Sparkles,
  Download,
  AlertCircle,
} from 'lucide-react';
import { LeaseWizardData } from '../../types';
import { initialLeaseData } from '../../data/mockData';
import { api } from '../../lib/api';
import { exportLeaseToPdf } from '../../lib/documentExport';

interface TurboTenantLeaseBuilderProps {
  onBack: () => void;
  onOpenExportPDF: (leaseData: LeaseWizardData) => void;
  onOpenSignature: () => void;
  initialData?: LeaseWizardData;
  docId?: string;
}

export const TurboTenantLeaseBuilder: React.FC<TurboTenantLeaseBuilderProps> = ({
  onBack,
  onOpenExportPDF,
  onOpenSignature,
  initialData,
  docId,
}) => {
  const [leaseData, setLeaseData] = useState<LeaseWizardData>(initialData || initialLeaseData);
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'wizard' | 'customization'>('wizard');
  const [isSaving, setIsSaving] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({
    1: true,
    2: true,
    3: true,
    4: true,
    5: true,
    6: true,
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const stepsConfig = [
    {
      id: 1,
      title: 'Lease Specifics',
      description: 'Verify the address and lease terms.',
      icon: FileText,
    },
    {
      id: 2,
      title: 'Rent, Deposit, & Fees',
      description: 'Set the rent amount, security deposit, and fees.',
      icon: DollarSign,
    },
    {
      id: 3,
      title: 'People on the Lease',
      description: 'Confirm the landlord and tenant info.',
      icon: Users,
    },
    {
      id: 4,
      title: 'Pets, Smoking, & Insurance',
      description: 'Specify pets, smoking policy, and if renters insurance is required.',
      icon: ShieldCheck,
    },
    {
      id: 5,
      title: 'Utilities, Services, & Keys',
      description: 'Choose what is included with the lease.',
      icon: Key,
    },
    {
      id: 6,
      title: 'Provisions & Attachments',
      description: 'Add custom clauses, rules, or attachments specific to your property and/or local area.',
      icon: Paperclip,
    },
  ];

  const handleStepComplete = (stepId: number) => {
    setCompletedSteps((prev) => ({ ...prev, [stepId]: true }));
    setActiveStep(null);
    showToast(`Saved section: ${stepsConfig[stepId - 1].title}`);
  };

  return (
    <div className="flex h-screen w-full bg-slate-100 overflow-hidden font-sans">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* TurboTenant Left Dark Navigation Sidebar (Image 3 exact match) */}
      <aside className="w-52 bg-slate-900 text-slate-300 flex flex-col justify-between shrink-0 select-none text-xs border-r border-slate-800 hidden md:flex">
        <div className="p-4 overflow-y-auto">
          {/* Logo */}
          <div className="flex items-center gap-2 text-white font-bold text-base mb-6">
            <div className="w-6 h-6 rounded bg-blue-600 text-white flex items-center justify-center">
              <Home className="w-4 h-4" />
            </div>
            <span>=turbotenant</span>
          </div>

          {/* Nav Items */}
          <div className="space-y-4">
            <div className="space-y-1">
              <button
                onClick={onBack}
                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-300 text-left cursor-pointer"
              >
                <span>Dashboard</span>
                <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center font-bold">
                  2
                </span>
              </button>
              <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-300 cursor-pointer">Properties</div>
              <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-300 cursor-pointer">Maintenance</div>
              <div className="px-2.5 py-1.5 rounded bg-blue-600/30 text-white font-semibold">Leases</div>
              <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-300 cursor-pointer">Forms</div>
            </div>

            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block px-2.5 mb-1">
                Renters
              </span>
              <div className="space-y-1">
                <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-400 cursor-pointer">Leads</div>
                <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-400 cursor-pointer">Applicants</div>
                <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-400 cursor-pointer">Tenants</div>
              </div>
            </div>

            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block px-2.5 mb-1">
                Financial
              </span>
              <div className="space-y-1">
                <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-400 cursor-pointer">Payments</div>
                <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-400 cursor-pointer">Expenses</div>
                <div onClick={onBack} className="px-2.5 py-1.5 rounded hover:bg-slate-800 text-slate-400 cursor-pointer">Accounting</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Sidebar info */}
        <div className="p-4 border-t border-slate-800 space-y-1 text-slate-400 text-[11px]">
          <div onClick={onBack} className="px-2 py-1 hover:text-white cursor-pointer">Toolbox</div>
          <div onClick={onBack} className="px-2 py-1 hover:text-white cursor-pointer">Education</div>
          <div onClick={onBack} className="px-2 py-1 hover:text-white cursor-pointer">Account</div>
          <div onClick={onBack} className="px-2 py-1 hover:text-white cursor-pointer">Need Help?</div>
          <div className="px-2 py-1 text-amber-400 font-semibold">Earn $25</div>
        </div>
      </aside>

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-slate-50">
        {/* Top Header Bar */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 shadow-2xs">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-bold text-slate-900">
              Create Your Lease Agreement
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={async () => {
                setIsSaving(true);
                try {
                  const docPayload = {
                    title: `Residential Lease - ${leaseData.address || 'Property'}`,
                    category: 'Property' as const,
                    status: 'Draft' as const,
                    variables: [
                      { id: 'v-ra-1', key: 'Landlord Name', label: 'Landlord', value: leaseData.landlordName, defaultValue: 'Landlord', type: 'text' as const },
                      { id: 'v-ra-2', key: 'Tenant Name', label: 'Tenant(s)', value: leaseData.tenantNames, defaultValue: 'Tenant', type: 'text' as const },
                      { id: 'v-ra-3', key: 'Property Address', label: 'Premises', value: `${leaseData.address}, ${leaseData.unit ? leaseData.unit + ', ' : ''}${leaseData.city}, ${leaseData.state} ${leaseData.zip}`, defaultValue: 'Address', type: 'text' as const },
                      { id: 'v-ra-4', key: 'Monthly Rent', label: 'Rent', value: leaseData.monthlyRent, defaultValue: '$1,850.00', type: 'currency' as const },
                      { id: 'v-ra-5', key: 'Security Deposit', label: 'Deposit', value: leaseData.securityDeposit, defaultValue: '$1,850.00', type: 'currency' as const },
                    ],
                    sections: [
                      { id: 'sec-1', number: 1, title: 'Parties and Premises', content: `This agreement is made between ${leaseData.landlordName} and ${leaseData.tenantNames} for ${leaseData.address}.` },
                      { id: 'sec-2', number: 2, title: 'Term and Rent', content: `Lease term from ${leaseData.leaseStartDate} to ${leaseData.leaseEndDate} at ${leaseData.monthlyRent} per month.` },
                      { id: 'sec-3', number: 3, title: 'Deposits and Fees', content: `Security deposit of ${leaseData.securityDeposit}. Pet deposit of ${leaseData.petDeposit}. Late fee: ${leaseData.lateFee}.` },
                      { id: 'sec-4', number: 4, title: 'Rules and Utilities', content: `Utilities included: ${leaseData.utilitiesIncluded.join(', ') || 'None'}. Pets allowed: ${leaseData.petsAllowed ? 'Yes' : 'No'}. Smoking allowed: ${leaseData.smokingAllowed ? 'Yes' : 'No'}.` },
                    ],
                  };

                  if (docId) {
                    await api.documents.update(docId, docPayload);
                  } else {
                    await api.documents.create(docPayload);
                  }
                  showToast('Lease draft saved successfully to your documents!');
                } catch {
                  showToast('Draft saved in local session.');
                } finally {
                  setIsSaving(false);
                }
              }}
              disabled={isSaving}
              className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors uppercase tracking-wider cursor-pointer"
            >
              {isSaving ? 'Saving...' : 'Save & Finish Later'}
            </button>

            <button
              onClick={() => exportLeaseToPdf(leaseData)}
              className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Download PDF"
            >
              <Download className="w-3.5 h-3.5" />
              <span>PDF</span>
            </button>

            <button
              onClick={() => setViewMode(viewMode === 'wizard' ? 'customization' : 'wizard')}
              className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
            >
              {viewMode === 'wizard' ? 'Preview Lease' : 'Revert to Builder'}
            </button>
            <button
              onClick={onOpenSignature}
              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold uppercase tracking-wider shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>Review & E-Sign</span>
            </button>
          </div>
        </header>

        {/* View 1: Guided Checklist Wizard (Image 3 Left side) */}
        {viewMode === 'wizard' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex justify-center">
            <div className="w-full max-w-3xl space-y-6">
              {/* Notice Card: Here's what you need to know */}
              <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-5 text-xs text-slate-700 space-y-2.5">
                <h3 className="font-bold text-slate-900 text-sm">Here&apos;s what you need to know:</h3>
                <ul className="space-y-1.5 text-slate-600 list-disc list-inside">
                  <li>
                    Our Colorado lease agreement was drafted by a professional team of landlords and local lawyers to keep you compliant and covered.
                  </li>
                  <li>
                    Purchase a single-use lease agreement for $29 (e-sign included), or you can get Premium for unlimited lease agreements. Learn about Premium.
                  </li>
                  <li>
                    Once completed, send the lease agreement to your tenants to e-sign or choose to print it instead.
                  </li>
                  <li>
                    Edit the lease agreement, even after you&apos;ve paid, until it&apos;s been signed.
                  </li>
                </ul>
              </div>

              {/* Subheading */}
              <h2 className="text-base font-bold text-slate-900">Complete Each Section</h2>

              {/* Step Cards List (Image 3 exact cards) */}
              <div className="space-y-3">
                {stepsConfig.map((step) => {
                  const Icon = step.icon;
                  const isCompleted = completedSteps[step.id];
                  const isOpen = activeStep === step.id;

                  return (
                    <div
                      key={step.id}
                      className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs hover:border-slate-300 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full border border-blue-200 bg-blue-50/60 text-blue-600 flex items-center justify-center shrink-0">
                            <Icon className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="text-sm font-bold text-slate-900">{step.title}</h3>
                            <p className="text-xs text-slate-500 mt-0.5">{step.description}</p>
                          </div>
                        </div>

                        <button
                          onClick={() => setActiveStep(isOpen ? null : step.id)}
                          className={`px-5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                            isCompleted
                              ? 'border border-blue-600 text-blue-600 hover:bg-blue-50'
                              : 'bg-blue-600 text-white hover:bg-blue-700'
                          }`}
                        >
                          {isOpen ? 'Close' : isCompleted ? 'Edit' : 'Start'}
                        </button>
                      </div>

                      {/* Expanded Section Form */}
                      {isOpen && (
                        <div className="mt-5 pt-5 border-t border-slate-100 text-xs text-slate-700 animate-in fade-in duration-200">
                          {step.id === 1 && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div>
                                <label className="font-semibold block mb-1">Street Address</label>
                                <input
                                  type="text"
                                  value={leaseData.address}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, address: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">City, State, Zip</label>
                                <input
                                  type="text"
                                  value={`${leaseData.city}, ${leaseData.state} ${leaseData.zip}`}
                                  onChange={(e) => {
                                    const parts = e.target.value.split(',');
                                    setLeaseData({
                                      ...leaseData,
                                      city: parts[0]?.trim() || '',
                                      state: parts[1]?.trim().slice(0, 2) || '',
                                    });
                                  }}
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">Lease Start Date</label>
                                <input
                                  type="date"
                                  value={leaseData.leaseStartDate}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, leaseStartDate: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">Lease End Date</label>
                                <input
                                  type="date"
                                  value={leaseData.leaseEndDate}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, leaseEndDate: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                            </div>
                          )}

                          {step.id === 2 && (
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                              <div>
                                <label className="font-semibold block mb-1">Monthly Rent</label>
                                <input
                                  type="text"
                                  value={leaseData.monthlyRent}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, monthlyRent: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">Security Deposit</label>
                                <input
                                  type="text"
                                  value={leaseData.securityDeposit}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, securityDeposit: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">Move-in Fee</label>
                                <input
                                  type="text"
                                  value={leaseData.moveInFee}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, moveInFee: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div className="sm:col-span-3">
                                <label className="font-semibold block mb-1">Late Fee Policy</label>
                                <input
                                  type="text"
                                  value={leaseData.lateFee}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, lateFee: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                            </div>
                          )}

                          {step.id === 3 && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div>
                                <label className="font-semibold block mb-1">Landlord / Entity Name</label>
                                <input
                                  type="text"
                                  value={leaseData.landlordName}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, landlordName: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">Tenant Name(s)</label>
                                <input
                                  type="text"
                                  value={leaseData.tenantNames}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, tenantNames: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                            </div>
                          )}

                          {step.id === 4 && (
                            <div className="space-y-3">
                              <div className="flex items-center gap-4">
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={leaseData.petsAllowed}
                                    onChange={(e) =>
                                      setLeaseData({ ...leaseData, petsAllowed: e.target.checked })
                                    }
                                  />
                                  <span>Pets Allowed</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={leaseData.rentersInsuranceRequired}
                                    onChange={(e) =>
                                      setLeaseData({
                                        ...leaseData,
                                        rentersInsuranceRequired: e.target.checked,
                                      })
                                    }
                                  />
                                  <span>Renters Insurance Required</span>
                                </label>
                              </div>
                              <div>
                                <label className="font-semibold block mb-1">Pet Policy Details</label>
                                <input
                                  type="text"
                                  value={leaseData.petPolicyDetails}
                                  onChange={(e) =>
                                    setLeaseData({ ...leaseData, petPolicyDetails: e.target.value })
                                  }
                                  className="w-full p-2 border border-slate-200 rounded-lg"
                                />
                              </div>
                            </div>
                          )}

                          {step.id === 5 && (
                            <div>
                              <label className="font-semibold block mb-2">Included Utilities</label>
                              <div className="flex flex-wrap gap-2">
                                {['Water & Sewer', 'Trash & Recycling', 'Gas', 'Electricity', 'Internet', 'HOA Dues'].map((util) => {
                                  const isSelected = leaseData.utilitiesIncluded.includes(util);
                                  return (
                                    <button
                                      key={util}
                                      type="button"
                                      onClick={() => {
                                        const next = isSelected
                                          ? leaseData.utilitiesIncluded.filter((u) => u !== util)
                                          : [...leaseData.utilitiesIncluded, util];
                                        setLeaseData({ ...leaseData, utilitiesIncluded: next });
                                      }}
                                      className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                                        isSelected
                                          ? 'bg-blue-600 text-white border-blue-600'
                                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                                      }`}
                                    >
                                      {util}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {step.id === 6 && (
                            <div>
                              <label className="font-semibold block mb-1">
                                Custom Provisions, Rules & Attachments
                              </label>
                              <textarea
                                rows={3}
                                value={leaseData.customClauses}
                                onChange={(e) =>
                                  setLeaseData({ ...leaseData, customClauses: e.target.value })
                                }
                                className="w-full p-2 border border-slate-200 rounded-lg"
                              />
                            </div>
                          )}

                          <div className="mt-4 flex justify-end">
                            <button
                              onClick={() => handleStepComplete(step.id)}
                              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs"
                            >
                              Save Section
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Full Customization Banner (Image 3 bottom card) */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Full Customization</h3>
                  <p className="text-xs text-slate-500 max-w-lg mt-0.5">
                    Available for advanced users that want to fully customize the lease agreement to their needs. You must complete all sections in the builder before customizing the PDF.
                  </p>
                </div>
                <button
                  onClick={() => setViewMode('customization')}
                  className="px-5 py-2.5 rounded-xl border border-slate-300 hover:border-slate-400 bg-slate-50 text-slate-800 text-xs font-bold uppercase tracking-wider flex items-center gap-2 shrink-0 transition-colors"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>Customize</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* View 2: Full Customization & Live Lease Document Preview (Image 3 Right side) */}
        {viewMode === 'customization' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex justify-center">
            <div className="w-full max-w-4xl space-y-6">
              {/* Back to builder header */}
              <div className="flex items-center justify-between">
                <div>
                  <button
                    onClick={() => setViewMode('wizard')}
                    className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1 mb-1"
                  >
                    <ArrowLeft className="w-3 h-3" />
                    <span>BACK TO BUILDER</span>
                  </button>
                  <h2 className="text-xl font-bold text-slate-900">Full Customization</h2>
                  <p className="text-xs text-slate-500 max-w-2xl mt-1">
                    Nice Work! Most users are done by now and go directly to Review and E-sign. Some advanced users want to customize their lease agreement even further and can use this section to unlock full customization to meet their needs.
                  </p>
                </div>
              </div>

              {/* Instructions Callout Box */}
              <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 space-y-1.5">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>Here&apos;s what you need to know:</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-amber-800 text-[11px]">
                  <li>Those that choose this option are typically looking for advanced rules regarding late fees, security deposits, pets, guests, or maintenance that the standard form doesn&apos;t specify.</li>
                  <li>Once Customized, the builder can no longer be used to make edits, only the Advanced Editor.</li>
                  <li>Modifying terms/dates or tenant/landlord/custom signers here will update the legal document live.</li>
                </ul>
              </div>

              {/* WYSIWYG Formatting Toolbar (Image 3 exact toolbar) */}
              <div className="bg-white border border-slate-200 rounded-xl p-2 flex flex-wrap items-center gap-1 text-slate-700 shadow-2xs">
                <button className="p-1.5 rounded hover:bg-slate-100 font-bold" title="Bold">
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100 italic" title="Italic">
                  <Italic className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100 underline" title="Underline">
                  <Underline className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100 line-through" title="Strikethrough">
                  <Strikethrough className="w-3.5 h-3.5" />
                </button>
                <div className="h-4 w-px bg-slate-200 mx-1" />
                <button className="p-1.5 rounded hover:bg-slate-100" title="Code">
                  <Code className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100" title="Bullet List">
                  <List className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100" title="Numbered List">
                  <ListOrdered className="w-3.5 h-3.5" />
                </button>
                <div className="h-4 w-px bg-slate-200 mx-1" />
                <button className="p-1.5 rounded hover:bg-slate-100" title="Align Left">
                  <AlignLeft className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100" title="Align Center">
                  <AlignCenter className="w-3.5 h-3.5" />
                </button>
                <button className="p-1.5 rounded hover:bg-slate-100" title="Align Right">
                  <AlignRight className="w-3.5 h-3.5" />
                </button>
                <div className="h-4 w-px bg-slate-200 mx-1" />
                <span className="text-xs text-slate-500 px-2">Font: Inter</span>
                <span className="text-xs text-slate-500 px-2">Size: 11pt</span>
              </div>

              {/* Document Sheet with Watermark (Image 3 exact paper sheet) */}
              <div className="document-sheet relative bg-white p-8 sm:p-12 rounded-xl shadow-lg border border-slate-200 text-slate-800 space-y-6 overflow-hidden">
                {/* Diagonal Draft Watermark (Image 3) */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-5 rotate-[-30deg]">
                  <span className="text-9xl font-black text-slate-900 tracking-widest">
                    DRAFT
                  </span>
                </div>

                {/* Subtitle Draft Notice */}
                <div className="text-center text-[10px] text-slate-400 uppercase tracking-widest pb-3 border-b border-slate-100">
                  DRAFT Rental Agreement for review only. NOT LEGALLY BINDING. COPYRIGHT {new Date().getFullYear()} LegalEase.
                </div>

                {/* Agreement Title */}
                <div className="text-center space-y-1">
                  <h2 className="text-lg font-bold text-slate-900">
                    Rental Agreement between:
                  </h2>
                  <div className="text-sm font-semibold text-blue-700 bg-blue-50 py-1 px-3 rounded-lg inline-block">
                    {leaseData.landlordName} (Landlord) and {leaseData.tenantNames} (Tenant)
                  </div>
                  <p className="text-xs text-slate-500">Dated: {leaseData.leaseStartDate}</p>
                </div>

                {/* Summary of Key Information Table (Image 3 exact table) */}
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Summary of Key Information
                  </h3>
                  <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                    <table className="w-full text-left border-collapse">
                      <tbody>
                        <tr className="border-b border-slate-200 bg-slate-50/70">
                          <td className="p-2.5 font-bold text-slate-700 w-1/3">Property Address:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.address}, {leaseData.unit}, {leaseData.city}, {leaseData.state} {leaseData.zip}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.5</td>
                        </tr>
                        <tr className="border-b border-slate-200">
                          <td className="p-2.5 font-bold text-slate-700">Lease Start Date:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.leaseStartDate}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.5</td>
                        </tr>
                        <tr className="border-b border-slate-200 bg-slate-50/70">
                          <td className="p-2.5 font-bold text-slate-700">Lease End Date:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.leaseEndDate}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.5</td>
                        </tr>
                        <tr className="border-b border-slate-200">
                          <td className="p-2.5 font-bold text-slate-700">Total Monthly Rent:</td>
                          <td className="p-2.5 text-slate-900 font-semibold">{leaseData.monthlyRent}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.6</td>
                        </tr>
                        <tr className="border-b border-slate-200 bg-slate-50/70">
                          <td className="p-2.5 font-bold text-slate-700">Security Deposit:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.securityDeposit}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.8</td>
                        </tr>
                        <tr className="border-b border-slate-200">
                          <td className="p-2.5 font-bold text-slate-700">Pet Deposit:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.petDeposit || 'N/A'}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.8</td>
                        </tr>
                        <tr className="border-b border-slate-200 bg-slate-50/70">
                          <td className="p-2.5 font-bold text-slate-700">Move-in Fee Amount:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.moveInFee || 'N/A'}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 1.9</td>
                        </tr>
                        <tr>
                          <td className="p-2.5 font-bold text-slate-700">Late Fee:</td>
                          <td className="p-2.5 text-slate-900">{leaseData.lateFee}</td>
                          <td className="p-2.5 text-blue-600 text-right text-[11px]">See section 2.1</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <p className="text-[11px] text-slate-400 italic mt-2">
                    The above summary table is provided as a reference. The Agreement will control if there is a conflict.
                  </p>
                </div>

                {/* Detailed Clauses */}
                <div className="space-y-4 text-xs text-slate-700 leading-relaxed pt-4 border-t border-slate-200">
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">1. Premises and Term</h4>
                    <p>
                      Landlord hereby leases to Tenant, and Tenant hereby leases from Landlord, the residential premises located at {leaseData.address}, {leaseData.city}, {leaseData.state}. The term shall commence on {leaseData.leaseStartDate} and expire on {leaseData.leaseEndDate}.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">2. Rent and Payment Terms</h4>
                    <p>
                      Tenant agrees to pay monthly rent of {leaseData.monthlyRent} in advance on or before the 1st day of each calendar month. Payments made after the grace period shall incur the late fee specified above.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">3. Security Deposit</h4>
                    <p>
                      Upon execution of this Lease, Tenant shall deposit with Landlord the sum of {leaseData.securityDeposit} as security for the faithful performance by Tenant of the terms and conditions of this Agreement.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">4. Rules, Pets & Insurance</h4>
                    <p>
                      {leaseData.petsAllowed
                        ? `Pets are permitted subject to the following rules: ${leaseData.petPolicyDetails}.`
                        : 'No animals or pets of any kind are permitted on the Premises without written consent.'}{' '}
                      {leaseData.rentersInsuranceRequired
                        ? 'Tenant is required to maintain a renter\'s liability insurance policy with a minimum coverage limit of $100,000.'
                        : ''}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">5. Utilities & Services</h4>
                    <p>
                      Landlord shall be responsible for: {leaseData.utilitiesIncluded.join(', ') || 'None'}. Tenant shall be responsible for all other utility hookups and monthly consumption charges.
                    </p>
                  </div>

                  {leaseData.customClauses && (
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">6. Special Provisions</h4>
                      <p>{leaseData.customClauses}</p>
                    </div>
                  )}
                </div>

                {/* Action Buttons at bottom of customization page */}
                <div className="pt-8 border-t border-slate-200 flex items-center justify-between">
                  <button
                    onClick={() => setViewMode('wizard')}
                    className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold uppercase tracking-wider hover:bg-slate-50 transition-colors"
                  >
                    Revert to Builder
                  </button>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onOpenExportPDF(leaseData)}
                      className="px-5 py-2.5 rounded-xl border border-blue-600 text-blue-600 text-xs font-bold uppercase tracking-wider hover:bg-blue-50 flex items-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PDF</span>
                    </button>
                    <button
                      onClick={onOpenSignature}
                      className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold uppercase tracking-wider shadow-sm flex items-center gap-2 transition-colors"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Save & Preview E-Sign</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
