import React from 'react';
import { Scale, ShieldCheck, Lock, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: 'landing' | 'editor' | 'lease-wizard' | 'dashboard' | 'templates') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Scale className="w-5 h-5 stroke-[2.2]" />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">
                Legal<span className="text-blue-500">Ease</span>
              </span>
            </div>
            <p className="text-slate-400 text-sm max-w-sm leading-relaxed">
              AI-powered legal document drafting platform helping individuals, freelancers, and businesses draft high-fidelity legal agreements in minutes.
            </p>
            <div className="flex items-center gap-4 text-xs text-slate-500 pt-2">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                256-Bit SSL Encryption
              </span>
              <span className="flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-blue-400" />
                SOC2 Type II Ready
              </span>
            </div>
          </div>

          {/* Popular Documents */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Documents
            </h4>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => onNavigate('lease-wizard')}
                  className="hover:text-white transition-colors"
                >
                  Rental Agreement
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-white transition-colors"
                >
                  Master Service Agreement
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-white transition-colors"
                >
                  Non-Disclosure Agreement
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('templates')}
                  className="hover:text-white transition-colors"
                >
                  Employment Contract
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('templates')}
                  className="hover:text-white transition-colors"
                >
                  Last Will & Testament
                </button>
              </li>
            </ul>
          </div>

          {/* Platform */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Platform
            </h4>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-white transition-colors"
                >
                  AI Document Studio
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="hover:text-white transition-colors"
                >
                  User Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('templates')}
                  className="hover:text-white transition-colors"
                >
                  Template Library
                </button>
              </li>
              <li>
                <a href="#pricing" className="hover:text-white transition-colors">
                  Pricing Plans
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-white transition-colors">
                  Security & Compliance
                </a>
              </li>
            </ul>
          </div>

          {/* Legal & Notice */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Legal Disclaimer
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              LegalEase provides automated legal document drafting tools and templates. LegalEase is not a law firm and does not provide legal advice. Use of this service is subject to our Terms of Service and Privacy Policy.
            </p>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500">
          <p>© {new Date().getFullYear()} LegalEase Inc. All rights reserved.</p>
          <div className="flex items-center gap-6 mt-4 sm:mt-0">
            <a href="#" className="hover:text-slate-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-slate-400 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-slate-400 transition-colors">Security</a>
            <a href="#" className="hover:text-slate-400 transition-colors">Contact Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
