import bcrypt from 'bcryptjs';
import { db } from './db.ts';
import type { UserRecord, DocumentRecord } from './db.ts';

export async function seedInitialData() {
  const users = db.getUsers();
  if (users.length === 0) {
    console.log('Seeding initial LegalEase users and sample documents...');

    // 1. Regular User: Vinay
    const vinayPasswordHash = await bcrypt.hash('Password123!', 10);
    const vinayUser: UserRecord = {
      id: 'usr-vinay-001',
      name: 'Vinay Kumar',
      email: 'bsv626718@gmail.com',
      passwordHash: vinayPasswordHash,
      role: 'user',
      emailVerified: true,
      subscriptionPlan: 'pro',
      createdAt: new Date().toISOString(),
    };
    db.createUser(vinayUser);

    // 2. Admin User: Sarah Chen
    const sarahPasswordHash = await bcrypt.hash('AdminSecure2026!', 10);
    const sarahUser: UserRecord = {
      id: 'usr-sarah-002',
      name: 'Sarah Chen',
      email: 'sarah.chen@vertextech.com',
      passwordHash: sarahPasswordHash,
      role: 'admin',
      emailVerified: true,
      subscriptionPlan: 'enterprise',
      createdAt: new Date().toISOString(),
    };
    db.createUser(sarahUser);

    // Seed Initial Documents for Vinay
    const sampleDoc1: DocumentRecord = {
      id: 'doc-msa-001',
      userId: vinayUser.id,
      title: 'Master Service Agreement',
      category: 'Business',
      status: 'Draft',
      lastSaved: '2 min ago',
      variables: [
        { id: 'v-1', key: 'Effective Date', label: 'Effective Date', value: 'October 1, 2026', defaultValue: 'October 1, 2026', type: 'date' },
        { id: 'v-2', key: 'Company Name', label: 'Company Name', value: 'Vertex Technologies Inc.', defaultValue: 'Vertex Technologies Inc.', type: 'text' },
        { id: 'v-3', key: 'Governing Law', label: 'Governing Law', value: 'State of Delaware', defaultValue: 'State of Delaware', type: 'text' },
        { id: 'v-4', key: 'Counterparty', label: 'Counterparty', value: 'Apex Solutions LLC', defaultValue: 'Apex Solutions LLC', type: 'text' },
      ],
      sections: [
        {
          id: 'sec-1',
          number: 1,
          title: 'Parties',
          content: 'This Agreement is made between {{Company Name}}, having its principal place of business at 123 Innovation Drive, Suite 400, San Francisco, CA 94105 (hereinafter referred to as the "Client"), and {{Counterparty}}, having its principal place of business at 456 Enterprise Blvd, New York, NY 10001 (hereinafter referred to as the "Service Provider"). Each Party represents and warrants that it has full authority to enter into and perform its obligations under this Agreement.',
        },
        {
          id: 'sec-2',
          number: 2,
          title: 'Scope of Services',
          content: 'The Service Provider agrees to provide professional consulting, software development, and related technology services as described in each Statement of Work ("SOW") executed under this Agreement. Each SOW shall describe the specific services to be performed, deliverables, timelines, milestones, acceptance criteria, and any applicable fees. In the event of a conflict between the terms of this Agreement and any SOW, the terms of this Agreement shall prevail unless the SOW expressly states otherwise and is signed by both Parties.',
        },
        {
          id: 'sec-3',
          number: 3,
          title: 'Deliverables',
          content: 'All deliverables shall be provided in accordance with the specifications, timelines, and quality standards set forth in the applicable SOW. The Client shall have a review period of fifteen (15) business days following receipt of each deliverable to evaluate and test the deliverable against the agreed acceptance criteria. Written notice of acceptance or specific non-conformities shall be provided before expiration of the review period.',
        },
        {
          id: 'sec-4',
          number: 4,
          title: 'Fees and Payment',
          content: 'Client shall pay Service Provider the fees specified in each Statement of Work. Invoices will be rendered on a monthly basis or upon completion of defined project milestones. Payment terms are net thirty (30) days from invoice date. Any undisputed sums overdue shall accrue interest at the lesser of one and one-half percent (1.5%) per month or the highest statutory rate permitted under governing law.',
        },
        {
          id: 'sec-5',
          number: 5,
          title: 'Confidentiality',
          content: 'Each Party agrees to safeguard the Confidential Information of the other Party with the same degree of care it uses for its own confidential information, but in no event less than reasonable care, for a period of five (5) years following termination of this Agreement. Trade secrets shall remain protected for as long as they retain trade secret status under applicable law.',
        },
        {
          id: 'sec-6',
          number: 6,
          title: 'Intellectual Property',
          content: 'Upon receipt of full payment, Service Provider hereby assigns to Client all right, title, and interest in and to the custom deliverables, works of authorship, and inventions developed specifically for Client under an executed SOW ("Work Product"). Service Provider retains all rights in its pre-existing tools, libraries, methodologies, and know-how.',
        },
        {
          id: 'sec-7',
          number: 7,
          title: 'Term and Termination',
          content: 'This Agreement shall commence on the Effective Date and remain in effect for an initial period of one (1) year, automatically renewing for successive one-year terms unless either Party provides written notice of non-renewal at least thirty (30) days prior to the expiration of the then-current term. Either Party may terminate for material breach upon thirty (30) days written notice and opportunity to cure.',
        },
        {
          id: 'sec-8',
          number: 8,
          title: 'Limitation of Liability',
          content: 'To the maximum extent permitted by applicable law, neither Party shall be liable to the other for any indirect, consequential, special, punitive, or exemplary damages. The aggregate liability of either Party arising out of or related to this Agreement shall be limited to the total fees paid by Client under the applicable SOW in the twelve (12) months preceding the incident.',
        },
      ],
      suggestions: [
        {
          id: 'sug-1',
          type: 'gdpr',
          color: 'red',
          title: 'Add a data protection clause to comply with GDPR requirements',
          actionText: 'Add clause →',
          clauseToAdd: 'Data Protection & Privacy. Each Party agrees to comply with all applicable data privacy laws, including the European Union General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA). Any processing of personal data transferred under this Agreement shall occur strictly in accordance with the Data Processing Addendum attached hereto as Exhibit B.',
        },
        {
          id: 'sug-2',
          type: 'liability',
          color: 'yellow',
          title: 'Strengthen the liability cap — current language may not hold in all jurisdictions',
          actionText: 'Improve →',
          clauseToAdd: 'Except for breach of confidentiality obligations or willful misconduct, neither Party\'s aggregate cumulative liability arising out of or related to this Agreement shall exceed the total amount actually paid or payable by Client to Service Provider under the applicable Statement of Work during the preceding twelve (12) months.',
          sectionTarget: 8,
        },
        {
          id: 'sug-3',
          type: 'dispute',
          color: 'blue',
          title: 'Add dispute resolution clause with arbitration as the default mechanism',
          actionText: 'Add clause →',
          clauseToAdd: 'Dispute Resolution & Arbitration. Any dispute, claim, or controversy arising out of or relating to this Agreement shall be resolved through confidential, binding arbitration administered by JAMS in Wilmington, Delaware, under its Comprehensive Arbitration Rules and Procedures.',
        },
        {
          id: 'sug-4',
          type: 'confidentiality',
          color: 'purple',
          title: 'Your confidentiality period (5 years) is standard — consider extending to 7 years for IP-heavy work',
          actionText: 'Review →',
          clauseToAdd: 'Each Party agrees to safeguard the Confidential Information of the other Party with the same degree of care it uses for its own confidential information of like kind, but not less than reasonable care, for a period of seven (7) years following the termination or expiration of this Agreement, provided that trade secrets shall remain protected indefinitely.',
          sectionTarget: 5,
        },
      ],
      comments: [
        {
          id: 'c-1',
          author: 'Sarah Chen',
          initials: 'SC',
          avatarColor: 'bg-blue-600',
          text: 'Please ensure the IP indemnification caps match our master client terms before final review.',
          timestamp: 'Today at 9:42 AM',
        },
        {
          id: 'c-2',
          author: 'John O\'Connor',
          initials: 'JO',
          avatarColor: 'bg-amber-600',
          text: 'Governing law Delaware is approved. Double-check Section 4 milestone deliverables schedule.',
          timestamp: 'Today at 10:15 AM',
        },
      ],
      readiness: {
        completed: 5,
        total: 7,
        items: [
          { label: 'All parties defined', done: true },
          { label: 'Payment terms set', done: true },
          { label: 'Confidentiality clause included', done: true },
          { label: 'IP assignment clarified', done: true },
          { label: 'Termination terms specified', done: true },
          { label: 'All variables filled', done: false },
          { label: 'Signature blocks ready', done: false },
        ],
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    db.createDocument(sampleDoc1);

    // Initial audit log
    db.createAuditLog({
      userId: 'system',
      userEmail: 'system@legalease.app',
      action: 'SYSTEM_BOOTSTRAP',
      details: 'System bootstrapped with sample user and admin records',
    });
  }
}
