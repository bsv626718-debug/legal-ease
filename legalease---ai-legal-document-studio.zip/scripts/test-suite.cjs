const http = require('http');

const PORT = 3000;
const BASE_URL = `http://localhost:${PORT}`;

function makeRequest(path, options = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const reqOptions = {
      method: options.method || 'GET',
      headers: options.headers || {},
    };

    const req = http.request(url, reqOptions, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        let json;
        try {
          json = JSON.parse(body);
        } catch {
          json = null;
        }
        resolve({
          status: res.statusCode,
          headers: res.headers,
          data: json,
          text: body,
        });
      });
    });

    req.on('error', reject);

    if (options.body) {
      req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    }
    req.end();
  });
}

async function runTests() {
  console.log('==================================================');
  console.log('LEGALEASE AUTOMATED SYSTEM & INTEGRATION TEST SUITE');
  console.log('==================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  try {
    // ----------------------------------------------------
    // TEST SUITE 1: TEMPLATE ENGINE & MULTI-ID LOADING
    // ----------------------------------------------------
    console.log('\n--- 1. Testing Template Engine & Catalog ---');

    const tplListRes = await makeRequest('/api/templates');
    assert(tplListRes.status === 200, 'GET /api/templates returns HTTP 200');
    assert(Array.isArray(tplListRes.data?.templates), 'Template catalog returns an array of templates');
    assert(tplListRes.data.templates.length >= 8, `Catalog contains ${tplListRes.data?.templates?.length} audited templates`);

    const requiredTemplateIds = [
      'rental-agreement',
      'nda',
      'employment-contract',
      'business-partnership',
      'last-will',
      'power-of-attorney',
      'contractor-agreement',
      'cease-and-desist',
      'master-service-agreement',
    ];

    for (const tid of requiredTemplateIds) {
      const singleTpl = await makeRequest(`/api/templates/${tid}`);
      assert(
        singleTpl.status === 200 && singleTpl.data?.template?.id === tid,
        `Template "${tid}" loads successfully with valid structure`
      );
      assert(
        Array.isArray(singleTpl.data?.template?.sections) && singleTpl.data.template.sections.length > 0,
        `Template "${tid}" contains numbered legal sections`
      );
      assert(
        Array.isArray(singleTpl.data?.template?.variables) && singleTpl.data.template.variables.length > 0,
        `Template "${tid}" contains customizable variables`
      );
    }

    // Invalid template ID error handling
    const invalidTpl = await makeRequest('/api/templates/non-existent-template-id');
    assert(invalidTpl.status === 404, 'Invalid template ID returns HTTP 404');
    assert(invalidTpl.data?.error?.includes('not found'), 'Invalid template ID returns helpful error message');

    // ----------------------------------------------------
    // TEST SUITE 2: AUTHENTICATION LIFECYCLE & SECURITY
    // ----------------------------------------------------
    console.log('\n--- 2. Testing Authentication & User Persistence ---');

    const testUserEmail = `qa_test_${Date.now()}@example.com`;
    const testUserPassword = 'SecurePassword2026!';

    // Register
    const regRes = await makeRequest('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: {
        name: 'Jordan Miller',
        email: testUserEmail,
        password: testUserPassword,
      },
    });
    assert(regRes.status === 201, 'User registration returns HTTP 201 Created');
    assert(regRes.data?.token && regRes.data?.user?.email === testUserEmail, 'Registration returns signed session token and user profile');
    const userToken = regRes.data.token;
    const authHeaders = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${userToken}`,
    };

    // Verify session persistence
    const meRes = await makeRequest('/api/auth/me', { headers: authHeaders });
    assert(meRes.status === 200 && meRes.data?.user?.email === testUserEmail, '/api/auth/me returns authenticated user details');

    // Profile update
    const updateProfileRes = await makeRequest('/api/auth/profile', {
      method: 'PATCH',
      headers: authHeaders,
      body: { name: 'Jordan K. Miller' },
    });
    assert(updateProfileRes.status === 200 && updateProfileRes.data?.user?.name === 'Jordan K. Miller', 'Profile name update persists correctly');

    // ----------------------------------------------------
    // TEST SUITE 3: DOCUMENT INSTANTIATION & OWNERSHIP
    // ----------------------------------------------------
    console.log('\n--- 3. Testing Document Creation & Access Control ---');

    // Instantiate Rental Agreement template
    const instantiateRes = await makeRequest('/api/templates/rental-agreement/instantiate', {
      method: 'POST',
      headers: authHeaders,
      body: {
        title: 'Residential Lease - 1182 S Reed St',
        initialVariables: {
          'Landlord Name': 'Frankie Mondo Properties LLC',
          'Tenant Name': 'Marcus Vance',
          'Monthly Rent': '$1,850.00',
        },
      },
    });
    assert(instantiateRes.status === 201, 'Instantiating Rental Agreement returns HTTP 201');
    const rentalDoc = instantiateRes.data?.document;
    assert(rentalDoc?.id && rentalDoc.title === 'Residential Lease - 1182 S Reed St', 'Rental agreement document saved with correct title');
    assert(rentalDoc?.sections?.length >= 8, 'Rental agreement document contains all complete legal clauses');

    // Retrieve document by ID
    const getDocRes = await makeRequest(`/api/documents/${rentalDoc.id}`, { headers: authHeaders });
    assert(getDocRes.status === 200 && getDocRes.data?.document?.id === rentalDoc.id, 'User can retrieve their own saved document');

    // Cross-user authorization check (Unauthenticated or other user)
    const unauthorizedGet = await makeRequest(`/api/documents/${rentalDoc.id}`);
    assert(unauthorizedGet.status === 401, 'Unauthenticated request to user document is rejected with HTTP 401');

    // Another user attempting to access document
    const otherUserEmail = `other_tenant_${Date.now()}@example.com`;
    const otherReg = await makeRequest('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: { name: 'Other User', email: otherUserEmail, password: 'OtherPassword123!' },
    });
    const otherHeaders = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${otherReg.data.token}`,
    };

    const crossUserGet = await makeRequest(`/api/documents/${rentalDoc.id}`, { headers: otherHeaders });
    assert(crossUserGet.status === 403, 'Cross-user document access is strictly blocked with HTTP 403 Forbidden');

    // ----------------------------------------------------
    // TEST SUITE 4: AI DOCUMENT GENERATION PIPELINE
    // ----------------------------------------------------
    console.log('\n--- 4. Testing AI Document Generation Pipeline ---');

    const aiPromptRes = await makeRequest('/api/ai/generate', {
      method: 'POST',
      headers: authHeaders,
      body: {
        documentType: 'Non-Disclosure Agreement for Proprietary Software',
        parties: 'Vertex Technologies Inc. & Apex Innovations LLC',
        jurisdiction: 'Delaware',
        keyTerms: '5-year trade secret duration',
      },
    });
    assert(aiPromptRes.status === 200, 'AI generate draft returns HTTP 200');
    assert(Array.isArray(aiPromptRes.data?.sections) && aiPromptRes.data.sections.length > 0, 'Generated draft contains structured sections');
    assert(Array.isArray(aiPromptRes.data?.variables) && aiPromptRes.data.variables.length > 0, 'Generated draft contains structured transaction variables');

    // Clause rewrite
    const rewriteRes = await makeRequest('/api/ai/rewrite', {
      method: 'POST',
      headers: authHeaders,
      body: {
        text: 'The parties agree to hold information confidential for 5 years.',
        tone: 'Protective',
      },
    });
    assert(rewriteRes.status === 200 && typeof rewriteRes.data?.rewritten === 'string', 'AI rewrite returns transformed clause string');

    // ----------------------------------------------------
    // SUMMARY
    // ----------------------------------------------------
    console.log('\n==================================================');
    console.log(`TOTAL TESTS: ${passed + failed}`);
    console.log(`PASSED: ${passed}`);
    console.log(`FAILED: ${failed}`);
    console.log('==================================================\n');

    process.exit(failed > 0 ? 1 : 0);
  } catch (err) {
    console.error('Test execution failed:', err);
    process.exit(1);
  }
}

runTests();
