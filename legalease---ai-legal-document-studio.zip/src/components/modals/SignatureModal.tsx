import React, { useState, useRef, useEffect } from 'react';
import { X, Check, ShieldCheck, PenTool, Type, RefreshCw, Send, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { LegalDocument } from '../../types';

interface SignatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentTitle: string;
}

export const SignatureModal: React.FC<SignatureModalProps> = ({
  isOpen,
  onClose,
  documentTitle,
}) => {
  const [signatureMode, setSignatureMode] = useState<'draw' | 'type'>('type');
  const [typedName, setTypedName] = useState('Sarah Chen');
  const [signerEmail, setSignerEmail] = useState('sarah.chen@vertextech.com');
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [isSigned, setIsSigned] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  useEffect(() => {
    if (signatureMode === 'draw' && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#1e3a8a';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
      }
    }
  }, [signatureMode]);

  if (!isOpen) return null;

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const handleCompleteSign = () => {
    setIsSigned(true);
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }
    setTimeout(() => {
      onClose();
      setIsSigned(false);
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">E-Sign Document</h3>
              <p className="text-xs text-slate-400">{documentTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {isSigned ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">Document Successfully Executed!</h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Cryptographic timestamp and digital audit certificate attached. Returning to editor...
              </p>
            </div>
          ) : (
            <>
              {/* Signer inputs */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Signer Legal Name</label>
                  <input
                    type="text"
                    value={typedName}
                    onChange={(e) => setTypedName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Email Address</label>
                  <input
                    type="email"
                    value={signerEmail}
                    onChange={(e) => setSignerEmail(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Mode Switcher */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="font-bold text-slate-800">Create Your Signature</span>
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                  <button
                    onClick={() => setSignatureMode('type')}
                    className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-colors ${
                      signatureMode === 'type' ? 'bg-white shadow-2xs text-blue-600' : 'text-slate-600'
                    }`}
                  >
                    <Type className="w-3.5 h-3.5" />
                    Type
                  </button>
                  <button
                    onClick={() => setSignatureMode('draw')}
                    className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-colors ${
                      signatureMode === 'draw' ? 'bg-white shadow-2xs text-blue-600' : 'text-slate-600'
                    }`}
                  >
                    <PenTool className="w-3.5 h-3.5" />
                    Draw
                  </button>
                </div>
              </div>

              {/* Signature Field */}
              {signatureMode === 'type' ? (
                <div className="h-32 border-2 border-dashed border-slate-300 rounded-2xl flex items-center justify-center bg-slate-50/50 p-4">
                  <span className="font-serif italic text-3xl sm:text-4xl text-blue-900 tracking-wide select-none">
                    {typedName || 'Sign Here'}
                  </span>
                </div>
              ) : (
                <div className="relative">
                  <canvas
                    ref={canvasRef}
                    width={440}
                    height={128}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    className="w-full h-32 border-2 border-dashed border-slate-300 rounded-2xl bg-white cursor-crosshair"
                  />
                  <button
                    onClick={clearCanvas}
                    className="absolute top-2 right-2 text-[10px] text-slate-500 hover:text-slate-800 bg-white/90 border border-slate-200 px-2 py-0.5 rounded shadow-2xs flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> Clear
                  </button>
                </div>
              )}

              {/* Compliance Checkbox */}
              <label className="flex items-start gap-2.5 text-xs text-slate-600 cursor-pointer pt-2">
                <input
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
                />
                <span>
                  I agree that this electronic signature is as legally binding as a handwritten physical signature under the US ESIGN Act and UETA regulations.
                </span>
              </label>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCompleteSign}
                  disabled={!agreedToTerms || !typedName.trim()}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Adopt & Sign Document</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
