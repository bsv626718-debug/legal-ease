import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { Document as DocxDocument, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { db } from './server/db.ts';
import type { UserRecord, DocumentRecord } from './server/db.ts';
import { seedInitialData } from './server/seed.ts';
import {
  authMiddleware,
  optionalAuthMiddleware,
  requireAdminMiddleware,
  generateToken,
} from './server/auth.ts';
import type { AuthenticatedRequest } from './server/auth.ts';
import {
  generateContractDraft,
  rewriteClause,
  contractAssistantChat,
} from './server/ai.ts';
import { LEGAL_TEMPLATES } from './server/templates.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

// Seed initial database
await seedInitialData();

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// ==========================================
// 1. AUTHENTICATION ENDPOINTS (/api/auth/*)
// ==========================================

// Register
app.post('/api/auth/register', async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({ error: 'Please provide a valid full name (min 2 characters).' });
    }
    if (!email || typeof email !== 'string' || !email.includes('@')) {
      return res.status(400).json({ error: 'Please provide a valid email address.' });
    }
    if (!password || typeof password !== 'string' || password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const existing = db.findUserByEmail(normalizedEmail);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email address already exists. Please log in.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const newUser: UserRecord = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: normalizedEmail,
      passwordHash,
      role: 'user',
      emailVerified: true,
      subscriptionPlan: 'free',
      createdAt: new Date().toISOString(),
    };

    db.createUser(newUser);

    db.createAuditLog({
      userId: newUser.id,
      userEmail: newUser.email,
      action: 'USER_REGISTERED',
      details: `User registered with name ${newUser.name}`,
      ipAddress: req.ip,
    });

    const token = generateToken(newUser);
    res.cookie('legalease_session', token, {
      httpOnly: true,
      secure: isProd,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.status(201).json({
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        subscriptionPlan: newUser.subscriptionPlan,
        emailVerified: newUser.emailVerified,
      },
      token,
      message: 'Account created successfully.',
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Failed to create account. Please try again.' });
  }
});

// Login
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Please enter both email and password.' });
    }

    const user = db.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) {
      db.createAuditLog({
        userId: user.id,
        userEmail: user.email,
        action: 'FAILED_LOGIN_ATTEMPT',
        details: 'Incorrect password entered',
        ipAddress: req.ip,
      });
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    db.createAuditLog({
      userId: user.id,
      userEmail: user.email,
      action: 'USER_LOGIN_SUCCESS',
      details: 'Logged in successfully',
      ipAddress: req.ip,
    });

    const token = generateToken(user);
    res.cookie('legalease_session', token, {
      httpOnly: true,
      secure: isProd,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        subscriptionPlan: user.subscriptionPlan,
        emailVerified: user.emailVerified,
      },
      token,
      message: 'Logged in successfully.',
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Authentication failed. Please try again.' });
  }
});

// Logout
app.post('/api/auth/logout', (req: AuthenticatedRequest, res: Response) => {
  if (req.user) {
    db.createAuditLog({
      userId: req.user.id,
      userEmail: req.user.email,
      action: 'USER_LOGOUT',
      details: 'User logged out',
    });
  }
  res.clearCookie('legalease_session');
  return res.json({ success: true, message: 'Logged out successfully.' });
});

// Get Current User (Session check)
app.get('/api/auth/me', optionalAuthMiddleware, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.json({ user: null });
  }
  return res.json({
    user: {
      id: req.user.id,
      name: req.user.name,
      email: req.user.email,
      role: req.user.role,
      subscriptionPlan: req.user.subscriptionPlan,
      emailVerified: req.user.emailVerified,
    },
  });
});

// Forgot Password
app.post('/api/auth/forgot-password', (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }

    const user = db.findUserByEmail(email);
    if (!user) {
      // Return safe message without exposing whether user exists
      return res.json({
        success: true,
        message: 'If an account with that email exists, password reset instructions have been sent.',
      });
    }

    const resetToken = crypto.randomBytes(24).toString('hex');
    const resetTokenExpiry = Date.now() + 60 * 60 * 1000; // 1 hour

    db.updateUser(user.id, { resetToken, resetTokenExpiry });

    db.createAuditLog({
      userId: user.id,
      userEmail: user.email,
      action: 'PASSWORD_RESET_REQUESTED',
      details: 'Generated password reset token',
    });

    return res.json({
      success: true,
      message: 'Password reset link has been dispatched to your email address.',
      resetToken, // Returned in API for easy demo/testing flow
    });
  } catch (err: any) {
    console.error('Forgot password error:', err);
    return res.status(500).json({ error: 'Failed to process password reset request.' });
  }
});

// Reset Password
app.post('/api/auth/reset-password', async (req: Request, res: Response) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) {
      return res.status(400).json({ error: 'Reset token and new password are required.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    }

    const user = db.findUserByResetToken(token);
    if (!user) {
      return res.status(400).json({ error: 'Password reset token is invalid or has expired.' });
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    db.updateUser(user.id, {
      passwordHash,
      resetToken: undefined,
      resetTokenExpiry: undefined,
    });

    db.createAuditLog({
      userId: user.id,
      userEmail: user.email,
      action: 'PASSWORD_RESET_SUCCESS',
      details: 'Password was successfully changed via reset token',
    });

    return res.json({
      success: true,
      message: 'Password reset successful. You may now log in with your new credentials.',
    });
  } catch (err: any) {
    console.error('Reset password error:', err);
    return res.status(500).json({ error: 'Failed to reset password.' });
  }
});

// Update Profile
app.patch('/api/auth/profile', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, email } = req.body;
    const userId = req.user!.id;

    const updates: Partial<UserRecord> = {};
    if (name && typeof name === 'string' && name.trim().length >= 2) {
      updates.name = name.trim();
    }
    if (email && typeof email === 'string' && email.includes('@')) {
      const normalized = email.toLowerCase().trim();
      const existing = db.findUserByEmail(normalized);
      if (existing && existing.id !== userId) {
        return res.status(409).json({ error: 'Email is already taken by another account.' });
      }
      updates.email = normalized;
    }

    const updated = db.updateUser(userId, updates);
    if (!updated) {
      return res.status(404).json({ error: 'User not found.' });
    }

    db.createAuditLog({
      userId,
      userEmail: updated.email,
      action: 'PROFILE_UPDATED',
      details: 'User updated profile attributes',
    });

    return res.json({
      user: {
        id: updated.id,
        name: updated.name,
        email: updated.email,
        role: updated.role,
        subscriptionPlan: updated.subscriptionPlan,
        emailVerified: updated.emailVerified,
      },
      message: 'Profile updated successfully.',
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to update profile.' });
  }
});

// Change Password
app.post('/api/auth/change-password', authMiddleware, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Please provide both current and new passwords.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    }

    const user = req.user!;
    const match = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!match) {
      return res.status(400).json({ error: 'Current password is incorrect.' });
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    db.updateUser(user.id, { passwordHash });

    db.createAuditLog({
      userId: user.id,
      userEmail: user.email,
      action: 'PASSWORD_CHANGED',
      details: 'Password changed by user in settings',
    });

    return res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to update password.' });
  }
});

// Delete Account
app.delete('/api/auth/delete-account', authMiddleware, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { confirmPassword } = req.body;
    const user = req.user!;

    if (!confirmPassword) {
      return res.status(400).json({ error: 'Please confirm your current password to proceed with deletion.' });
    }

    const match = await bcrypt.compare(confirmPassword, user.passwordHash);
    if (!match) {
      return res.status(400).json({ error: 'Confirmation password does not match.' });
    }

    db.createAuditLog({
      userId: user.id,
      userEmail: user.email,
      action: 'ACCOUNT_DELETED',
      details: 'Account and associated records permanently deleted',
    });

    db.deleteUser(user.id);
    res.clearCookie('legalease_session');

    return res.json({ success: true, message: 'Account and all saved documents deleted.' });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to delete account.' });
  }
});

// ==========================================
// 1.5 TEMPLATE LIBRARY ENDPOINTS (/api/templates/*)
// ==========================================

// Get all templates catalog
app.get('/api/templates', (req: Request, res: Response) => {
  const summaries = LEGAL_TEMPLATES.map((t) => ({
    id: t.id,
    title: t.title,
    category: t.category,
    description: t.description,
    popular: t.popular,
    jurisdiction: t.jurisdiction,
    timeEst: t.timeEst,
    icon: t.icon,
  }));
  return res.json({ templates: summaries });
});

// Get single template with full schema & clauses
app.get('/api/templates/:id', (req: Request, res: Response) => {
  const template = LEGAL_TEMPLATES.find((t) => t.id === req.params.id);
  if (!template) {
    return res.status(404).json({ error: `Template with ID "${req.params.id}" not found.` });
  }
  return res.json({ template });
});

// Instantiate document from template
app.post('/api/templates/:id/instantiate', optionalAuthMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const template = LEGAL_TEMPLATES.find((t) => t.id === req.params.id);
  if (!template) {
    return res.status(404).json({ error: `Template with ID "${req.params.id}" not found.` });
  }

  const { title, initialVariables } = req.body;
  const variables = template.variables.map((v) => {
    if (initialVariables && initialVariables[v.key]) {
      return { ...v, value: initialVariables[v.key] };
    }
    return { ...v };
  });

  const userId = req.user?.id || 'guest-session';
  const doc: DocumentRecord = {
    id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    userId,
    title: title || template.title,
    category: template.category,
    status: 'Draft',
    lastSaved: 'Just now',
    variables,
    sections: template.sections.map((s) => ({ ...s })),
    suggestions: template.suggestions.map((sug) => ({ ...sug })),
    comments: [],
    readiness: { ...template.readiness },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  if (req.user) {
    const saved = db.createDocument(doc);
    return res.status(201).json({ document: saved });
  } else {
    return res.status(200).json({ document: doc });
  }
});

// ==========================================
// 2. DOCUMENT MANAGEMENT ENDPOINTS (/api/documents/*)
// ==========================================

// Get user documents
app.get('/api/documents', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const documents = db.getDocumentsByUser(req.user!.id);
  return res.json({ documents });
});

// Create new document
app.post('/api/documents', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { title, category, variables, sections, suggestions, comments, readiness } = req.body;

    const doc: DocumentRecord = {
      id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: req.user!.id,
      title: title || 'Untitled Document',
      category: category || 'Business',
      status: 'Draft',
      lastSaved: 'Just now',
      variables: variables || [],
      sections: sections || [],
      suggestions: suggestions || [],
      comments: comments || [],
      readiness: readiness || {
        completed: 5,
        total: 7,
        items: [
          { label: 'All parties defined', done: true },
          { label: 'Payment terms set', done: true },
          { label: 'Confidentiality clause included', done: true },
          { label: 'IP assignment clarified', done: true },
          { label: 'Termination terms specified', done: true },
          { label: 'All variables filled', done: false },
          { label: 'Signature blocks ready', done: false },
        ],
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = db.createDocument(doc);
    return res.status(201).json({ document: saved });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to create document.' });
  }
});

// Get document by ID (Strict ownership check)
app.get('/api/documents/:id', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const doc = db.findDocumentById(req.params.id);
  if (!doc) {
    return res.status(404).json({ error: 'Document not found.' });
  }
  // Enforce ownership: only owner or admin can view
  if (doc.userId !== req.user!.id && req.user!.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. You do not own this document.' });
  }
  return res.json({ document: doc });
});

// Update document (Strict ownership check)
app.put('/api/documents/:id', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const existing = db.findDocumentById(req.params.id);
  if (!existing) {
    return res.status(404).json({ error: 'Document not found.' });
  }
  if (existing.userId !== req.user!.id && req.user!.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. You do not own this document.' });
  }

  const updated = db.updateDocument(req.params.id, req.body);
  return res.json({ document: updated });
});

// Delete document (Strict ownership check)
app.delete('/api/documents/:id', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const existing = db.findDocumentById(req.params.id);
  if (!existing) {
    return res.status(404).json({ error: 'Document not found.' });
  }
  if (existing.userId !== req.user!.id && req.user!.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. You do not own this document.' });
  }

  db.deleteDocument(req.params.id, req.user!.id, req.user!.role === 'admin');
  return res.json({ success: true, message: 'Document deleted.' });
});

// Export DOCX File
app.post('/api/documents/:id/export-docx', authMiddleware, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const doc = db.findDocumentById(req.params.id);
    if (!doc) {
      return res.status(404).json({ error: 'Document not found.' });
    }
    if (doc.userId !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied.' });
    }

    const docParagraphs: Paragraph[] = [
      new Paragraph({
        text: doc.title.toUpperCase(),
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
      }),
      new Paragraph({
        text: `Category: ${doc.category} · Jurisdiction: Delaware · Prepared via LegalEase`,
        alignment: AlignmentType.CENTER,
        spacing: { after: 300 },
      }),
    ];

    doc.sections.forEach((sec) => {
      docParagraphs.push(
        new Paragraph({
          text: `${sec.number}. ${sec.title}`,
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 },
        })
      );

      let content = sec.content;
      doc.variables.forEach((v) => {
        content = content.replace(new RegExp(`{{${v.key}}}`, 'g'), v.value);
      });

      docParagraphs.push(
        new Paragraph({
          children: [new TextRun(content)],
          spacing: { after: 200 },
        })
      );
    });

    const docxFile = new DocxDocument({
      sections: [{ properties: {}, children: docParagraphs }],
    });

    const buffer = await Packer.toBuffer(docxFile);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${doc.title.toLowerCase().replace(/\s+/g, '-')}.docx"`);
    return res.send(buffer);
  } catch (err: any) {
    console.error('Docx generation error:', err);
    return res.status(500).json({ error: 'Failed to generate Word (.docx) document.' });
  }
});

// ==========================================
// 3. AI DRAFTING & REWRITE ENDPOINTS (/api/ai/*)
// ==========================================

// AI Generate Draft
app.post('/api/ai/generate', authMiddleware, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { documentType, parties, jurisdiction, keyTerms } = req.body;
    const result = await generateContractDraft({
      documentType: documentType || 'Master Service Agreement',
      parties,
      jurisdiction,
      keyTerms,
    });
    return res.json(result);
  } catch (err: any) {
    console.error('AI generate error:', err);
    return res.status(500).json({ error: 'AI drafting service unavailable.' });
  }
});

// AI Rewrite Clause
app.post('/api/ai/rewrite', authMiddleware, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { text, tone, clauseTitle } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text to rewrite is required.' });
    }
    const rewritten = await rewriteClause({
      text,
      tone: tone || 'Formal',
      clauseTitle,
    });
    return res.json({ rewritten });
  } catch (err: any) {
    console.error('AI rewrite error:', err);
    return res.status(500).json({ error: 'AI rewrite failed.' });
  }
});

// AI Assistant Chat
app.post('/api/ai/chat', authMiddleware, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { question, documentTitle, documentSummary } = req.body;
    if (!question) {
      return res.status(400).json({ error: 'Question is required.' });
    }
    const answer = await contractAssistantChat({
      question,
      documentTitle: documentTitle || 'Legal Document',
      documentSummary: documentSummary || '',
    });
    return res.json({ answer });
  } catch (err: any) {
    console.error('AI chat error:', err);
    return res.status(500).json({ error: 'AI chat service unavailable.' });
  }
});

// ==========================================
// 4. BILLING & SUBSCRIPTIONS (/api/billing/*)
// ==========================================

app.post('/api/billing/subscribe', authMiddleware, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { plan, currency = 'USD' } = req.body;
    if (!['basic', 'pro', 'enterprise'].includes(plan.toLowerCase())) {
      return res.status(400).json({ error: 'Invalid subscription tier.' });
    }

    const user = req.user!;
    const planNormalized = plan.toLowerCase() as 'basic' | 'pro' | 'enterprise';

    db.updateUser(user.id, { subscriptionPlan: planNormalized === 'basic' ? 'free' : planNormalized });

    db.createOrUpdateSubscription({
      id: `sub-${Date.now()}`,
      userId: user.id,
      plan: planNormalized === 'basic' ? 'free' : planNormalized,
      status: 'active',
      amount: planNormalized === 'pro' ? 25 : planNormalized === 'enterprise' ? 75 : 10,
      currency: currency as 'USD' | 'INR',
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
    });

    db.createAuditLog({
      userId: user.id,
      userEmail: user.email,
      action: 'SUBSCRIPTION_UPGRADED',
      details: `User upgraded plan to ${planNormalized.toUpperCase()}`,
    });

    return res.json({
      success: true,
      plan: planNormalized,
      message: `Successfully upgraded to ${planNormalized.toUpperCase()} plan.`,
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to process subscription upgrade.' });
  }
});

// ==========================================
// 5. ADMIN ENDPOINTS (/api/admin/*)
// ==========================================

// Get all users (Admin only)
app.get('/api/admin/users', authMiddleware, requireAdminMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const users = db.getUsers().map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    subscriptionPlan: u.subscriptionPlan,
    emailVerified: u.emailVerified,
    createdAt: u.createdAt,
  }));
  return res.json({ users });
});

// Get admin system statistics (Admin only)
app.get('/api/admin/stats', authMiddleware, requireAdminMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const users = db.getUsers();
  const documents = db.getAllDocuments();
  const auditLogs = db.getAuditLogs();

  return res.json({
    totalUsers: users.length,
    totalDocuments: documents.length,
    activeSubscriptions: users.filter((u) => u.subscriptionPlan !== 'free').length,
    recentAuditCount: auditLogs.length,
  });
});

// Get audit logs (Admin only)
app.get('/api/admin/audit-logs', authMiddleware, requireAdminMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const logs = db.getAuditLogs(100);
  return res.json({ logs });
});

// Change user role (Admin only)
app.patch('/api/admin/users/:id/role', authMiddleware, requireAdminMiddleware, (req: AuthenticatedRequest, res: Response) => {
  const { role } = req.body;
  if (!['user', 'admin'].includes(role)) {
    return res.status(400).json({ error: 'Role must be user or admin.' });
  }
  const updated = db.updateUser(req.params.id, { role });
  if (!updated) {
    return res.status(404).json({ error: 'User not found.' });
  }
  return res.json({ user: updated, message: `Role updated to ${role}.` });
});

// ==========================================
// 6. FRONTEND MOUNTING & STATIC SERVING
// ==========================================

if (!isProd) {
  // Development mode: attach Vite dev server middleware
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  // Production mode: serve built assets from dist
  const distDir = path.resolve(__dirname, 'dist');
  app.use(express.static(distDir));
  app.get('*', (req: Request, res: Response) => {
    res.sendFile(path.resolve(distDir, 'index.html'));
  });
}

// Start Server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`LegalEase Server listening on http://0.0.0.0:${PORT}`);
});
