import React, { createContext, useContext, useState, useEffect } from 'react';
import { api, User } from '../lib/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (name: string, email: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
  forgotPassword: (email: string) => Promise<{ message: string; resetToken?: string }>;
  resetPassword: (token: string, newPassword: string) => Promise<void>;
  updateProfile: (data: { name?: string; email?: string }) => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  deleteAccount: (confirmPassword: string) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    try {
      const res = await api.auth.me();
      setUser(res.user);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const login = async (email: string, password: string): Promise<User> => {
    const res = await api.auth.login({ email, password });
    setUser(res.user);
    return res.user;
  };

  const register = async (name: string, email: string, password: string): Promise<User> => {
    const res = await api.auth.register({ name, email, password });
    setUser(res.user);
    return res.user;
  };

  const logout = async () => {
    await api.auth.logout();
    setUser(null);
  };

  const forgotPassword = async (email: string) => {
    const res = await api.auth.forgotPassword(email);
    return { message: res.message, resetToken: res.resetToken };
  };

  const resetPassword = async (token: string, newPassword: string) => {
    await api.auth.resetPassword({ token, newPassword });
  };

  const updateProfile = async (data: { name?: string; email?: string }) => {
    const res = await api.auth.updateProfile(data);
    setUser(res.user);
  };

  const changePassword = async (currentPassword: string, newPassword: string) => {
    await api.auth.changePassword({ currentPassword, newPassword });
  };

  const deleteAccount = async (confirmPassword: string) => {
    await api.auth.deleteAccount(confirmPassword);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        forgotPassword,
        resetPassword,
        updateProfile,
        changePassword,
        deleteAccount,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
