/**
 * LegalEase 12-Scene Automated Walkthrough & Video Recording Script
 * 
 * Usage:
 *   1. Install Playwright:
 *      npm install -D playwright
 *      npx playwright install chromium
 * 
 *   2. Run this script to execute the 12 scenes and record video:
 *      node scripts/record-demo-playwright.cjs
 * 
 * The output video will be saved to: ./videos/legalease-demo-walkthrough.webm
 */

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

async function recordWalkthrough() {
  console.log('Starting LegalEase Automated Video Walkthrough...');

  const videosDir = path.resolve(process.cwd(), 'videos');
  if (!fs.existsSync(videosDir)) {
    fs.mkdirSync(videosDir, { recursive: true });
  }

  const browser = await chromium.launch({
    headless: false, // Set to true for headless recording environments
    slowMo: 800, // Smooth human-like pacing for clear demonstration
  });

  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    recordVideo: {
      dir: videosDir,
      size: { width: 1440, height: 900 },
    },
  });

  const page = await context.newPage();
  const BASE_URL = process.env.APP_URL || 'http://localhost:3000';

  try {
    // Scene 1: Open the LegalEase homepage
    console.log('Scene 1: Loading Homepage...');
    await page.goto(BASE_URL);
    await page.waitForTimeout(2000);

    // Scene 2: Sign in using safe test credentials
    console.log('Scene 2: Signing in with safe test account...');
    await page.click('button:has-text("Login")');
    await page.waitForSelector('input[type="email"]');
    await page.fill('input[type="email"]', 'bsv626718@gmail.com');
    await page.fill('input[type="password"]', 'Password123!');
    await page.click('button:has-text("Sign In to Account")');
    await page.waitForTimeout(2500);

    // Scene 3: Open the dashboard
    console.log('Scene 3: Verifying workspace dashboard...');
    await page.waitForSelector('h1:has-text("Good morning")');
    await page.waitForTimeout(2000);

    // Scene 4: Select Templates from Left Sidebar
    console.log('Scene 4: Navigating to Templates catalog...');
    await page.click('button:has-text("Templates")');
    await page.waitForSelector('h1:has-text("Verified Legal Document Templates")');
    await page.waitForTimeout(2000);

    // Scene 5: Choose Rental Agreement and click Edit
    console.log('Scene 5: Selecting Rental Agreement and clicking Edit...');
    const rentalCard = page.locator('div:has-text("Rental Agreement")').first();
    await rentalCard.locator('button:has-text("Edit")').click();
    await page.waitForTimeout(2500);

    // Scene 6: Show the document loading correctly and fill sample fields
    console.log('Scene 6: Editing variables with fictional sample data...');
    await page.waitForSelector('h1:has-text("Rental Agreement")');
    // Click on a variable chip
    const variableChip = page.locator('span:has-text("Frankie Mondo")').first();
    if (await variableChip.isVisible()) {
      await variableChip.click();
      await page.waitForTimeout(1500);
    }

    // Scene 7: Generate agreement / Apply AI Suggestion
    console.log('Scene 7: Applying legal AI suggestion & clauses...');
    const addClauseBtn = page.locator('button:has-text("Add clause")').first();
    if (await addClauseBtn.isVisible()) {
      await addClauseBtn.click();
      await page.waitForTimeout(2000);
    }

    // Scene 8: Show properly formatted document preview
    console.log('Scene 8: Opening document preview...');
    await page.click('button:has-text("Preview")');
    await page.waitForSelector('h2:has-text("Rental Agreement")');
    await page.waitForTimeout(3000);

    // Scene 9: Edit and save document
    console.log('Scene 9: Saving document to vault...');
    await page.click('button:has-text("Back")');
    await page.waitForTimeout(1000);
    await page.click('button:has-text("Save")');
    await page.waitForTimeout(2000);

    // Scene 10: Download PDF
    console.log('Scene 10: Triggering print-ready PDF export...');
    const [download] = await Promise.all([
      page.waitForEvent('download', { timeout: 8000 }).catch(() => null),
      page.click('button:has-text("Export")'),
    ]);
    await page.waitForTimeout(2000);

    // Scene 11: Open My Documents and Profile via Left Sidebar
    console.log('Scene 11: Navigating to My Documents & Settings...');
    await page.click('button:has-text("Dashboard")');
    await page.waitForTimeout(2000);
    await page.click('button:has-text("Profile")');
    await page.waitForSelector('h1:has-text("Account & Settings")');
    await page.waitForTimeout(2500);

    // Scene 12: Finished workflow
    console.log('Scene 12: Walkthrough completed successfully.');
    await page.waitForTimeout(2000);

    console.log('Recording finished! Video will be saved in:', videosDir);
  } catch (error) {
    console.error('Walkthrough error:', error);
  } finally {
    await context.close();
    await browser.close();
  }
}

if (require.main === module) {
  recordWalkthrough();
}
