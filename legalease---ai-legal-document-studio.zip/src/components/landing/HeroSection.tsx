import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Play,
  Search,
  Shield,
  Zap,
  FileText,
  ShieldCheck,
  Home,
  User,
  Star,
  Settings,
  FolderOpen,
  Scale,
  Globe,
} from 'lucide-react';

interface HeroSectionProps {
  onGenerateDocument: (promptText?: string) => void;
  onWatchDemo: () => void;
  onOpenLeaseWizard: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onGenerateDocument,
  onWatchDemo,
  onOpenLeaseWizard,
}) => {
  const [laptopSearchPrompt, setLaptopSearchPrompt] = useState('');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('India - Tamil Nadu');

  const handleLaptopGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (laptopSearchPrompt.toLowerCase().includes('lease') || laptopSearchPrompt.toLowerCase().includes('rental')) {
      onOpenLeaseWizard();
    } else {
      onGenerateDocument(laptopSearchPrompt ? `${laptopSearchPrompt} (${selectedJurisdiction})` : `Master Service Agreement (${selectedJurisdiction})`);
    }
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-20 bg-linear-to-b from-blue-50/40 via-white to-slate-50">
      {/* Background soft ambient blurs */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-blue-100/30 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header Copy (Exact match to Image 2) */}
        <div className="text-center max-w-3xl mx-auto">
          {/* Badge: AI-Powered Legal Document Generator */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-700 text-xs font-semibold mb-6 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>AI-Powered Legal Document Generator</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15] mb-5">
            Create Legal Documents <br />
            in <span className="text-blue-600">Minutes, Not Hours</span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto mb-8 font-normal leading-relaxed">
            LegalEase uses advanced AI to help you generate professional, customizable legal documents — quickly, easily, and affordably.
          </p>

          {/* 3 Checkmark Value Badges */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm font-medium text-slate-700 mb-8">
            <span className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </span>
              Accurate & Reliable
            </span>
            <span className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </span>
              Easy to Use
            </span>
            <span className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </span>
              100% Secure
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <button
              onClick={() => onGenerateDocument()}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-base shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 group cursor-pointer"
            >
              <span>Generate Your Document</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={onWatchDemo}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl border border-blue-600 text-blue-600 hover:bg-blue-50/70 font-semibold text-base transition-all flex items-center justify-center gap-2 cursor-pointer bg-white"
            >
              <Play className="w-4 h-4 fill-blue-600 text-blue-600" />
              <span>Watch How It Works</span>
            </button>
          </div>

          {/* Social Proof with Overlapping Avatars & Rating */}
          <div className="flex items-center justify-center gap-3">
            <div className="flex -space-x-2 overflow-hidden">
              <img
                className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover shadow-xs"
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=80&q=80"
                alt="Sarah Chen"
              />
              <img
                className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover shadow-xs"
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&q=80"
                alt="Alex Rivera"
              />
              <img
                className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover shadow-xs"
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&q=80"
                alt="Elena Gomez"
              />
              <img
                className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover shadow-xs"
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=80&q=80"
                alt="David Kim"
              />
            </div>
            <div className="text-left text-xs">
              <p className="font-semibold text-slate-800">Trusted by 50,000+ users</p>
              <div className="flex items-center gap-1 text-amber-500">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <span className="font-bold text-slate-700 ml-1">4.8/5</span>
              </div>
            </div>
          </div>
        </div>

        {/* Laptop Mockup on Desk with Floating 3D Cards (Image 2 exact replica) */}
        <div className="relative mt-14 max-w-5xl mx-auto">
          {/* Floating Card 1: Top-Left "Contract" */}
          <div
            onClick={() => onGenerateDocument('Contract')}
            className="absolute -left-4 sm:left-4 top-4 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-slate-100 hover:shadow-2xl hover:-translate-y-1 transition-all cursor-pointer w-36 sm:w-44 hidden md:block"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
              <FileText className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-slate-900 mb-2">Contract</h4>
            <div className="space-y-1.5 opacity-60">
              <div className="h-1.5 bg-slate-200 rounded-full w-full" />
              <div className="h-1.5 bg-slate-200 rounded-full w-4/5" />
              <div className="h-1.5 bg-slate-200 rounded-full w-3/5" />
            </div>
          </div>

          {/* Floating Card 2: Bottom-Left "NDA" */}
          <div
            onClick={() => onGenerateDocument('Non-Disclosure Agreement')}
            className="absolute -left-2 sm:left-8 bottom-12 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-slate-100 hover:shadow-2xl hover:-translate-y-1 transition-all cursor-pointer w-36 sm:w-44 hidden md:block"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-slate-900 mb-2">NDA</h4>
            <div className="space-y-1.5 opacity-60">
              <div className="h-1.5 bg-slate-200 rounded-full w-full" />
              <div className="h-1.5 bg-slate-200 rounded-full w-2/3" />
            </div>
          </div>

          {/* Floating Card 3: Top-Right "Rental Agreement" */}
          <div
            onClick={onOpenLeaseWizard}
            className="absolute -right-4 sm:right-4 top-4 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-slate-100 hover:shadow-2xl hover:-translate-y-1 transition-all cursor-pointer w-36 sm:w-48 hidden md:block"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
              <Home className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-slate-900 mb-2">Rental Agreement</h4>
            <div className="space-y-1.5 opacity-60">
              <div className="h-1.5 bg-slate-200 rounded-full w-full" />
              <div className="h-1.5 bg-slate-200 rounded-full w-5/6" />
              <div className="h-1.5 bg-slate-200 rounded-full w-2/4" />
            </div>
          </div>

          {/* Floating Card 4: Bottom-Right "Will" */}
          <div
            onClick={() => onGenerateDocument('Last Will and Testament')}
            className="absolute -right-2 sm:right-8 bottom-12 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-slate-100 hover:shadow-2xl hover:-translate-y-1 transition-all cursor-pointer w-36 sm:w-44 hidden md:block"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
              <User className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-slate-900 mb-2">Will</h4>
            <div className="space-y-1.5 opacity-60">
              <div className="h-1.5 bg-slate-200 rounded-full w-full" />
              <div className="h-1.5 bg-slate-200 rounded-full w-3/4" />
            </div>
          </div>

          {/* Laptop Device Frame & Screen Mockup */}
          <div className="relative mx-auto max-w-3xl">
            {/* Laptop Screen Body */}
            <div className="bg-slate-900 p-2 sm:p-3 rounded-t-2xl sm:rounded-t-3xl shadow-2xl border-4 border-slate-800">
              {/* Screen Bezel Camera */}
              <div className="flex items-center justify-center pb-2">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-700 inline-block" />
              </div>

              {/* Inside Laptop Screen Interface (Image 2 laptop UI) */}
              <div className="bg-slate-50 rounded-xl overflow-hidden shadow-inner border border-slate-200">
                <div className="flex h-[320px] sm:h-[380px]">
                  {/* Mini Sidebar inside laptop */}
                  <div className="w-36 sm:w-44 bg-blue-900 text-white p-3 sm:p-4 flex flex-col justify-between shrink-0">
                    <div className="space-y-4">
                      {/* Laptop Mini Logo */}
                      <div className="flex items-center gap-2 text-white font-bold text-xs tracking-tight">
                        <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center text-white">
                          ⚖️
                        </div>
                        <span>LegalEase</span>
                      </div>

                      {/* Nav Links */}
                      <div className="space-y-1 text-[11px]">
                        <div className="flex items-center gap-2 px-2 py-1.5 rounded bg-blue-800/80 font-medium text-white">
                          <Home className="w-3 h-3 text-blue-300" />
                          <span>Home</span>
                        </div>
                        <div className="flex items-center gap-2 px-2 py-1.5 rounded text-blue-200 hover:text-white">
                          <FileText className="w-3 h-3" />
                          <span>Templates</span>
                        </div>
                        <div className="flex items-center gap-2 px-2 py-1.5 rounded text-blue-200 hover:text-white">
                          <FolderOpen className="w-3 h-3" />
                          <span>My Documents</span>
                        </div>
                        <div className="flex items-center gap-2 px-2 py-1.5 rounded text-blue-200 hover:text-white">
                          <Settings className="w-3 h-3" />
                          <span>Settings</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-[10px] text-blue-300 border-t border-blue-800/60 pt-2">
                      v2.4 AI Pro
                    </div>
                  </div>

                  {/* Main Laptop Content Area */}
                  <div className="flex-1 p-4 sm:p-8 flex flex-col items-center justify-center text-center bg-white">
                    <h3 className="text-base sm:text-xl font-bold text-slate-900 mb-4 sm:mb-6">
                      What legal document do you need?
                    </h3>

                    {/* Interactive Search Bar inside Mockup */}
                    <form onSubmit={handleLaptopGenerate} className="w-full max-w-md space-y-2">
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            value={laptopSearchPrompt}
                            onChange={(e) => setLaptopSearchPrompt(e.target.value)}
                            placeholder="e.g., Rental Agreement, NDA, Service Agreement..."
                            className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all placeholder:text-slate-400 shadow-2xs"
                          />
                        </div>
                        <select
                          value={selectedJurisdiction}
                          onChange={(e) => setSelectedJurisdiction(e.target.value)}
                          className="px-2 py-2 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-700 bg-slate-50 focus:outline-none cursor-pointer"
                        >
                          <option value="India - Tamil Nadu">🇮🇳 Tamil Nadu (TNRRRL Act)</option>
                          <option value="India - Central">🇮🇳 India (Central Acts)</option>
                          <option value="India - Maharashtra">🇮🇳 Maharashtra</option>
                          <option value="Delaware, US">🇺🇸 Delaware, US</option>
                        </select>
                      </div>
                      <button
                        type="submit"
                        className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Generate Grounded Document</span>
                      </button>
                    </form>

                    {/* 3 Value Badges at bottom of laptop */}
                    <div className="flex items-center justify-center gap-4 sm:gap-6 mt-6 sm:mt-8 text-[11px] text-slate-600">
                      <span className="flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-blue-600" />
                        AI Powered
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Shield className="w-3.5 h-3.5 text-blue-600" />
                        Secure
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                        Fast
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Laptop Base Stand / Hinge */}
            <div className="relative bg-slate-300 h-3 sm:h-4 w-[105%] -left-[2.5%] rounded-b-xl shadow-lg border-t border-slate-400">
              <div className="mx-auto w-24 h-1 bg-slate-400 rounded-full mt-1" />
            </div>

            {/* Table Surface Reflection */}
            <div className="h-5 w-4/5 mx-auto bg-slate-300/40 blur-md rounded-full mt-1 -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
};
